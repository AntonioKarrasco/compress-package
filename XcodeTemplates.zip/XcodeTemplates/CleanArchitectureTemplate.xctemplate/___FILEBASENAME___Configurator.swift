//  ___FILEHEADER___

import Foundation
import UIKit

protocol ___FILEBASENAMEASIDENTIFIER___ {
    func configure(controller: ___VARIABLE_cutClass:identifier___ViewController)
}

class ___FILEBASENAMEASIDENTIFIER___Implementation: ___FILEBASENAMEASIDENTIFIER___ {
    func configure(controller: ___VARIABLE_cutClass:identifier___ViewController) {
        // ApiClient
        // let apiClient = ApiClientImplementation()
        // Gateway
        // let apiGateway = ___VARIABLE_cutClass:identifier___ApiGatewayImplementation(apiClient: apiClient)
        // UseCase
        // let example___VARIABLE_cutClass:identifier___UseCase = Example___VARIABLE_cutClass:identifier___UseCaseImplementation(apiGateWay: apiGateway)
        // Router
        let router = ___VARIABLE_cutClass:identifier___ViewRouterImplementation(controller: controller)
        // Presenter
        let presenter = ___VARIABLE_cutClass:identifier___PresenterImplementation(view: controller, router: router)
        controller.presenter = presenter
    }
}
