//  ___FILEHEADER___

import Foundation
import UIKit

class ___FILEBASENAMEASIDENTIFIER___: UIViewController {
    ///////////////////////////////////////
    // MARK: Outlets
    ///////////////////////////////////////
    
    ///////////////////////////////////////
    // MARK: Properties
    ///////////////////////////////////////
    var presenter: ___VARIABLE_cutClass:identifier___Presenter!
    var configurator = ___VARIABLE_cutClass:identifier___ConfiguratorImplementation()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configurator.configure(controller: self)
    }
}

extension ___FILEBASENAMEASIDENTIFIER___: ___VARIABLE_cutClass:identifier___View {
}
