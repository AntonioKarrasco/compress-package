//  ___FILEHEADER___

import Foundation
import UIKit

protocol ___FILEBASENAMEASIDENTIFIER___ {
}

class ___VARIABLE_cutClass:identifier___ViewRouterImplementation: ___FILEBASENAMEASIDENTIFIER___ {
    let controller: ___VARIABLE_cutClass:identifier___ViewController
    
    init(controller: ___VARIABLE_cutClass:identifier___ViewController) {
        self.controller = controller
    }
}
