//  ___FILEHEADER___

import Foundation
import UIKit

protocol ___VARIABLE_cutClass:identifier___View {
}

protocol ___FILEBASENAMEASIDENTIFIER___ {
}

class ___FILEBASENAMEASIDENTIFIER___Implementation: ___FILEBASENAMEASIDENTIFIER___ {
    fileprivate let view: ___VARIABLE_cutClass:identifier___View
    fileprivate let router: ___VARIABLE_cutClass:identifier___ViewRouter
    
    init(view: ___VARIABLE_cutClass:identifier___View, router: ___VARIABLE_cutClass:identifier___ViewRouter) {
        self.view = view
        self.router = router
    }
}
