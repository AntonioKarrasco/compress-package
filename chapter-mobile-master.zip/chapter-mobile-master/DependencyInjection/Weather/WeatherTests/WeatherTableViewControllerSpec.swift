//
//  WeatherTableViewControllerSpec.swift
//  WeatherTests
//
//  Created by GBM Mobile on 10/23/17.
//  Copyright © 2017 GBM Mobile. All rights reserved.
//

import Quick
import Nimble
import Swinject
@testable import Weather

class WeatherTableViewControllerSpec: QuickSpec {
    
    //Networking is defined as MockNetwork, it increments a counter named requestCount
    class MockNetwork: Networking {
        
        var requestCount = 0
        
        func request(response: @escaping (Data?) -> ()) {
             requestCount += 1
        }
        
    }
    
    override func spec() {
        var container: Container!
        beforeEach {
            container = Container()
            
            //Register to MockNetwork
            container.register(Networking.self) { _ in MockNetwork() }.inObjectScope(.container)
            container.register(WeatherFetcher.self) { r in
                WeatherFetcher(networking: r.resolve(Networking.self)!)
            }
            
            //WeatherTableViewController are retrieved from the configured container
            container.register(WeatherTableViewController.self) { r in
                let controller = WeatherTableViewController()
                controller.weatherFetcher = r.resolve(WeatherFetcher.self)
                return controller
            }
        }
        
        it("starts fetching weather information when the view is about appearing.") {
         
            //Cast the returned instance to MockNetwork
            let network = container.resolve(Networking.self) as! MockNetwork
            let controller = container.resolve(WeatherTableViewController.self)!
            
            expect(network.requestCount) == 0
            controller.viewWillAppear(true)
            expect(network.requestCount).toEventually(equal(1))
            
        }
    }
    
}
