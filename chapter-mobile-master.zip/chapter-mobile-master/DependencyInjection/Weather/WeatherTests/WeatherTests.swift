//
//  WeatherTests.swift
//  WeatherTests
//
//  Created by GBM Mobile on 10/23/17.
//  Copyright © 2017 GBM Mobile. All rights reserved.
//  https://github.com/Quick/Nimble

import Quick
import Nimble
@testable import Weather

class WeatherTests: QuickSpec {
    
    override func spec() {
        it("returns cities normal.") { //Quick and Nimble, each test is written in an it closure
            var cities:[City]?

           
            WeatherFetcher.fetch(response: { (responses) in
                cities = responses
                
            })
            
             expect(cities).toEventuallyNot(beNil())  //asynchronously
           
            expect(cities?.count).toEventually(equal(12))
            let city = cities?[0]
            expect(city?.id).toEventually(equal(6077243))
            expect(city?.name).toEventually(equal("Montreal"))
            expect(city?.weather).toEventually(equal("Clouds"))
            
        }
        
    }
    
    
    
    
}
