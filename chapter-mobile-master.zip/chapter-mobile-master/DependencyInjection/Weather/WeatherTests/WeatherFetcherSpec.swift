//
//  WeatherFetcherSpec.swift
//  WeatherTests
//
//  Created by GBM Mobile on 10/23/17.
//  Copyright © 2017 GBM Mobile. All rights reserved.
//

import Quick
import Nimble
import Swinject
@testable import Weather

class WeatherFetcherSpec: QuickSpec {

    //StubNetwork is a stub that conforms Networking
    struct StubNetwork: Networking {
        
        //Has a definition of JSON data that has the same structure as the data returned from the server.
        private static let json =
            "{" +
                "\"list\": [" +
                "{" +
                "\"id\": 2643743," +
                "\"name\": \"London\"," +
                "\"weather\": [" +
                "{" +
                "\"main\": \"Rain\"" +
                "}" +
                "]" +
                "}," +
                "{" +
                "\"id\": 3451190," +
                "\"name\": \"Rio de Janeiro\"," +
                "\"weather\": [" +
                "{" +
                "\"main\": \"Clear\"" +
                "}" +
                "]" +
                "}" +
                "]" +
        "}"
        
        func request(response: @escaping (Data?) -> ()) {
            let data = StubNetwork.json.data(using: String.Encoding.utf8, allowLossyConversion: false)
            response(data)
        }
        
    
    }
    
    override func spec() {
        
        var container: Container!
        
        container = Container()
//        beforeEach {
//            container = Container()
//
//            // Registrations for the network using Alamofire.
//            container.register(Networking.self) { _ in Network() }
//            container.register(WeatherFetcher.self) { r in
//                WeatherFetcher(networking: r.resolve(Networking.self)!)
//            }
//
//            // Registration for the stub network.
//            container.register(Networking.self, name: "stub") { _ in
//                StubNetwork()
//            }
//            container.register(WeatherFetcher.self, name: "stub") { r in
//                WeatherFetcher(networking: r.resolve(Networking.self, name: "stub")!)
//            }
//        }
        
        it("returns cities injected.") {
            
            // Registrations for the network using Alamofire.
            container.register(Networking.self) { _ in Network() }
            container.register(WeatherFetcher.self) { r in
                WeatherFetcher(networking: r.resolve(Networking.self)!)
            }
            
            
            // Without a registration name, container is configured to use Network
            var cities: [City]?
            let fetcher = container.resolve(WeatherFetcher.self)!
            fetcher.fetch { cities = $0 }
            
            expect(cities).toEventuallyNot(beNil())
            expect(cities?.count).toEventually(beGreaterThan(0))
            
        }
        
        it("fills weather data injected.") {
            
            // Registration for the stub network.
            container.register(Networking.self, name: "stub") { _ in
                StubNetwork()
            }
            container.register(WeatherFetcher.self, name: "stub") { r in
                WeatherFetcher(networking: r.resolve(Networking.self, name: "stub")!)
            }
            
            // With a registration name, container is configured to use stub
            var cities: [City]?
            let fetcher = container.resolve(WeatherFetcher.self, name: "stub")!
            fetcher.fetch { cities = $0 }
            
            expect(cities?[0].id).toEventually(equal(2643743))
            expect(cities?[0].name).toEventually(equal("London"))
            expect(cities?[0].weather).toEventually(equal("Rain"))
            expect(cities?[1].id).toEventually(equal(3451190))
            expect(cities?[1].name).toEventually(equal("Rio de Janeiro"))
            expect(cities?[1].weather).toEventually(equal("Clear"))
        }
        
        //The unit tests have become reproducible under any circumstances
    }
    
    
}
