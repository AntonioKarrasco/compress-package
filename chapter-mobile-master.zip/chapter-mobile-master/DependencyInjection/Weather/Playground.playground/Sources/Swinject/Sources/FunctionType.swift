//
//  FunctionType.swift
//  Swinject
//
//  Created by Yoichi Tagaya on 11/28/15.
//  Copyright © 2015 Swinject Contributors. All rights reserved.
//

// Type alias to expect a closure.
internal typealias FunctionType = Any
