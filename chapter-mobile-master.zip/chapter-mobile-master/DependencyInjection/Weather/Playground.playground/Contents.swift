//: Playground - noun: a place where people can play

import UIKit

print("---- Without Dependency Injection ----")
class Cat {
    let name: String
    
    init(name: String) {
        self.name = name
    }
    
    func sound() -> String {
        return "Meow!"
    }
}

class PetOwner {
    let pet = Cat(name: "Mimi")
    
    func play() -> String {
        return "I'm playing with \(pet.name). \(pet.sound())"
    }
}

let petOwner = PetOwner()
print(petOwner.play()) // prints "I'm playing with Mimi. Meow!"

print("Conclution:")
print("Problem hardcoded pet -> cat")
print("But if the owner has a dog")
print("\n")

print("---- With Dependency Injection ----")
protocol AnimalType {
    var name: String { get }
    func sound() -> String
}

class PetOwnerDependency {
    
    let pet: AnimalType
    
    init(pet: AnimalType) {
        self.pet = pet
    }
    
    func play() -> String {
        return "I'm playing with \(pet.name). \(pet.sound())"
    }
}

class CatByProtocol: AnimalType {
    let name: String
    
    init(name: String) {
        self.name = name
    }
    
    func sound() -> String {
        return "Meow!"
    }
}

let catOwner = PetOwnerDependency(pet: CatByProtocol(name: "Mimi"))
print(catOwner.play())

class DogByProtocol: AnimalType {
    let name: String
    
    init(name: String) {
        self.name = name
    }
    
    func sound() -> String {
        return "Bow wow!"
    }
}

let dogOwner = PetOwnerDependency(pet: DogByProtocol(name: "Hachi"))
print(dogOwner.play())

print("Conclution:")
print("Injected the dependency PetOwnerDependency")
print("But if we get more dependencies as the app evolved, it is harder to maintain dependency injection by hand")
print("\n")


print("---- Using Swinject ----")

class PetOwnerDependencyDog : PetOwnerDependency {

}

class PetOwnerDependencyCat : PetOwnerDependency {

}

let container = Container()
container.register(CatByProtocol.self) { _ in CatByProtocol(name: "Mimi") }
container.register(DogByProtocol.self) { _ in DogByProtocol(name: "Hachi") }

container.register(PetOwnerDependencyCat.self) { r in
    PetOwnerDependencyCat(pet: r.resolve(CatByProtocol.self)!)
}

container.register(PetOwnerDependencyDog.self) { r in
    PetOwnerDependencyDog(pet: r.resolve(DogByProtocol.self)!)
}


let petOwnerInstanceCat = container.resolve(PetOwnerDependencyCat.self)!
print(petOwnerInstanceCat.play())

let petOwnerInstanceDog = container.resolve(PetOwnerDependencyDog.self)!
print(petOwnerInstanceDog.play())

print("Conclution:")
print("First need to register the protocol and the intance for resolve the container")
print("The Container and to retrieve a resolved instance with its dependencies injected")

