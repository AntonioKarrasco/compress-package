//
//  WeatherTableViewController.swift
//  Weather
//
//  Created by GBM Mobile on 10/23/17.
//  Copyright © 2017 GBM Mobile. All rights reserved.
//

import UIKit

class WeatherTableViewController: UITableViewController {

    var weatherFetcher: WeatherFetcher?
    
    private var cities = [City]() {
        didSet {
            tableView.reloadData()
        }
    }
    
    // MARK: Normal
    override func viewDidLoad() {
        super.viewDidLoad()
        
        WeatherFetcher.fetch {
            
            if let cities = $0 {
                self.cities = cities
            }
            else {
                // Show an error message.
            }
            
        }
        
    }
    
    // MARK: Dependency Injection
//    override func viewDidLoad() {
//        super.viewDidLoad()
//
//        weatherFetcher?.fetch {
//            if let cities = $0 {
//                self.cities = cities
//            }
//            else {
//                // Show an error message.
//            }
//        }
//
//    }


    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        let city = cities[indexPath.row]
        cell.textLabel?.text = city.name
        cell.detailTextLabel?.text = city.weather
        return cell
        
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return cities.count
        
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

