//
//  OpenWeatherMap.swift
//  Weather
//
//  Created by GBM Mobile on 10/23/17.
//  Copyright © 2017 GBM Mobile. All rights reserved.
//
//http://openweathermap.org/
import Foundation

struct OpenWeatherMap {
    
    static let cityIds = [
        6077243, 524901, 5368361, 1835848, 3128760, 4180439,
        2147714, 264371, 1816670, 2643743, 3451190, 1850147
    ]
    
    static let url = "http://api.openweathermap.org/data/2.5/group?APPID=a9836c5729108b7262761d8ea47382b7"
    
}
