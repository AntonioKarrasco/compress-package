//
//  WeatherFetcher.swift
//  Weather
//
//  Created by GBM Mobile on 10/23/17.
//  Copyright © 2017 GBM Mobile. All rights reserved.
//

import Foundation
import Alamofire
import SwiftyJSON

struct WeatherFetcher {
    
    // MARK: Injected
    let networking: Networking
    
    func fetch(response: @escaping ([City]?) -> ()) {
        networking.request { data in
            let cities = data.map { WeatherFetcher.decode(data: $0) }
            response(cities)
        }
    }
    
    
    // MARK: Normal
    static func fetch(response: @escaping ([City]?) -> ()) {
        
        print("1.- Request to Api")
        let url =  OpenWeatherMap.url + "&id=" + OpenWeatherMap.cityIds.map { String($0) }.joined(separator: ",")
        print(url)
        Alamofire.request(url, method: .get)
            .responseData{ data in
                
                let cities = data.map { decode(data: $0) }
                //print(cities)
                print("2.- Decode and map response")
                response(cities.result.value)
                
            }
          
        
    }
    
    private static func decode(data: Data) -> [City] {
        let json = JSON(data: data as Data)
        var cities = [City]()
        for (_, j) in json["list"] {
            if let id = j["id"].int {
                let name = j["name"].string ?? ""
                let city = City(
                    id: id,
                    name: name,
                    weather: j["weather"][0]["main"].string ?? "")
                cities.append(city)
            }
        }
        return cities
    }
}
