//
//  City.swift
//  Weather
//
//  Created by GBM Mobile on 10/23/17.
//  Copyright © 2017 GBM Mobile. All rights reserved.
//

import Foundation

struct City {
    let id: Int
    let name: String
    let weather: String
}
