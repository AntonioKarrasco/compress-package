//
//  Networking.swift
//  Weather
//
//  Created by GBM Mobile on 10/23/17.
//  Copyright © 2017 GBM Mobile. All rights reserved.
//

import Foundation
import Alamofire

protocol Networking {
    func request(response: @escaping (Data?) -> ())
}

struct Network : Networking {
    
    func request(response: @escaping (Data?) -> ()){
        
        print("1.- Request to Api")
        let url =  OpenWeatherMap.url + "&id=" + OpenWeatherMap.cityIds.map { String($0) }.joined(separator: ",")
        print(url)
        Alamofire.request(url, method: .get)
            .responseData{ value in
                
            response(value.data)
                
        }
        
    }

}
