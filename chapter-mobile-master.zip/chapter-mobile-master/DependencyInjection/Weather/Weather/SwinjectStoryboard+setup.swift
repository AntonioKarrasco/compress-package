//
//  SwinjectStoryboard+setup.swift
//  Weather
//
//  Created by GBM Mobile on 10/23/17.
//  Copyright © 2017 GBM Mobile. All rights reserved.
//

import Foundation
import Swinject
import SwinjectStoryboard

extension SwinjectStoryboard {
    
    //The setup method in the extension is called only once before the first instance of SwinjectStoryboard is instantiated
    //SwinjectStoryboard is automatically instantiated when the runtime tries to instantiate UIStoryboard
    @objc class func setup() {
        
        let container : Container = defaultContainer
        
        //Used to configure dependency injection to WeatherTableViewController
        container.storyboardInitCompleted(WeatherTableViewController.self) { r, c in
            //weatherFetcher property is configured to be set to an instance of WeatherFetcher
            //is called “property injection”
            c.weatherFetcher = r.resolve(WeatherFetcher.self)
        }
        
        //Network encapsulating Alamofire
        container.register(Networking.self) { _ in Network() }
        
        container.register(WeatherFetcher.self) { r in
            //WeatherFetcher is configured to be initialized with a resolved Networking instance
            WeatherFetcher(networking: r.resolve(Networking.self)!)
        }
        
    }
    

}
