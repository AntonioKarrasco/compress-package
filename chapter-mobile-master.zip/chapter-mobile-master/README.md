# Chapter Mobile

El chapter de mobile reúne a todos los desarrolladores de tecnologías móviles
con el fin de compartir conocimientos, experiencias y problemas comunes así como soluciones comunes.

## Temas

Cada reunión del chapter debe estar enfocado a un tema en específico. El tema puede ser propuesto en la sección de [issues](https://github.com/gbmdigital/chapter-mobile/issues). Algunos de los temas de interés de nuestro chapter son:

 - Tecnologías
 - Buenas prácticas de programación
 - Estándares de desarrollo
 - Patrones de diseño
 - Code Smells
 - Visión del área
 - Seguimiento de temas anteriores
 - Entre otros... [propón un tema :)](https://github.com/gbmdigital/chapter-mobile/issues)

## Formatos

En el caso de los formatos, los chapters pueden ser en formato **Abierto**, **Plática o presentación**, **Seguimiento** o **Demo**. A continuación se describe el propósito de cada formato.

 - **Abierto**: El objetivo es definir un tema a tratar de debatirlo entre todos con el fin de escuchar los diferentes puntos de vista acerca de el tema del día.
 - **Plática**: En una plática se busca que una persona exponga un tema que conozca mientras que los demás escuchamos atentamente. Al final de cada plática se realizan preguntas o comentario.
 - **Seguimiento**: En ocasiones será necesario hablar sobre la situación del área en general y se propondrán mejoras que podamos aplicar en común. El propósito de un chapter de seguimiento es tal cual revisar avances o dudas acerca del acuerdo al que se llegó en algún punto.
 - **Demo**: Las demostraciones tienen el propósito de mostrar a los demás cómo funciona una tecnología en específico.

## Temas

#1 [Amazon SNS Mobile Push [19/09/2017]](https://github.com/gbmdigital/chapter-mobile/blob/master/Amazon%20SNS%20Mobile%20Push.md) by Antonio Trejo <br/>
#2 [Dependency Injection iOS [24/10/2017]](https://github.com/gbmcode/chapter-mobile/blob/master/DependencyInjection.md) by Antonio Trejo <br/>


## Xcode Templates
 
 - cd ~/Library/Developer/Xcode/Templates/
 - copy template