//
//  GetUserKey.swift
//  Account
//
//  Created by gbmlocaladmin on 07/03/18.
//  Copyright © 2018 GBM. All rights reserved.
//

import Foundation
import ApiGateway

public typealias LoginAccountUseCaseCompletionHandler = (_ userKey: Result<Account.ViewModel>) -> Void

public protocol LoginAccountUseCase {
    func login(parameters: Account.Request, completion: @escaping LoginAccountUseCaseCompletionHandler)
}

public class LoginAccountImplementation: LoginAccountUseCase {
    let accountGateway: AccountGateway
    
    init(accountGateway: AccountGateway) {
        self.accountGateway = accountGateway
    }
    
    public func login(parameters: Account.Request, completion: @escaping LoginAccountUseCaseCompletionHandler) {
        self.accountGateway.loginAccount(parameters: parameters) { (result) in
            completion(result)
        }
    }
}
