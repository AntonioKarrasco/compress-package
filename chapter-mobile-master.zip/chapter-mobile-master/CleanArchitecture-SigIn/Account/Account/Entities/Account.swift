//
//  UserKey.swift
//  Account
//
//  Created by gbmlocaladmin on 07/03/18.
//  Copyright © 2018 GBM. All rights reserved.
//

import UIKit
import ApiGateway

public enum Account {
    public struct Response: Decodable, InitializableWithData {
        public let alias: String
        public let firstName: String
        public let hash: String
        public let name: String
        public let statusId: Int
        public let token: String
        public let user: Int
        
        public init(data: Data?) throws {
            guard let data = data else { throw NSError.createParseError() }
            self = try Account.Response.decode(data: data)
        }
        
        public var viewModel: ViewModel {
            return ViewModel(alias: alias,
                             firstName: firstName,
                             hash: hash,
                             name: name,
                             statusId: statusId,
                             token: token,
                             user: user)
        }
    }
    
    public struct Request: Encodable {
        public let user: String
        public let code: String
        public let device: Int
    }
    
    public struct ViewModel {
        public let alias: String
        public let firstName: String
        public let hash: String
        public let name: String
        public let statusId: Int
        public let token: String
        public let user: Int
    }
}
