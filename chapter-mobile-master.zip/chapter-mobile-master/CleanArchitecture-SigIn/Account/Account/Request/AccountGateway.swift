//
//  AccountGateway.swift
//  Account
//
//  Created by gbmlocaladmin on 07/03/18.
//  Copyright © 2018 GBM. All rights reserved.
//

import UIKit
import ApiGateway

public typealias LoginGatewayCompletion = (_ account: Result<Account.ViewModel>) -> Void

public protocol AccountGateway {
    func loginAccount(parameters: Account.Request, completion: @escaping LoginGatewayCompletion)
}
