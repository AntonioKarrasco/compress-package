//
//  ApiAccountGateway.swift
//  Account
//
//  Created by gbmlocaladmin on 07/03/18.
//  Copyright © 2018 GBM. All rights reserved.
//

import UIKit
import ApiGateway

public  protocol ApiAccountGateway: AccountGateway {
   
}

public  class ApiAccountGatewayImplementation: ApiAccountGateway {
    public let apiClient: ApiClient
    
    public init(apiClient: ApiClient) {
        self.apiClient = apiClient
    }
    
    public func loginAccount(parameters: Account.Request, completion: @escaping LoginGatewayCompletion) {
        let accountApiRequest = AccountApiRequest(loginAccountParameters: parameters)
        apiClient.execute(request: accountApiRequest) { (result: Result<ApiResponse<Account.Response>>) in
            switch result {
            case let .success(response):
                let account = response.entity.viewModel
                completion(.success(account))
            case let .failure(error):
                completion(.failure(error))
            }
        }
    }
}
