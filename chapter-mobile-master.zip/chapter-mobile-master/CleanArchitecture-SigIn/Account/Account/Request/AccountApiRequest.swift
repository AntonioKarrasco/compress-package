//
//  AccountApiRequest.swift
//  Account
//
//  Created by gbmlocaladmin on 07/03/18.
//  Copyright © 2018 GBM. All rights reserved.
//

import UIKit
import ApiGateway


public struct AccountApiRequest: ApiRequest {
    public let loginAccountParameters: Account.Request
    
    public var urlRequest: URLRequest {
        let url: URL! = URL(string: host.yodlee + "/api/v1/account/session/login")
        var request = URLRequest(url: url)
        ApiClient2.addDefaultHeaders(request: &request)
        request.httpMethod = HttpMethod.POST
        
        do {
            request.httpBody = try loginAccountParameters.encode()
        } catch let error {
            ApiLog.error(error.localizedDescription)
        }
        return request
    }
}

public struct host {
    static let gbm = "https://api.gbmfondos.com.mx"
    static let yodlee = "https://api.gbmfondos.com.mx"
}

public struct HttpMethod {
    static let GET = "GET"
    static let POST = "POST"
    static let PUT = "PUT"
    static let DELETE = "DELETE"
}

public class ApiClient2 {
    public static func addDefaultHeaders(request: inout URLRequest) {
        request.addValue("application/json;charset=UTF-8", forHTTPHeaderField: "Content-Type")
        request.addValue("application/json, text/plain, */*", forHTTPHeaderField: "Accept")
        request.addValue("gzip", forHTTPHeaderField: "Accept-Encoding")
    }
}
