//
//  LoginPresenter.swift
//  Account
//
//  Created by gbmlocaladmin on 07/03/18.
//  Copyright © 2018 GBM. All rights reserved.
//

import UIKit
import ApiGateway

protocol LoginAccountView: class {
    func displaySuccesLoginAccount(title: String, message: String)
    func displayFailLoginAccount(title: String, message: String)
}

protocol LoginAccountPresenterDelegate: class {
    func loginAccountPresenter(_ presenter: LoginAccountPresenter, didLogin account: Account)
}

protocol LoginAccountPresenter {
    var router: LoginAccountViewRouter { get }
    func loginButtonPressed(parameters: Account.Request)
}

class LoginAccountPresenterImplementation: LoginAccountPresenter {
    fileprivate weak var view: LoginAccountView?
    fileprivate var loginAccountUseCase: LoginAccountUseCase
    fileprivate weak var delegate: LoginAccountPresenterDelegate?
    private(set) var router: LoginAccountViewRouter
    
    init(view: LoginAccountView,
         loginAccountUseCase: LoginAccountUseCase,
         router: LoginAccountViewRouter,
         delegate: LoginAccountPresenterDelegate?) {
        
        self.view = view
        self.loginAccountUseCase = loginAccountUseCase
        self.router = router
        self.delegate = delegate
    }
    
    func loginButtonPressed(parameters: Account.Request) {
        loginAccountUseCase.login(parameters: parameters) { (result) in
            switch result {
            case let .success(account):
                //self.handleLoginSuccess(account)
                view?.displaySuccesLoginAccount(title: "Usuario Logeado", message: "Bienvenido " + account.firstName)
                
            case let .failure(error):
               self.handleLoginAccountError(error)
                break
            }
        }
    }
    
    fileprivate func handleLoginSuccess(_ account: Account.ViewModel) {
        view?.displaySuccesLoginAccount(title: "Usuario Logeado", message: "Bienvenido " + account.firstName)
    }
    
    fileprivate func handleLoginAccountError(_ error: ApiError) {
        guard let errorMessage = error.friendlyMessage else { return }
        view?.displayFailLoginAccount(title: "Ups!", message: errorMessage)
    }
}
