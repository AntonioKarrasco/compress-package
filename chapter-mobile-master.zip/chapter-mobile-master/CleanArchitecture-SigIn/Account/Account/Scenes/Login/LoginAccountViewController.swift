//
//  LoginViewController.swift
//  Account
//
//  Created by gbmlocaladmin on 07/03/18.
//  Copyright © 2018 GBM. All rights reserved.
//

import UIKit
import Swinject
import ApiGateway

class LoginAccountViewController: UIViewController {
    var presenter: LoginAccountPresenter!
    var configurator = LoginAccountConfiguratorImplementation()
    
    // MARK: - IBOutlets
    @IBOutlet var txtUser: UITextField!
    @IBOutlet var txtPassword: UITextField!
    
    let container = Container()

    // MARK: - LoginAccountViewController
    override func viewDidLoad() {
        super.viewDidLoad()
        
        configurator.configure(loginAccountViewController: self)
        
        registrationContainer()
        useDependencies()
    }

    @IBAction func loginButtonPresedded(_ sender: Any) {
        let loginAccountParameters = Account.Request(user: txtUser.text!, code: txtPassword.text!, device: 1)
        presenter.loginButtonPressed(parameters: loginAccountParameters)
    }
    
    fileprivate func registrationContainer() {
        container.register(Animal.self) { _ in Cat(name: "Mimi") }
        container.register(Animal.self) { _, name in
            Horse(name: name)
        }
        container.register(Animal.self) { _, name, running in
            Horse(name: name, running: running)
        }
        
        container.register(Person.self) { r in
            PetOwner(name: "Stephen", pet: r.resolve(Animal.self)!)
        }
    }
    
    fileprivate func useDependencies() {
        let animal = container.resolve(Animal.self)!
        let animal1 = container.resolve(Animal.self, argument: "Spirit")!
        let animal2 = container.resolve(Animal.self, arguments: "Lucky", true)!
        let animal3 = container.resolve(Animal.self)!
        let person = container.resolve(Person.self)!
        let pet = (person as! PetOwner).pet
        
        print(animal.name) // prints "Mimi"
        print(animal3.name) // prints "Mimi"
        print(animal is Cat) // prints "true"
        print(animal1.name) // prints "Spirit"
        print((animal1 as! Horse).running) // prints "false"
        print(animal1 is Horse) // prints "true"
        print(animal2.name) // prints "Lucky"
        print((animal2 as! Horse).running) // prints "true"
        print(person.name) // prints "Stephen"
        print(person is PetOwner) // prints "true"
        print(pet.name) // prints "Mimi"
        print(pet is Cat) // prints "true"
        
        ApiLog.info(pet.name)
    }
}

extension LoginAccountViewController: LoginAccountView {
    func displaySuccesLoginAccount(title: String, message: String) {
        presentAlert(withTitle: title, message: message)
    }
    
    func displayFailLoginAccount(title: String, message: String) {
        presentAlert(withTitle: title, message: message)
    }
}

protocol Animal {
    var name: String { get }
}
protocol Person {
    var name: String { get }
}

class Cat: Animal {
    let name: String
    
    init(name: String) {
        self.name = name
    }
}

class Horse: Animal {
    let name: String
    let running: Bool
    
    convenience init(name: String) {
        self.init(name: name, running: false)
    }
    
    init(name: String, running: Bool) {
        self.name = name
        self.running = running
    }
}

class PetOwner: Person {
    let name: String
    let pet: Animal
    
    init(name: String, pet: Animal) {
        self.name = name
        self.pet = pet
    }
}
