//
//  LoginViewRouter.swift
//  Account
//
//  Created by gbmlocaladmin on 07/03/18.
//  Copyright © 2018 GBM. All rights reserved.
//

import UIKit

protocol LoginAccountViewRouter: ViewRouter {
    func presentSuccessLogin(account: Account)
}

class LoginAccountViewRouterImplementation: LoginAccountViewRouter {
    fileprivate weak var loginAccoutViewController: LoginAccountViewController?
    
    init(loginAccoutViewController: LoginAccountViewController) {
        self.loginAccoutViewController = loginAccoutViewController
    }
    
    func presentSuccessLogin(account: Account) {
        
    }
}

extension LoginAccountViewRouterImplementation: LoginAccountView {
    func displaySuccesLoginAccount(title: String, message: String) {
        self.loginAccoutViewController?.presentAlert(withTitle: title, message: message)
    }
    
    func displayFailLoginAccount(title: String, message: String) {
        self.loginAccoutViewController?.presentAlert(withTitle: title, message: message)
    }
}
