//
//  LoginConfigurator.swift
//  Account
//
//  Created by gbmlocaladmin on 07/03/18.
//  Copyright © 2018 GBM. All rights reserved.
//

import UIKit
import ApiGateway

protocol LoginAccountConfigurator {
    func configure(loginAccountViewController: LoginAccountViewController)
}

class LoginAccountConfiguratorImplementation: LoginAccountConfigurator {
    func configure(loginAccountViewController: LoginAccountViewController) {
        let apiClient = ApiClientImplementation()
        let apiAccountGateway = ApiAccountGatewayImplementation(apiClient: apiClient)
        
        let loginAccountUseCase = LoginAccountImplementation(accountGateway: apiAccountGateway)
        
        //Router
        let router = LoginAccountViewRouterImplementation(loginAccoutViewController: loginAccountViewController)
        
        //Presenter
        let preseneter = LoginAccountPresenterImplementation(view: loginAccountViewController,
                                                             loginAccountUseCase: loginAccountUseCase,
                                                             router: router,
                                                             delegate: nil)
        
        loginAccountViewController.presenter = preseneter
    }
}
