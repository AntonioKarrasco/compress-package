//
//  ViewController.swift
//  Account
//
//  Created by gbmlocaladmin on 08/03/18.
//  Copyright © 2018 GBM. All rights reserved.
//

import UIKit

extension UIViewController {
    func presentAlert(withTitle title:String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Ok", style: .cancel, handler: nil))
        
        DispatchQueue.main.async {
            self.present(alert, animated: true, completion: nil)
        }
    }
}
