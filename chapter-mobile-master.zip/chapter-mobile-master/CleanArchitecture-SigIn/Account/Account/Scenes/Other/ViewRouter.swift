//
//  ViewRouter.swift
//  Account
//
//  Created by gbmlocaladmin on 08/03/18.
//  Copyright © 2018 GBM. All rights reserved.
//

import UIKit

protocol ViewRouter {
    func prepare(for segue: UIStoryboardSegue, sender: Any?)
}

extension ViewRouter {
    func prepare(for segue: UIStoryboardSegue, sender: Any?) { }
}
