//
//  APIResponse.swift
//  ApiGateway
//
//  Created by gbmlocaladmin on 06/03/18.
//  Copyright © 2018 GBM. All rights reserved.
//

import UIKit

public protocol InitializableWithData {
    init(data: Data?) throws
}

public struct ApiParseError: Error {
    public static let code = 999
    public let error: Error
    public let httpUrlResponse: HTTPURLResponse
    public let data: Data?
    
    public var localizedDescription: String {
        return error.localizedDescription
    }
}

public struct ApiResponse<T: InitializableWithData> {
    public let entity: T
    public let httpUrlResponse: HTTPURLResponse
    public let data: Data?
    
    init(data: Data?, httpUrlResponse: HTTPURLResponse) throws {
        do {
            self.entity = try T(data: data)
            self.httpUrlResponse = httpUrlResponse
            self.data = data
        } catch {
            throw ApiParseError(error: error, httpUrlResponse: httpUrlResponse, data: data)
        }
    }
}
