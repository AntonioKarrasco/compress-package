//
//  APIClient.swift
//  ApiGateway
//
//  Created by gbmlocaladmin on 06/03/18.
//  Copyright © 2018 GBM. All rights reserved.
//

import Foundation

public enum StatusCode: Int {
    case success             = 200
    case badRequest          = 400
    case unauthorized        = 401
    case forbidden           = 403
    case notFound            = 404
    case internalServerError = 500
}

public protocol ApiClient {
    func execute<T>(request: ApiRequest, completion: @escaping (_ result: Result<ApiResponse<T>>) -> Void)
}

public protocol URLSessionProtocol {
    func dataTask(with request: URLRequest, completionHandler: @escaping (Data?, URLResponse?, Error?) -> Void) -> URLSessionDataTask
}

extension URLSession: URLSessionProtocol { }

public class ApiClientImplementation: NSObject, ApiClient {
    public static let timeOut = 240.0
    var urlSession: URLSessionProtocol!
    
    public override init() {
        super.init()
        urlSession = URLSession(configuration: configuration, delegate: self, delegateQueue: nil)
    }
    
    public init(urlSession: URLSessionProtocol) {
        self.urlSession = urlSession
    }
    
    public func execute<T>(request: ApiRequest, completion: @escaping (Result<ApiResponse<T>>) -> Void) {
        let urlRequest = request.urlRequest
        ApiLog.info("Url: \(urlRequest.url!)")
        ApiLog.info("Headers: \(urlRequest.allHTTPHeaderFields!)")
        ApiLog.info("Method: \(urlRequest.httpMethod!)")
        
        let dataTask = urlSession.dataTask(with: request.urlRequest) { (data, response, error) in
            guard let httpUrlResponse = response as? HTTPURLResponse else {
                completion(.failure(ApiError.networkRequestError))
                return
            }
            
            ApiLog.info("StatusCode: \(httpUrlResponse.statusCode)")
            
            if httpUrlResponse.statusCode == StatusCode.success.rawValue {
                do {
                    let response = try ApiResponse<T>(data: data, httpUrlResponse: httpUrlResponse)
                    DispatchQueue.main.async {
                        completion(.success(response))
                    }
                } catch {
                    DispatchQueue.main.async {
                        completion(.failure(ApiError.unexpectedError))
                    }
                }
            } else {
                DispatchQueue.main.async {
                    completion(.failure(ApiError(data: data)))
                }
            }
        }
        dataTask.resume()
    }
    
    var configuration: URLSessionConfiguration {
        get {
            let configuration = URLSessionConfiguration.default
            configuration.timeoutIntervalForRequest = ApiClientImplementation.timeOut
            configuration.timeoutIntervalForResource = ApiClientImplementation.timeOut
            
            return configuration
        }
    }
}

extension ApiClientImplementation: URLSessionDelegate {
    //MARK: URLSessionDelegate
    public func urlSession(_ session: URLSession, didReceive challenge: URLAuthenticationChallenge, completionHandler: @escaping (URLSession.AuthChallengeDisposition, URLCredential?) -> Void) {
        if challenge.protectionSpace.authenticationMethod == NSURLAuthenticationMethodServerTrust {
            challenge.sender!.use(URLCredential(trust: challenge.protectionSpace.serverTrust!), for: challenge)
            challenge.sender!.continueWithoutCredential(for: challenge)
        }
        if challenge.previousFailureCount > 0 {
            completionHandler(Foundation.URLSession.AuthChallengeDisposition.cancelAuthenticationChallenge, nil)
        } else if let serverTrust = challenge.protectionSpace.serverTrust {
            completionHandler(Foundation.URLSession.AuthChallengeDisposition.useCredential, URLCredential(trust: serverTrust))
        }
    }
}
