//
//  ApiCodable.swift
//  ApiGateway
//
//  Created by gbmlocaladmin on 07/03/18.
//  Copyright © 2018 GBM. All rights reserved.
//

import UIKit

extension Decodable {
    public static func decode(data: Data) throws -> Self {
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .customCodableDate
        do {
            return try decoder.decode(Self.self, from: data)
            
        } catch let error {
            ApiLog.error(error.localizedDescription)
        }
        return try decoder.decode(Self.self, from: data)
    }
}

extension Encodable {
    public func encode() throws -> Data {
        let encoder = JSONEncoder()
        encoder.outputFormatting = .prettyPrinted
        return try encoder.encode(self)
    }
}

extension JSONDecoder.DateDecodingStrategy {
    static let customCodableDate = custom({ decoder -> Date in
        let container = try decoder.singleValueContainer()
        let string = try container.decode(String.self)
        if #available(iOS 10.0, *) {
            if let date = Formatter.baseFormatCodable.date(from: string) ?? ISO8601DateFormatter().date(from: string) {
                return date
            }
        } else {
            // Fallback on earlier versions
        }
        throw DecodingError.dataCorruptedError(in: container, debugDescription: "Invalid date: \(string)")
    })
}
