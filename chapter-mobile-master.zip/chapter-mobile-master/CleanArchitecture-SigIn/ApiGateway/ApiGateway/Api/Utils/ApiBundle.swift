//
//  ApiBundle.swift
//  ApiGateway
//
//  Created by gbmlocaladmin on 06/03/18.
//  Copyright © 2018 GBM. All rights reserved.
//

import UIKit

extension Bundle {
    public var bundleName: String {
        let bundle = Bundle(for: ApiLog.self)
        return bundle.infoDictionary?["CFBundleName"] as? String ?? ""
    }
}
