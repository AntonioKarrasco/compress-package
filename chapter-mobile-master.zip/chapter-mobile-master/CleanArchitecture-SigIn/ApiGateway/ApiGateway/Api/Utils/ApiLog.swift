//
//  APILog.swift
//  ApiGateway
//
//  Created by gbmlocaladmin on 06/03/18.
//  Copyright © 2018 GBM. All rights reserved.
//

import UIKit

public enum LogType : String {
    case info  = "info"
    case error = "error"
}

public class ApiLog {
    public static func info(_ message : String) {
        log(message, logType: .info)
    }
    
    public static func error(_ message : String) {
        log(message, logType: .error)
    }
    
    private static func log(_ message : String, logType : LogType) {
        let bundle = Bundle(for: ApiLog.self)
        var completeMessage = bundle.bundleName
        completeMessage += " "
        completeMessage += ApiDate.currentDateToString
        completeMessage += " "
        completeMessage += logType.rawValue
        completeMessage += " "
        completeMessage += message
        print(completeMessage)
    }
}
