//
//  ApiError.swift
//  ApiGateway
//
//  Created by gbmlocaladmin on 06/03/18.
//  Copyright © 2018 GBM. All rights reserved.
//

import UIKit

public struct ApiError: Decodable {
    public var code            : String?
    public var eventId         : String?
    public var message         : String?
    public var friendlyMessage : String?
    public var origin          : String?
    public var type            : String
    
    public static var unexpectedError : ApiError {
        get {
            return ApiError(code: "0",
                            eventId: "0",
                            friendlyMessage: "Unexpected error",
                            message: "Unexpected error",
                            origin: "",
                            type: "")
        }
    }
    
    public static var networkRequestError : ApiError {
        get {
            return ApiError(code: "0",
                            eventId: "0",
                            friendlyMessage: "Network request error - no other information",
                            message: "Network request error - no other information",
                            origin: "",
                            type: "")
        }
    }
    
    public init(friendlyMessage:String){
        self.code            = "0"
        self.eventId         = "0"
        self.friendlyMessage = friendlyMessage
        self.message         = "Unexpected error"
        self.origin          = ""
        self.type            = ""
    }
    
    public init(code: String, eventId: String, friendlyMessage:String , message: String, origin: String, type: String){
        self.code            = code
        self.eventId         = eventId
        self.friendlyMessage = friendlyMessage
        self.message         = message
        self.origin          = origin
        self.type            = type
    }
    
    public init (data: Data?) {
        guard let data = data else { self = ApiError.unexpectedError ; return }
        do {
            self = try ApiError.decode(data: data)
        } catch let error {
            self = ApiError(friendlyMessage: error.localizedDescription)
        }
    }
}

extension NSError {
    public static func createParseError() -> NSError {
        return NSError(domain: "com.gbm.ApiGateway",
                       code: ApiParseError.code,
                       userInfo: [NSLocalizedDescriptionKey: "A parsing error occured"])
    }
}
