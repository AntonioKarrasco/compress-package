//
//  StoreValue.swift
//  SNS_MobileAnalytics_Sample
//
//  Created by GBM Mobile on 10/3/17.
//  Copyright © 2017 Amazon Web Services. All rights reserved.
//

import Foundation

class StoreValue{
    
    private static let KeyToken = "deviceToken"
    private static let KeyEndpointArn = "endpointArn"
    private static let KeySubscriptionArn = "subscriptionArn"
    
    static func token() -> String{
    
        return UserDefaults.standard.string(forKey:KeyToken) ?? "";
        //return "4d7ba733300e6935445ff2c7911b30557954230b1acb012c8f5d7a3f6ae14018"
        
    }
    
    static func setToken(value : String){
        
        UserDefaults.standard.set(value, forKey: KeyToken)
        UserDefaults.standard.synchronize()
        
    }

    
    static func endpointArn() -> String{
    
        return UserDefaults.standard.string(forKey:"endpointArn") ?? "";
        //return "arn:aws:sns:us-east-1:289552524591:endpoint/APNS_SANDBOX/TestPush/225874d8-6b93-33fb-bfdb-b73ff9eed4ed"
        
    }
    
    static func subscriptionArn(topic : String) -> String{
    
       return UserDefaults.standard.string(forKey:topic) ?? "";
    
    }
    
    static func setEndpointArn(value : String){
    
        UserDefaults.standard.set(value, forKey: KeyEndpointArn)
        UserDefaults.standard.synchronize()
        
    }
    
    static func setSubscriptionArn(topic : String, value : String){
    
        
        UserDefaults.standard.set(value, forKey: topic)
        UserDefaults.standard.synchronize()
        
    
    }

    
}
