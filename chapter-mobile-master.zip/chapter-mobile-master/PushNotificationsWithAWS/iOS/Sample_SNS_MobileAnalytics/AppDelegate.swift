/*
* Copyright 2010-2015 Amazon.com, Inc. or its affiliates. All Rights Reserved.
*
* Licensed under the Apache License, Version 2.0 (the "License").
* You may not use this file except in compliance with the License.
* A copy of the License is located at
*
*  http://aws.amazon.com/apache2.0
*
* or in the "license" file accompanying this file. This file is distributed
* on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
* express or implied. See the License for the specific language governing
* permissions and limitations under the License.
*/

import UIKit
import AWSMobileAnalytics
import AWSSNS

//import Firebase
//import FirebaseMessaging

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    let SNSPlatformApplicationArn = "arn:aws:sns:us-east-1:289552524591:app/APNS_SANDBOX/TestPush"

    var window: UIWindow?

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
        // Configures the appearance
        UINavigationBar.appearance().barTintColor = UIColor.black
        UINavigationBar.appearance().titleTextAttributes = [NSForegroundColorAttributeName:UIColor.white]
        UIApplication.shared.statusBarStyle = UIStatusBarStyle.lightContent

        // Sets up Mobile Push Notification
//        let readAction = UIMutableUserNotificationAction()
//        readAction.identifier = "READ_IDENTIFIER"
//        readAction.title = "Read"
//        readAction.activationMode = UIUserNotificationActivationMode.foreground
//        readAction.isDestructive = false
//        readAction.isAuthenticationRequired = true
//
//        let deleteAction = UIMutableUserNotificationAction()
//        deleteAction.identifier = "DELETE_IDENTIFIER"
//        deleteAction.title = "Delete"
//        deleteAction.activationMode = UIUserNotificationActivationMode.foreground
//        deleteAction.isDestructive = true
//        deleteAction.isAuthenticationRequired = true
//
//        let ignoreAction = UIMutableUserNotificationAction()
//        ignoreAction.identifier = "IGNORE_IDENTIFIER"
//        ignoreAction.title = "Ignore"
//        ignoreAction.activationMode = UIUserNotificationActivationMode.foreground
//        ignoreAction.isDestructive = false
//        ignoreAction.isAuthenticationRequired = false
//
//        let messageCategory = UIMutableUserNotificationCategory()
//        messageCategory.identifier = "MESSAGE_CATEGORY"
//        messageCategory.setActions([readAction, deleteAction], for: UIUserNotificationActionContext.minimal)
//        messageCategory.setActions([readAction, deleteAction, ignoreAction], for: UIUserNotificationActionContext.default)
//
//        let notificationSettings = UIUserNotificationSettings(types: [UIUserNotificationType.badge, UIUserNotificationType.sound, UIUserNotificationType.alert], categories: (NSSet(array: [messageCategory])) as? Set<UIUserNotificationCategory>)
//
//        UIApplication.shared.registerForRemoteNotifications()
//        UIApplication.shared.registerUserNotificationSettings(notificationSettings)
        
        
      
        //let notificationSettings = UserNotificationSettings(forTypes: [.alert, .badge, .sound], categories: nil)
        let notificationSettings = UIUserNotificationSettings(types: [.alert, .badge, .sound], categories: nil)
        application.registerUserNotificationSettings(notificationSettings)
        
        
        if launchOptions != nil{
            
            let msg = "\(String(describing: launchOptions))"
            
            self.alert(msg)
            
            
        }
        
        return true
    }
    
    func alert(_  msg : String){
    
        let alert = UIAlertController(title: "Push Notification", message:msg, preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: "Click", style: UIAlertActionStyle.default, handler: nil))
        let nav =  self.window?.rootViewController as! UINavigationController
        nav.topViewController?.present(alert, animated: true, completion: nil)
    }
    
    func application(_ application: UIApplication, didRegister notificationSettings: UIUserNotificationSettings) {
        if notificationSettings.types != .none {
            application.registerForRemoteNotifications()
        }
    }
    func application(_ application: UIApplication, handleActionWithIdentifier identifier: String?, forRemoteNotification userInfo: [AnyHashable : Any], withResponseInfo responseInfo: [AnyHashable : Any], completionHandler: @escaping () -> Void) {
        
    }
   
    func application(_ application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) {
        
        let token = deviceToken.map { String(format: "%02.2hhx", $0) }.joined()
        
        
        let deviceToken = "\(token)"
            .trimmingCharacters(in: CharacterSet(charactersIn:"<>"))
            .replacingOccurrences(of: " ", with: "")
        print("deviceTokenString: \(deviceToken)")
        StoreValue.setToken(value: deviceToken)
        
      //  mainViewController()?.displayDeviceInfo()
    
//        let sns = AWSSNS.default()
//        let request = AWSSNSCreatePlatformEndpointInput()
//        request?.token = deviceTokenString
//        request?.platformApplicationArn = SNSPlatformApplicationArn
//        
//  
//        //AWSExecutor.mainThreadExecutor()
//        sns.createPlatformEndpoint(request!).continue(with: AWSExecutor.mainThread(), with:  { (task: AWSTask!) -> AnyObject? in
//            
//            if task.error != nil {
//                print("Error: \(String(describing: task.error))")
//            } else {
//                let createEndpointResponse = task.result!
//                print("endpointArn: \(String(describing: createEndpointResponse.endpointArn))")
//                UserDefaults.standard.set(createEndpointResponse.endpointArn, forKey: "endpointArn")
//    //            self.mainViewController()?.displayDeviceInfo()
//            }
//
//            
//            return nil
//            
//        })
    
    }

    func application(_ application: UIApplication, didFailToRegisterForRemoteNotificationsWithError error: Error) {
        print("Failed to register with error: \(error)")
    }

    func application(_ application: UIApplication, didReceiveRemoteNotification userInfo: [AnyHashable: Any]) {
        print("userInfo: \(userInfo)")
        let msg = "\(userInfo)"
        var m = ""
        if let aps = userInfo["aps"] as? NSDictionary {
            if let alert = aps["alert"] as? String {
                
                if let data =  convertToDictionary(alert){
                    if let d = data["data"] as? String{
                        m = d
                    }
                }
                
            }
        }
        
        
        
        self.alert(m)

        
    }
    
    func convertToDictionary(_ text: String) -> [String: Any]? {
        if let data = text.data(using: .utf8) {
            do {
                return try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any]
            } catch {
                print(error.localizedDescription)
            }
        }
        return nil
    }


    func application(_ application: UIApplication, handleActionWithIdentifier identifier: String?, forRemoteNotification userInfo: [AnyHashable: Any], completionHandler: @escaping () -> Void) {
        
//        let mobileAnalytics = AWSMobileAnalytics.default()
//        let eventClient = mobileAnalytics?.eventClient
//        let pushNotificationEvent = eventClient?.createEvent(withEventType: "PushNotificationEvent")
//
//        var action = "Undefined"
//        if identifier == "READ_IDENTIFIER" {
//            action = "Read"
//            print("User selected 'Read'")
//            
//        } else if identifier == "DELETE_IDENTIFIER" {
//            action = "Deleted"
//            print("User selected 'Delete'")
//        } else {
//            action = "Undefined"
//        }
//
//        self.alert(msg: action)
//        
//        pushNotificationEvent?.addAttribute(action, forKey: "Action")
//        eventClient?.record(pushNotificationEvent)
//
//      //  mainViewController()?.displayUserAction(action as NSString)

        completionHandler()
    }


}
