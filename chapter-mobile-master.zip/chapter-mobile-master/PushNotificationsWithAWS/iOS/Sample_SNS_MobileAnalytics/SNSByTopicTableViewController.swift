//
//  SNSByTopicTableViewController.swift
//  SNS_MobileAnalytics_Sample
//
//  Created by GBM Mobile on 9/25/17.
//  Copyright © 2017 Amazon Web Services. All rights reserved.
//

import UIKit

class SNSByTopicTableViewController: UITableViewController {
    lazy var topics = [Topic]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        print("token:\(StoreValue.token())")
        print("endpointArn:\(StoreValue.endpointArn())")
        NetworkApi.awsActionTopics { (topics) in
            
            self.topics = topics
            self.tableView.reloadData()
            
        }
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
//    func awsActionTopics(){
//        
//        let url:NSURL = NSURL(string: "http://192.168.3.1:3000/subscriptions_ios")!
//        let session = URLSession.shared
//        
//        let request = NSMutableURLRequest(url: url as URL)
//        request.httpMethod = "POST"
//        request.cachePolicy = .reloadIgnoringLocalAndRemoteCacheData
//        
//        let paramString = "endpointArn=\(StoreValue.endpointArn())&device=\(StoreValue.token())&employee=7854&app=1"
//        
//        request.httpBody = paramString.data(using: .utf8)
//        
//        let task = session.dataTask(with: request as URLRequest) { data, response, error in
//            
//            guard let _ : Data = data  else {
//                print("error")
//                return
//            }
//            
//            if let parsedData = try? JSONSerialization.jsonObject(with: data!) as! [String:Any] {
//                //print(parsedData.description ?? "no value")
//                let data = parsedData["data"] as! [String:Any]
//                if let values = data["topics"]  as? [[String: Any]] {
//                    for t in values {
//                     
//                        let identifier =  t["topicId"] as! String
//                        let name =  t["name"] as! String
//                        let isSubscribed =  t["isSubscribed"] as! Bool
//                        let item = Topic(identifier:identifier, name: name, isSubscribed: isSubscribed)
//                        self.topics.append(item)
//                        
//                    }
//                    
//                    DispatchQueue.main.async {
//                        
//                    }
//                }
//                
//            }
//            
//
//            
//        }
//        
//        task.resume()
//
//        
//        
//    }
//    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cellTopic", for: indexPath) as! TopicCell
        let t = topics[indexPath.row]
        cell.name.text = t.name
        cell.subscribed.setOn(t.isSubscribed, animated: false)
        cell.topic = t
        return cell
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return topics.count
    }
    
    

}
