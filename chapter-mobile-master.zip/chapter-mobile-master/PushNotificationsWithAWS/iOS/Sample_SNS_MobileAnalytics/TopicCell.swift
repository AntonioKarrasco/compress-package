//
//  TopicCell.swift
//  SNS_MobileAnalytics_Sample
//
//  Created by GBM Mobile on 10/3/17.
//  Copyright © 2017 Amazon Web Services. All rights reserved.
//

import Foundation

class TopicCell: UITableViewCell {
    
    @IBOutlet weak var name: UILabel!
    
    @IBOutlet weak var subscribed: UISwitch!
    
    var topic : Topic!
    
    func awsActionSubscribe(device : String, topic : Topic, isSubscription : Bool){
        
        let url:NSURL = NSURL(string: "http://192.168.3.1:3000/\(isSubscription ? "subscribe_ios" : "unsubscribe_ios")")!
        let session = URLSession.shared
        
        let request = NSMutableURLRequest(url: url as URL)
        request.httpMethod = "POST"
        request.cachePolicy = .reloadIgnoringLocalAndRemoteCacheData
        
        let subscriptionArn = UserDefaults.standard.string(forKey: topic.identifier) ?? ""
        let paramString = "endpointArn=\(StoreValue.endpointArn())&device=\(device)&topic=\(topic)&subscriptionArn=\(subscriptionArn)&app=1&employee=7854"
        request.httpBody = paramString.data(using: .utf8)
        
        let task = session.dataTask(with: request as URLRequest) { data, response, error in
            
            guard let _d : Data = data  else {
                print("error")
                return
            }
            
            let dataString = String(data: _d, encoding: String.Encoding.utf8)
            
            print(dataString ?? "no value")
            
            if let parsedData = try? JSONSerialization.jsonObject(with: data!) as! [String:Any] {
                
                if isSubscription {
                    
                    StoreValue.setEndpointArn(value: parsedData["endpointArn"] as! String)
                    StoreValue.setSubscriptionArn(topic:topic.identifier, value: parsedData["subscriptionArn"]  as! String)
                    topic.isSubscribed = true
                    
                }else{
                    
                    StoreValue.setSubscriptionArn(topic:topic.identifier, value: "")
                    topic.isSubscribed = false
                    
                }
                
            }
            
        }
        
        task.resume()
        
        
    }

    @IBAction func changeValue(_ sender: UISwitch) {
        
        awsActionSubscribe(device:StoreValue.token(), topic:topic, isSubscription:sender.isOn ? true : false)

        
        
    }
    
}
