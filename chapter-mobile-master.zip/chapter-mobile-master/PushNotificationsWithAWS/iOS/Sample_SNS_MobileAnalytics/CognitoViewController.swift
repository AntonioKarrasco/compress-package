//
//  CognitoViewController.swift
//  SNS_MobileAnalytics_Sample
//
//  Created by GBM Mobile on 9/18/17.
//  Copyright © 2017 Amazon Web Services. All rights reserved.
//

import UIKit
import AWSCognito

class CognitoViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        let credentialsProvider = AWSCognitoCredentialsProvider(regionType:.usEast1,
                                                                identityPoolId:"us-east-1:7f667e96-a365-46d3-beba-5a4db0d2b210")
        
        let configuration = AWSServiceConfiguration(region:.usEast1, credentialsProvider:credentialsProvider)
        
        AWSServiceManager.default().defaultServiceConfiguration = configuration
        
        // Initialize the Cognito Sync client
        let syncClient = AWSCognito.default()
        
        // Create a record in a dataset and synchronize with the server
        let dataset = syncClient?.openOrCreateDataset("myDataset")
        dataset?.setString("myValue", forKey:"myKey")
        dataset?.synchronize().continue({ (task: AWSTask!) -> Any? in
            
             return nil
        })

        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
