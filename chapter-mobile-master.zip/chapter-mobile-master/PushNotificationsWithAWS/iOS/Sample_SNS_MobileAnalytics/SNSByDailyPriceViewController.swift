//
//  SNSByDailyPriceViewController.swift
//  SNS_MobileAnalytics_Sample
//
//  Created by GBM Mobile on 10/24/17.
//  Copyright © 2017 Amazon Web Services. All rights reserved.
//

import Foundation
import UIKit

class SNSByDailyPriceViewController: UIViewController {
    
    @IBOutlet weak var issueIdField: UITextField?
    @IBOutlet weak var datePicker: UIDatePicker?
    
    @IBAction func addNotification(_ sender: Any) {
        
         print("addNotification")
        
        NetworkApi.awsSubscriptionsInDailyPrice { (success) in
            
        }
        
        
    }
    
}
