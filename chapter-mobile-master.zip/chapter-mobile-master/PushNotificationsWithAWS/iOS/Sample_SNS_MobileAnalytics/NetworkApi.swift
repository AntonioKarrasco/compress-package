//
//  NetworkApi.swift
//  SNS_MobileAnalytics_Sample
//
//  Created by GBM Mobile on 10/24/17.
//  Copyright © 2017 Amazon Web Services. All rights reserved.
//

import Foundation

struct Method {
    static let GET = "GET"
    static let POST = "POST"
}

struct NetworkApi {

    static let API_URL = "http://192.168.3.1:3000/"
    
    static var employeeId = "7854"
    static var appId = "1"
    
    static func REQUEST(url : String, param: String, method: String, completionHandler:@escaping (Data) -> ()){
        
        let url:NSURL = NSURL(string: API_URL + "subscriptions_ios")!
        let session = URLSession.shared
        
        let request = NSMutableURLRequest(url: url as URL)
        request.httpMethod = "POST"
        request.cachePolicy = .reloadIgnoringLocalAndRemoteCacheData
        
        let paramString = "endpointArn=\(StoreValue.endpointArn())&device=\(StoreValue.token())&employee=\(NetworkApi.employeeId)&app=\(NetworkApi.appId)"
        
        request.httpBody = paramString.data(using: .utf8)
        
        let task = session.dataTask(with: request as URLRequest) { data, response, error in
            
            guard let _d : Data = data  else {
                print("error")
                 completionHandler(Data())
                return
            }
            
            completionHandler(_d)
            
          
            
        } // end task
        
        task.resume()
        
    }
    
    static func POST(url : String, param: String, completionHandler:@escaping (Data) -> ()){
        
        REQUEST(url:url, param:param, method: Method.POST) { (data) in
             completionHandler(data)
        }
        
    } // end POST
    
    static func GET(url : String, completionHandler:@escaping (Data) -> ()){
     
        REQUEST(url:url, param:"", method: Method.GET) { (data) in
            completionHandler(data)
        }
    } // end GET
    
    static func awsActionTopics(completionHandler:@escaping ([Topic]) -> ()){
       
        let paramString = "endpointArn=\(StoreValue.endpointArn())&device=\(StoreValue.token())&employee=\(NetworkApi.employeeId)&app=\(NetworkApi.appId)"
        POST(url: "subscriptions_ios", param: paramString) { (data) in
            
            if let parsedData = try? JSONSerialization.jsonObject(with: data) as! [String:Any] {
                
                print(parsedData.description)
                
                let data = parsedData["data"] as! [String:Any]
                if let values = data["topics"]  as? [[String: Any]] {
                    
                    var topics : [Topic] = []
                    
                    for t in values {
                        
                        let identifier =  t["topicId"] as! String
                        let name =  t["name"] as! String
                        let isSubscribed =  t["isSubscribed"] as! Bool
                        let item = Topic(identifier:identifier, name: name, isSubscribed: isSubscribed)
                        topics.append(item)
                        
                    }
                    
                    DispatchQueue.main.async {
                       
                         completionHandler(topics)
                        
                    }
                }
                
            }
            
        }
        
    } // end awsActionTopics
    
    static func awsSubscribeByDailyPrice(completionHandler:@escaping (Bool) -> ()){
        
         let paramString = "endpointArn=\(StoreValue.endpointArn())&device=\(StoreValue.token())&employee=\(NetworkApi.employeeId)&app=\(NetworkApi.appId)"
        POST(url: "subscribe_daily_price", param: paramString) { (data) in
            
        }
        
    }
    
    static func awsSubscriptionsInDailyPrice(completionHandler:@escaping (Bool) -> ()){
        
        //let paramString = "endpointArn=\(StoreValue.endpointArn())&device=\(StoreValue.token())&employee=\(NetworkApi.employeeId)&app=\(NetworkApi.appId)"
        GET(url: "subscriptions_in_daily_price") { (data) in
            
        }
        
    }
    
}
