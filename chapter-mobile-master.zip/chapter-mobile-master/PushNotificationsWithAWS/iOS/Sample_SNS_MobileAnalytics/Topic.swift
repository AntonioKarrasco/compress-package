//
//  Topic.swift
//  SNS_MobileAnalytics_Sample
//
//  Created by GBM Mobile on 10/3/17.
//  Copyright © 2017 Amazon Web Services. All rights reserved.
//

import Foundation

class Topic{
    
    lazy var identifier : String = String()
    lazy var name : String  = String()
    lazy var isSubscribed : Bool = false
    
    init(identifier : String, name : String, isSubscribed : Bool) {
        
        self.identifier = identifier
        self.name = name
        self.isSubscribed = isSubscribed
        
    }
    
}
