package hbpro.gbmmobile.com.androidnotifications;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;

import com.rw.velocity.Velocity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * Created by mobile on 10/2/17.
 */

public class TopicAdapter extends RecyclerView.Adapter <TopicAdapter.ItemViewTopic> {

    ArrayList <Topic> allTopics;
    private Context context;

    public TopicAdapter(ArrayList <Topic> allTopics, Context context) {
        this.allTopics = allTopics;
        this.context = context;
    }



    @Override
    public TopicAdapter.ItemViewTopic onCreateViewHolder(ViewGroup parent, int viewType) {

        Context context = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);

        View view = inflater.inflate(R.layout.item_sns_by_topic, parent, false);

        ItemViewTopic viewHolder = new ItemViewTopic(view);
        return viewHolder;

    }


    private Context getContext() {
        return context;
    }

    @Override
    public void onBindViewHolder(TopicAdapter.ItemViewTopic holder, int position) {

        final Topic t = allTopics.get(position);
        holder.subscribed.setText(t.name);
        holder.subscribed.setChecked(t.isSubscribed);

        holder.subscribed.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, final boolean isChecked) {

                Log.i("chcecked", "gogo");
                String endpointArn = StoreValue.getInstance(null).endpointArn();
                String token = StoreValue.getInstance(null).token();
                String subscriptionArn = StoreValue.getInstance(null).subscriptionArn(t.identifier);

                Log.i("topic: ", t.name);
                Log.i("token: ", token);
                Log.i("endpointArn: ", endpointArn);
                Log.i("subscriptionArn: ", subscriptionArn);

                String url = "http://192.168.3.1:3000/" + (isChecked ? "subscribe_android" : "unsubscribe_android");
                Velocity.post(url)
                        .withFormData("endpointArn", endpointArn)
                        .withFormData("device", token)
                        .withFormData("topic", t.identifier)
                        .withFormData("subscriptionArn", subscriptionArn)
                        .withFormData("app", "1")
                        .connect(new Velocity.ResponseListener() {
                            @Override
                            public void onVelocitySuccess(Velocity.Response response) {

                                if (response.responseCode == 200){

                                    try {

                                        Log.i("response", response.body);
                                        JSONObject jsonObj = new JSONObject(response.body);
                                        String subscriptionArn = jsonObj.getString("subscriptionArn");
                                        String endpointArn = jsonObj.getString("endpointArn");
                                        if (isChecked) {

                                            StoreValue.getInstance(null).setSubscriptionArn(t.identifier, subscriptionArn);
                                            StoreValue.getInstance(null).setEndpointArn(endpointArn);

                                        }else{

                                            StoreValue.getInstance(null).setSubscriptionArn(t.identifier, "");

                                        }


                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                    }


                                }else{

                                }


                            }

                            @Override
                            public void onVelocityFailed(Velocity.Response error) {

                                Log.i("error", error.toString());

                            }

                        });




            }
        });

    }




    @Override
    public int getItemCount() {
        return this.allTopics.size();
    }

    class ItemViewTopic extends RecyclerView.ViewHolder{

        public Switch subscribed;

        public ItemViewTopic(View itemView) {

            super(itemView);

            subscribed = (Switch) itemView.findViewById(R.id.subscribed);

        }


    }


}
