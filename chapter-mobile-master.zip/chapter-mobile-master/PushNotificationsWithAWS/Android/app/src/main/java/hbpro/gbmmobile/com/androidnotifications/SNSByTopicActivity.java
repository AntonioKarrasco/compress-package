package hbpro.gbmmobile.com.androidnotifications;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.Switch;

import com.rw.velocity.Velocity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import static hbpro.gbmmobile.com.androidnotifications.MessageReceivingService.PREFS_NAME;
import static java.lang.System.in;

/**
 * Created by mobile on 9/28/17.
 */

public class SNSByTopicActivity extends AppCompatActivity {

    ArrayList <Topic> allTopics = new ArrayList<>();
    RecyclerView recyclerTopics;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sns_by_topic);
        StoreValue.getInstance(getApplicationContext());
        Velocity.initialize(3);

        recyclerTopics = (RecyclerView) findViewById(R.id.recycler);
        recyclerTopics.setLayoutManager(new LinearLayoutManager(this));

        awsActionTopics();

    }

    @Override
    protected void onResume() {
        super.onResume();
        OptionsActivity.context = this;

    }

    void awsActionTopics(){

        String endpointArn =  StoreValue.getInstance(null).endpointArn();
        String token = StoreValue.getInstance(null).token();
        Log.i("token: ", token);
        Log.i("endpointArn: ", endpointArn);

        final SNSByTopicActivity activity = this;
        String url = "http://192.168.3.1:3000/subscriptions_android";
        Velocity.post(url)
                .withFormData("endpointArn", endpointArn)
                .withFormData("device", token)
                .withFormData("employee", "67891")
                .withFormData("app", "1")
                .connect(new Velocity.ResponseListener() {
                    @Override
                    public void onVelocitySuccess(Velocity.Response response) {



                        if (response.responseCode == 200){

                            try {

                                Log.i("response", response.body);
                                JSONObject jsonObj = new JSONObject(response.body);
                                if (StoreValue.getInstance(null).endpointArn().equals("")) {

                                    String endpointArn = jsonObj.getJSONObject("data").getString("endpointArn");
                                    Log.i("jsonObj: ", jsonObj.toString());
                                    Log.i("endpointArn: ", endpointArn);
                                    StoreValue.getInstance(null).setEndpointArn(endpointArn);
                                }

                                JSONArray topics = jsonObj.getJSONObject("data").getJSONArray("topics");

                                for(int i = 0 ; i < topics.length() ; i++){
                                    //list.add(topics.getJSONObject(i).getString("interestKey"));
                                    String topicId =  topics.getJSONObject(i).getString("topicId");
                                    String topicName =  topics.getJSONObject(i).getString("name");
                                    Boolean isSubscribed = topics.getJSONObject(i).getBoolean("isSubscribed");

                                    Topic t = new Topic(topicId, topicName, isSubscribed);
                                    allTopics.add(t);


                                }


                                TopicAdapter adapter = new TopicAdapter(allTopics, getBaseContext());
                                recyclerTopics.setAdapter(adapter);


                            } catch (JSONException e) {
                                e.printStackTrace();
                            }


                        }else{

                        }



                    }

                    @Override
                    public void onVelocityFailed(Velocity.Response error) {

                        Log.i("error", error.toString());

                    }

                });

    } // end awsActionTopics

} // end SNSByTopicActivity
