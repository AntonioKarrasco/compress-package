package hbpro.gbmmobile.com.androidnotifications;

/**
 * Created by mobile on 10/2/17.
 */

public class Topic {

    String identifier;
    String name;
    Boolean isSubscribed;

    public Topic(String identifier, String name, Boolean isSubscribed) {
        this.identifier = identifier;
        this.name = name;
        this.isSubscribed = isSubscribed;
    }
}
