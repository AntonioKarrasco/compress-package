package hbpro.gbmmobile.com.androidnotifications;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

/**
 * Created by mobile on 9/28/17.
 */

public class OptionsActivity extends AppCompatActivity {

    Button sns;
    Button snsByTopic;
    public static Context context;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        setContentView(R.layout.activity_options);

        sns = (Button) findViewById(R.id.sns);
        snsByTopic = (Button) findViewById(R.id.snsbytopic);

        sns.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getBaseContext(), SNSActivity.class);
                startActivity(i);
            }
        });

        snsByTopic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getBaseContext(), SNSByTopicActivity.class);
                startActivity(i);
            }
        });


    }

    @Override
    protected void onResume() {
        super.onResume();
        OptionsActivity.context = this;

    }
}
