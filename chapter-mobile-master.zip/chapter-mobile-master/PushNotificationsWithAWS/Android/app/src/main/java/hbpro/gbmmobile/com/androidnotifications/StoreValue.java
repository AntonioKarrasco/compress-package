package hbpro.gbmmobile.com.androidnotifications;

import android.content.Context;
import android.content.SharedPreferences;

import static hbpro.gbmmobile.com.androidnotifications.MessageReceivingService.PREFS_NAME;

/**
 * Created by mobile on 10/2/17.
 */

public class StoreValue {

    final String keyEndpointArn = "endpointArn";
    private static StoreValue mInstance = null;

    private Context context;

    private StoreValue(Context context){
        if (context != null) {
            this.context = context;
        }
    }

    public static StoreValue getInstance(Context context){
        if(mInstance == null)
        {
            mInstance = new StoreValue(context);
        }
        return mInstance;
    }


    public String token(){

        SharedPreferences mSettings = context.getSharedPreferences(PREFS_NAME, 0);
        String token = mSettings.getString(MessageReceivingService.TokenKey, "");

        return token;
    }

    public String endpointArn(){

        SharedPreferences mSettings = context.getSharedPreferences(PREFS_NAME, 0);
        String endpointArn = mSettings.getString(keyEndpointArn, "");

        return endpointArn;
    }

    public String subscriptionArn(String topic){

        SharedPreferences mSettings = context.getSharedPreferences(PREFS_NAME, 0);
        String subscriptionArn = mSettings.getString(topic, "");

        return subscriptionArn;

    }

    public void setEndpointArn(String value){

        SharedPreferences mSettings = context.getSharedPreferences(PREFS_NAME, 0);
        SharedPreferences.Editor editor = mSettings.edit();
        editor.putString(keyEndpointArn, value);
        editor.commit();

    }

    public void setSubscriptionArn(String topic, String value){

        SharedPreferences mSettings = context.getSharedPreferences(PREFS_NAME, 0);
        SharedPreferences.Editor editor = mSettings.edit();
        editor.putString(topic, value);
        editor.commit();



    }

}
