! function () {
    "use strict";
    var e = (angular.module("fastBind", []), angular.module("app", ["ngAnimate", "ngRoute", "ngSanitize", "ngStorage", "ngCookies", "ngTouch", "common", "ui.bootstrap", "angularSpinner", "fastBind", "ngDragDrop", "ui.sortable", "template/accordion/accordion-group.html", "gridster", "perfect_scrollbar"]));
    e.run(["$route", "$rootScope", "$location", "$http", "hbSecuritySvc", "urlServices", function (e, t, n, i, o, r) {
        o.bootstrap()["finally"](function () {
            o.loggedIn() || n.path("/login"), t.$on("$routeChangeStart", function (e, i, r) {
                t.error = null, o.loggedIn() || i.allowAnonymous || n.path("/login")
            })
        })
    }])
}(),
function () {
    "use strict";
    var e = angular.module("app");
    toastr.options.timeOut = 4e3, toastr.options.positionClass = "toast-bottom-right";
    var t = "breeze/Breeze",
        n = {
            controllerActivateSuccess: "controller.activateSuccess",
            spinnerToggle: "spinner.toggle"
        },
        i = {
            appErrorPrefix: "[HB Error] ",
            docTitle: "HomeBroker: ",
            events: n,
            remoteServiceName: t,
            version: "2.0.0"
        };
    e.value("config", i), e.value("timeoutConfig", timeOut);
    var o = 100,
        r = 5,
        a = 0;
    ! function (e) {
        for (var t = 30, n = e.innerWidth - (t + 43); n > o;) a++, n -= o, n > o + 2 * r && (n -= 2 * r)
    }(window);
    var s = {
        columns: 15,
        pushing: !0,
        floating: !0,
        width: "auto",
        colWidth: 110,
        rowHeight: "match",
        margins: [10, 10],
        outerMargin: !0,
        isMobile: !1,
        mobileBreakPoint: 600,
        mobileModeEnabled: !0,
        minColumns: 1,
        minRows: 1,
        maxRows: 100,
        defaultSizeX: 2,
        defaultSizeY: 1,
        resizable: {
            enabled: !0,
            handles: "n,e,s,w,ne,se,sw,nw"
        },
        draggable: {
            enabled: !0,
            handle: ".box-drag-handle"
        }
    };
    e.constant("hbGridsterOptions", s);
    var c = {
        servicesUri: clientWebAPIUri
    };
    e.constant("urlServices", c), e.constant("timezoneOffset", timezoneOffset);
    var l = [{
        widgetType: -1,
        url: "loadPartial/Empty/Index/",
        controller: "hbEmptyCtrl",
        controllerAs: "vm"
    }, {
        widgetType: 1,
        url: "loadPartial/Operation/Index/",
        controller: "hbOperationCtrl",
        controllerAs: "vm"
    }, {
        widgetType: 2,
        url: "loadPartial/Monitor/Index/",
        controller: "hbMonitorCtrl",
        controllerAs: "vm"
    }, {
        widgetType: 3,
        url: "loadPartial/Trades/Index/",
        controller: "hbTradesCtrl",
        controllerAs: "vm"
    }, {
        widgetType: 4,
        url: "loadPartial/Blotter/Index/",
        controller: "hbBlotterCtrl",
        controllerAs: "vm"
    }, {
        widgetType: 5,
        url: "loadPartial/LevelTwo/Index/",
        controller: "hbLeveltwoCtrl",
        controllerAs: "vm"
    }, {
        widgetType: 6,
        url: "loadPartial/Participation/Index/",
        controller: "hbParticipationCtrl",
        controllerAs: "vm"
    }, {
        widgetType: 7,
        url: "loadPartial/IssueIntraday/Index/",
        controller: "hbIssueintradayCtrl",
        controllerAs: "vm"
    }, {
        widgetType: 8,
        url: "loadPartial/IndexIntraday/Index/",
        controller: "hbIndexintradayCtrl",
        controllerAs: "vm"
    }, {
        widgetType: 9,
        url: "loadPartial/Commodities/Index/",
        controller: "hbCommoditiesCtrl",
        controllerAs: "vm"
    }, {
        widgetType: 10,
        url: "loadPartial/AdvancedCharts/TVCharts/",
        controller: "hbTVChartsCtrl",
        controllerAs: "vm"
    }, {
        widgetType: 11,
        url: "loadPartial/Transactions/Index/",
        controller: "hbTransactionsCtrl",
        controllerAs: "vm"
    }, {
        widgetType: 12,
        url: "loadPartial/SocialNetwork/Index/",
        controller: "hbSocialNetworkCtrl",
        controllerAs: "vm"
    }, {
        widgetType: 13,
        url: "loadPartial/TradeLevel2Participation/Index/",
        controller: "hbTradeLevel2ParticipationCtrl",
        controllerAs: "vm"
    }, {
        widgetType: 14,
        url: "loadPartial/Position/Index/",
        controller: "hbPositionCtrl",
        controllerAs: "vm"
    }, {
        widgetType: 15,
        url: "loadPartial/TopTen/Index/",
        controller: "hbToptenCtrl",
        controllerAs: "vm"
    }, {
        widgetType: 16,
        url: "loadPartial/Chat/",
        controller: "hbChatterCtrl",
        controllerAs: "vm"
    }, {
        widgetType: 5779,
        url: "loadPartial/Chat/Index/",
        controller: "hbAdvancedChartsCtrl",
        controllerAs: "vm"
    }];
    e.constant("widgetsPath", l);
    var u = {
        SELECTED_SYMBOL: "SELECTED_SYMBOL",
        SELECTED_SYMBOL_FUNDS: "SELECTED_SYMBOL_FUNDS",
        SELECTED_SYMBOL_CASH: "SELECTED_SYMBOL_CASH",
        SEARCHED_SYMBOL: "SEARCHED_SYMBOL",
        CAPITAL_ORDER_ENTER: "CAPITAL_ORDER_ENTER",
        SELECTED_BLOTTER_ORDER: "SELECTED_BLOTTER_ORDER",
        SELECTED_LEVEL_2_SYMBOL: "SELECTED_LEVEL_2_SYMBOL",
        SELECTED_LEVEL_2_ROWDATA: "SELECTED_LEVEL_2_ROWDATA",
        SELECTED_POSITION_CAPITAL: "SELECTED_POSITION_CAPITAL",
        SELECTED_POSITION_FUNDS: "SELECTED_POSITION_FUNDS",
        SELECTED_POSITION_CASH: "SELECTED_POSITION_CASH"
    };
    e.constant("notificationTypes", u);
    var d = {
        CONTRACT: "CONTRACT",
        CULTURE: "CULTURE",
        DASHBOARD_SORTING: "DASHBOARD_SORTING"
    };
    e.constant("configurationTypes", d), e.config(["$logProvider", function (e) {
        e.debugEnabled && e.debugEnabled(!0)
    }]), e.config(["commonConfigProvider", function (e) {
        e.config.controllerActivateSuccessEvent = i.events.controllerActivateSuccess, e.config.spinnerToggleEvent = i.events.spinnerToggle
    }]), e.constant("pusherAppKey", pusherAppKey), e.config(["$provide", function (e) {
        e.decorator("$rootScope", ["$delegate", function (e) {
            return Object.defineProperty(e.constructor.prototype, "$onRootScope", {
                value: function (t, n) {
                    var i = e.$on(t, n);
                    return this.$on("$destroy", i), i
                },
                enumerable: !1
            }), e
        }])
    }]), Date.prototype.getSignedOffsetHour = function () {
        var e = this.getTimezoneOffset() / 60,
            t = "-" === String(e)[0] ? "+" : "-",
            e = String(e).length <= 1 ? "0" + e : e;
        return t + e + ":00"
    }, Date.prototype.getIsoDateFromTime = function (e) {
        var t = new Date,
            n = t.getFullYear(),
            i = t.getMonth() + 1,
            o = t.getDate();
        return i = i.toString().length < 2 ? "0" + i : i, o = o.toString().length < 2 ? "0" + o : o, n + "-" + i + "-" + o + "T" + e + t.getSignedOffsetHour()
    }, Date.prototype.toISO8601String = function () {
        var e = function (e) {
                return e < 10 ? "0" + e : "" + e
            },
            t = this.getTimezoneOffset(),
            n = ~~(t / 60),
            i = t % 60,
            o = this.getFullYear() + "-" + e(this.getMonth() + 1) + "-" + e(this.getDate()) + "T" + e(this.getHours()) + ":" + e(this.getMinutes()) + ":" + e(this.getSeconds()) + "." + this.getMilliseconds() + (t > 0 ? "-" : "+") + e(n) + ":" + e(i);
        return o
    }
}(),
function () {
    "use strict";

    function e(e, t, n) {
        var i = t.appErrorPrefix,
            o = n.getLogFn("app", "error");
        return function (t, n) {
            if (e(t, n), !i || !t.message || 0 !== t.message.indexOf(i)) {
                var r = {
                        exception: t,
                        cause: n
                    },
                    a = i + t.message;
                o(a, r, !0)
            }
        }
    }
    var t = angular.module("app");
    t.config(["$provide", function (t) {
        t.decorator("$exceptionHandler", ["$delegate", "config", "logger", e])
    }])
}(),
function () {
    "use strict";

    function e(e, t, n, i) {
        n.forEach(function (t) {
            e.when(t.url, t.config)
        }), e.otherwise({
            redirectTo: "/"
        }), i.html5Mode(!0), t.interceptors.push(["$rootScope", "$q", "$location", function (e, t, n) {
            return {
                responseError: function (i) {
                    switch (i.status) {
                        case 403:
                            return e.$emit("log-Out", {}), n.path("/login"), t.reject(i);
                        default:
                            return t.reject(i)
                    }
                }
            }
        }])
    }

    function t() {
        return [{
            url: "/",
            config: {
                templateUrl: "loadPartial/Dashboard/Index",
                title: "GBM Dashboard",
                controller: "hbDashboardCtrl",
                controllerAs: "vm",
                resolve: {
                    init: ["$q", "hbLocalDataSvc", "hbPositionSvc", function (e, t, n) {
                        function i(e) {
                            o.reject(e)
                        }
                        var o = e.defer();
                        return t.initialize().then(function () {
                            var e = t.loadcontracts();
                            e && e.then(function () {
                                n.initialized().then(function () {
                                    o.resolve(!0)
                                }, i)
                            }, i)
                        }, i), o.promise
                    }],
                    initSolace: ["hbSolaceSvc", function (e) {
                        return e.serviceInitialized()
                    }]
                },
                settings: {
                    nav: 1,
                    content: '<i class="fa fa-dashboard"></i> GBM Dashboard'
                }
            }
        }, {
            url: "/monitor",
            config: {
                templateUrl: "loadPartial/Monitor/Index",
                title: "GBM Monitor",
                controller: "hbMonitorCtrl",
                controllerAs: "vm",
                resolve: {
                    init: ["hbLocalDataSvc", function (e) {
                        return e.initialize().then(function () {
                            e.loadcontracts()
                        })
                    }]
                },
                settings: {
                    nav: 4,
                    content: '<i class="fa fa-table"></i> GBM Monitor'
                }
            }
        }, {
            url: "/highchartsTest",
            config: {
                templateUrl: "app/widgets/highchartsTest/highchartTmpl.html",
                controller: "highchartsCtrl",
                controllerAs: "vm",
                title: ""
            }
        }, {
            url: "/login",
            config: {
                title: "GBM Login",
                templateUrl: "loadPartial/Login/Index",
                allowAnonymous: !0,
                resolve: {
                    init: ["hbLocalDataSvc", function (e) {
                        return e.initialize()
                    }]
                }
            }
        }, {
            url: "/activate",
            config: {
                title: "GBM Activate",
                templateUrl: "loadPartial/Login/Activate",
                allowAnonymous: !0,
                resolve: {
                    init: ["hbLocalDataSvc", function (e) {
                        return e.initialize()
                    }]
                }
            }
        }, {
            url: "/sync",
            config: {
                title: "GBM Token ReSync",
                templateUrl: "loadPartial/Login/ReSyncToken",
                allowAnonymous: !0,
                resolve: {
                    init: ["hbLocalDataSvc", function (e) {
                        return e.initialize()
                    }]
                }
            }
        }, {
            url: "/operation",
            config: {
                templateUrl: "loadPartial/Operation/Index",
                title: "GBM Operation",
                controller: "hbOperationCtrl",
                controllerAs: "vm",
                resolve: {
                    init: ["hbLocalDataSvc", function (e) {
                        return e.initialize().then(function () {
                            e.loadcontracts()
                        })
                    }]
                },
                settings: {
                    nav: 5,
                    content: '<i class="fa fa-umbrella"></i> GBM Operation'
                }
            }
        }, {
            url: "/trades",
            config: {
                templateUrl: "loadPartial/Trades/Index",
                title: "GBM Trades",
                controller: "hbTradesCtrl",
                controllerAs: "vm",
                resolve: {
                    init: ["hbLocalDataSvc", function (e) {
                        return e.initialize().then(function () {
                            e.loadcontracts()
                        })
                    }]
                },
                settings: {
                    nav: 6,
                    content: '<i class="fa fa-exchange"></i> GBM Trade'
                }
            }
        }, {
            url: "/LevelTwo",
            config: {
                templateUrl: "loadPartial/LevelTwo/Index",
                title: "GBM LevelTwo",
                controller: "hbLeveltwoCtrl",
                controllerAs: "vm",
                resolve: {
                    init: ["hbLocalDataSvc", function (e) {
                        return e.initialize().then(function () {
                            e.loadcontracts()
                        })
                    }]
                },
                settings: {
                    nav: 7,
                    content: '<i class="fa fa-lightbulb"></i> GBM Level2'
                }
            }
        }, {
            url: "/IssueIntraday",
            config: {
                templateUrl: "loadPartial/IssueIntraday/Index",
                title: "GBM IssueIntraday",
                controller: "hbIssueintradayCtrl",
                controllerAs: "vm",
                resolve: {
                    init: ["hbLocalDataSvc", function (e) {
                        return e.initialize().then(function () {
                            e.loadcontracts()
                        })
                    }]
                },
                settings: {
                    nav: 8,
                    content: '<i class="fa fa-bolt"></i> GBM Issue Intraday'
                }
            }
        }, {
            url: "/IndexIntraday",
            config: {
                templateUrl: "loadPartial/IndexIntraday/Index",
                title: "GBM IndexIntraday",
                controller: "hbIndexintradayCtrl",
                controllerAs: "vm",
                resolve: {
                    init: ["hbLocalDataSvc", function (e) {
                        return e.initialize().then(function () {
                            e.loadcontracts()
                        })
                    }]
                },
                settings: {
                    nav: 9,
                    content: '<i class="fa fa-bolt"></i> GBM Index Intraday'
                }
            }
        }, {
            url: "/Participation",
            config: {
                templateUrl: "loadPartial/Participation/Index",
                title: "GBM Participation",
                controller: "hbParticipationCtrl",
                controllerAs: "vm",
                resolve: {
                    init: ["hbLocalDataSvc", function (e) {
                        return e.initialize().then(function () {
                            e.loadcontracts()
                        })
                    }]
                },
                settings: {
                    nav: 10,
                    content: '<i class="fa fa-circle"></i> GBM Participation'
                }
            }
        }, {
            url: "/Blotter",
            config: {
                templateUrl: "loadPartial/Blotter/Index",
                title: "GBM Blotter",
                controller: "hbBlotterCtrl",
                controllerAs: "vm",
                resolve: {
                    init: ["hbLocalDataSvc", function (e) {
                        return e.initialize().then(function () {
                            e.loadcontracts()
                        })
                    }]
                },
                settings: {
                    nav: 11,
                    content: '<i class="fa fa-globe"></i> GBM Blotter'
                }
            }
        }, {
            url: "/Chat",
            config: {
                templateUrl: "loadPartial/Chat/Index",
                title: "GBM Chat client",
                settings: {
                    nav: 12,
                    content: '<i class="icon-group"></i> GBM Chat'
                }
            }
        }]
    }
    var n = angular.module("app");
    n.constant("routes", t()), n.config(["$routeProvider", "$httpProvider", "routes", "$locationProvider", e])
}(),
function (e) {
    "use strict";

    function t() {
        return function (e, t) {
            for (var n, i = 0; i < e.length; i++)
                if (e[i].topic === t) {
                    n = e[i];
                    break
                }
            return n
        }
    }

    function n() {
        return function (e, t, n) {
            for (var i, o = 0; o < e.length; o++)
                if (e[o][n] === t) {
                    i = e[o];
                    break
                }
            return i
        }
    }
    e.filter("solaceGetByTopic", t), e.filter("solaceGetByProp", n), e.filter("getByTicks", n), e.constant("solaceOptions", solaceOptions)
}(angular.module("app")),
function () {
    "use strict";

    function e(e, t, n, i, o, r, a, s) {
        function c(t, n) {
            return e.all(t).then(function (e) {
                var t = {
                    controllerId: n
                };
                u(o.config.controllerActivateSuccessEvent, t)
            })
        }

        function l(e, t) {
            var n = i.open({
                scope: e,
                templateUrl: "loadPartial/Confirmation",
                controller: "hbConfirmationCtrl",
                resolve: {
                    parentCtrl: function () {
                        return e.vm
                    },
                    options: function () {
                        return t
                    }
                }
            });
            return n.result
        }

        function u() {
            return t.$broadcast.apply(t, arguments)
        }

        function d() {
            return t.$emit.apply(t, arguments)
        }

        function g() {
            return t.$onRootScope.apply(t, arguments)
        }

        function f(e, t, i, o, r) {
            r = +r || 300, i || (i = "filtered" + t[0].toUpperCase() + t.substr(1).toLowerCase(), o = t + "Filter");
            var a = function () {
                e[i] = e[t].filter(function (t) {
                    return e[o](t)
                })
            };
            return function () {
                var e;
                return function (t) {
                    e && (n.cancel(e), e = null), t || !r ? a() : e = n(a, r)
                }
            }()
        }

        function p(e, t, i, o) {
            var r = 1e3;
            i = i || r, v[e] && (n.cancel(v[e]), v[e] = void 0), o ? t() : v[e] = n(t, i)
        }

        function h(e) {
            return /^[-]?\d+$/.test(e)
        }

        function m(e, t) {
            return e && -1 !== e.toLowerCase().indexOf(t.toLowerCase())
        }
        var v = {},
            b = {
                isMobile: !1
            },
            S = {
                $broadcast: u,
                $emit: d,
                $onRootScope: g,
                $q: e,
                $timeout: n,
                activateController: c,
                createSearchThrottle: f,
                debouncedThrottle: p,
                isNumber: h,
                logger: r,
                textContains: m,
                serviceManager: a,
                mobileProperties: b,
                displayConfirmation: l
            };
        return t.$watch(function () {
            return s.isMobile
        }, function (e) {
            S.mobileProperties.isMobile = !!e
        }), S
    }
    var t = angular.module("common", []);
    t.provider("commonConfig", function () {
        this.config = {}, this.$get = function () {
            return {
                config: this.config
            }
        }
    }), t.factory("common", ["$q", "$rootScope", "$timeout", "$modal", "commonConfig", "logger", "serviceManager", "hbGridsterOptions", e])
}(),
function () {
    "use strict";

    function e(e) {
        function t(e, t) {
            switch (t = t || "log", t.toLowerCase()) {
                case "success":
                    t = "logSuccess";
                    break;
                case "error":
                    t = "logError";
                    break;
                case "warn":
                    t = "logWarning";
                    break;
                case "warning":
                    t = "logWarning"
            }
            var n = s[t] || s.log;
            return function (t, i, o) {
                n(t, i, e, void 0 === o || o)
            }
        }

        function n(e, t, n, i) {
            a(e, t, n, i, "info")
        }

        function i(e, t, n, i) {
            a(e, t, n, i, "warning")
        }

        function o(e, t, n, i) {
            a(e, t, n, i, "success")
        }

        function r(e, t, n, i) {
            a(e, t, n, i, "error")
        }

        function a(t, n, i, o, r) {
            var a = "error" === r ? e.error : e.log;
            i = i ? "[" + i + "] " : "", a(i, t, n), o && ("error" === r ? toastr.error(t) : "warning" === r ? toastr.warning(t) : "success" === r ? toastr.success(t) : toastr.info(t))
        }
        var s = {
            getLogFn: t,
            log: n,
            logError: r,
            logSuccess: o,
            logWarning: i
        };
        return s
    }
    angular.module("common").factory("logger", ["$log", e])
}(),
function () {
    "use strict";

    function e(e, t) {
        function n() {
            o(!1)
        }

        function i() {
            o(!0)
        }

        function o(n) {
            e.$broadcast(t.config.spinnerToggleEvent, {
                show: n
            })
        }
        var r = {
            spinnerHide: n,
            spinnerShow: i
        };
        return r
    }
    angular.module("common").factory("spinner", ["common", "commonConfig", e])
}(),
function () {
    "use strict";
    var e = "serviceManager";
    angular.module("common").factory(e, ["$http", "$q", "$timeout", "$modal", "$rootScope", "logger", "urlServices", "hbSessionSliderSvc", function (t, n, i, o, r, a, s, c) {
        return function (i, l, u, d) {
            function g() {
                o.open({
                    scope: r,
                    templateUrl: "loadPartial/Login/RefreshApplication",
                    controller: "hbRefreshApplicationCtrl",
                    backdrop: "static"
                })
            }

            function f(e, n, i, o) {
                return 0 !== e.indexOf(s.servicesUri) || t.defaults.headers.common.GBMDigitalIdentityUser ? void t({
                    method: n,
                    url: e,
                    data: i
                }).then(function (e) {
                    o && o.count > 0 && m("[" + (new Date).format("dd/mm/yyyy HH:MM:ss L tt") + "] - ConexiÃ³n recuperada.", null, !0), o && void 0 !== o.isTimer && o.isTimer || setTimeout(function () {
                        c.slideSession()
                    }, 0), y.resolve(e)
                }, function (t) {
                    switch (t.status) {
                        case 0:
                            o ? o.mustRetry && o.count < b ? (o.count++, setTimeout(function () {
                                f(e, n, i, o)
                            }, S), v("[" + (new Date).format("dd/mm/yyyy HH:MM:ss L tt") + "] - There was a problem contacting the service, attempt #" + o.count + ".", null, !0)) : r.isOffline || (g(), r.isOffline = !0) : r.isOffline || h("[" + (new Date).format("dd/mm/yyyy HH:MM:ss L tt") + "] - Application is offline.", null, !0);
                            break;
                        default:
                            y.reject(t)
                    }
                }) : void y.reject()
            }
            var p = a.getLogFn,
                h = p(e, "Error"),
                m = p(e, "success"),
                v = p(e, "warning"),
                b = 3,
                S = 5e3,
                y = n.defer();
            return f(i, l, u, d), y.promise
        }
    }])
}(),
function () {
    "use strict";

    function e(e) {
        return {
            restrict: "AE",
            scope: {
                widgets: "=ezGridster"
            },
            template: '<ul class="rowwidget"><li class="gs-w box" ez-gridster-widget ng-repeat="widget in widgets" ></li></ul>',
            link: function (t, n, i) {
                function o() {
                    var e = r(),
                        n = a(),
                        i = {};
                    return e > t.gridster.rows && (t.gridster.rows = e, i.rows = e), n > t.gridster.cols && (t.gridster.cols = n, i.cols = n), i
                }

                function r() {
                    var e = t.widgets.reduce(function (e, t) {
                        return t.row > e.row ? t : e
                    });
                    return e.row
                }

                function a() {
                    var e = t.widgets.reduce(function (e, t) {
                        return t.col > e.col ? t : e
                    });
                    return e.col
                }
                t.options = angular.extend(e, t.$parent.$eval(i.ezGridsterOptions)), t.updateWidgets = function (e) {
                    var n = t.gridster.serialize();
                    angular.forEach(n, function (e, n) {
                        t.widgets[n].init = 1, t.widgets[n] = angular.extend(t.widgets[n], e)
                    }), t.$digest(), t.$emit("ez_gridster.widgets_updated", n), t.$emit("ez_gridster.get_widgets", t.widgets)
                }, t.options.draggable.stop = function (e) {
                    t.updateWidgets(e), t.$emit("ez_gridster.widget_dragged")
                }, t.options.draggable.start = function (e) {
                    t.$emit("ez_gridster.widget_dragging")
                }, t.options.resize.stop = function (e, n) {
                    t.updateWidgets(e), t.$emit("ez_gridster.widget_resized")
                }, t.gridster = n.addClass("gridster").find("ul").gridster(t.options).data("gridster"), t.$on("ez_gridster.add_widget", function (e, n) {
                    var i = n.size_x || 1,
                        r = n.size_y || 1;
                    1 == n.init && (n = angular.extend(n, t.gridster.next_position(i, r))), null == t.widgets ? t.widgets = [n] : t.widgets.push(n), t.$emit("ez_gridster.widget_added", n), 1 == n.init && t.$emit("ez_gridster.get_widgets", t.widgets);
                    o()
                }), t.$on("ez_gridster.remove_widget", function (e, n) {
                    t.removeWidget(n), t.$emit("ez_gridster.get_widgets", t.widgets)
                }), t.$on("ez_gridster.clear", function () {
                    t.gridster.remove_all_widgets(), t.widgets = [], t.$emit("ez_gridster.get_widgets", t.widgets)
                }), t.$on("ez_gridster.set", function (e, n) {
                    t.gridster.remove_all_widgets(), t.widgets = n;
                    o()
                }), t.$on("ez_gridster.setup", function (e, n) {
                    t.gridster.remove_all_widgets()
                }), t.removeWidget = function (e) {
                    t.gridster.remove_widget(n.find("li.gs-w").eq(e), t.options.remove.silent, function () {
                        var n = t.widgets[e];
                        t.widgets.splice(e, 1), t.$emit("ez_gridster.widget_removed", n, e), t.$emit("ez_gridster.get_widgets", t.widgets), t.$digest()
                    })
                }
            }
        }
    }
    var t = "ezGridster";
    angular.module("app").directive(t, ["ezGridsterConfig", e])
}(),
function () {
    "use strict";

    function e(e, t, n, i, o, r) {
        return {
            restrict: "AE",
            templateUrl: "loadPartial/Dashboard/WidgetTemplate",
            link: function (t, n) {
                if (void 0 != t.widget && void 0 != t.widget.id) {
                    var r = 0,
                        a = "{Configuration not found.}";
                    o.getWidgetConfiguration(t.widget.id).then(function (n) {
                        var o = n.data;
                        r = o.widgetTypeId, a = o.config, t.widget.config = a;
                        var s = e("filter")(i, {
                            widgetType: r
                        }, !0);
                        angular.extend(t.widget, s[0]), s || (t.widget.url = "loadPartial/Empty/Index/", t.widget.controller = "", t.widget.config = a)
                    }, function (e) {
                        t.widget.url = "loadPartial/Empty/Index/", t.widget.controller = "", t.widget.config = a
                    });
                    n.attr({
                        "data-min-sizey": t.widget.min_sizey,
                        "data-min-sizex": t.widget.min_sizex,
                        "data-max-sizey": t.widget.max_sizey,
                        "data-max-sizex": t.widget.max_sizex
                    })
                }
            }
        }
    }
    var t = "ezGridsterWidget";
    angular.module("app").directive(t, ["$filter", "$timeout", "common", "widgetsPath", "hbAppManagementSvc", "hbLoggingSvc", e])
}(),
function () {
    "use strict";
    var e = "object2Array";
    angular.module("app").filter(e, function () {
        return function (e) {
            var t = [];
            for (var n in e) t.push(e[n]);
            return t
        }
    })
}(),
function () {
    "use strict";

    function e(e) {
        function t(e, t, n) {
            t.removeClass("flash-change"), e.$watch(n.hbSymbolChanged, function (e, n) {
                t.removeClass("flash-change"), n && e !== n && t.addClass("flash-change")
            }, !0)
        }
        var n = {
            restrict: "A",
            link: t
        };
        return n
    }
    var t = "hbSymbolChanged";
    angular.module("app").directive(t, ["$timeout", e])
}(),
function () {
    "use strict";

    function e(e, t, n) {
        return {
            link: function (i, o, r) {
                var a, s, c, l;
                return t = angular.element(t), c = 0, null != r.infiniteScrollDistance && i.$watch(r.infiniteScrollDistance, function (e) {
                    return c = parseInt(e, 10)
                }), l = !0, a = !1, null != r.infiniteScrollDisabled && i.$watch(r.infiniteScrollDisabled, function (e) {
                    if (l = !e, l && a) return a = !1, s()
                }), s = function () {
                    var n, s, u, d;
                    return d = t.height() + t.scrollTop(), n = o.offset().top + o.height(), s = n - d, u = s <= t.height() * c, u && l ? e.$$phase ? i.$eval(r.infiniteScroll) : i.$apply(r.infiniteScroll) : u ? a = !0 : void 0
                }, o.bind("scroll", s), n(function () {
                    return r.infiniteScrollImmediateCheck ? i.$eval(r.infiniteScrollImmediateCheck) ? s() : void 0 : s()
                }, 0)
            }
        }
    }
    var t = "infiniteScroll";
    angular.module("app").directive(t, ["$rootScope", "$window", "$timeout", e])
}(),
function () {
    "use strict";
    angular.module("app").directive("repeatDone", function () {
        return function (e, t, n) {
            e.$last && e.$eval(n.repeatDone)
        }
    })
}(),
function () {
    "use strict";

    function e(e) {
        return {
            restrict: "A",
            scope: {
                method: "&hbPostRender"
            },
            link: function (t, n, i) {
                e(t.method(), 1e3)
            }
        }
    }
    var t = "hbPostRender";
    angular.module("app").directive(t, ["$timeout", e])
}(),
function () {
    "use strict";

    function e(e, t, n, i) {
        function o(o, r, a) {
            var s = {};
            o.$watch("widget.url", function () {
                o.widget.url && o.widget.controller && n.get(o.widget.url, {
                    cache: i
                }).then(function (n) {
                    s.$template = n.data, r.html(s.$template);
                    var i = e(r.contents());
                    if (s.$scope = o, o.widget.controller) {
                        var a = t(o.widget.controller, s);
                        o.widget.controllerAs && (o[o.widget.controllerAs] = a), r.data("$ngControllerController", a), r.children().data("$ngControllerController", a)
                    }
                    i(o)
                })
            }, !0)
        }
        return {
            restricti: "E",
            link: o
        }
    }
    var t = "bindWidget";
    angular.module("app").directive(t, ["$compile", "$controller", "$http", "$templateCache", e])
}(),
function () {
    "use strict";

    function e(e) {
        return {
            compile: function (t, n) {
                var i = e(n.fastBindOnce);
                return function (e, t) {
                    t.text(i(e))
                }
            }
        }
    }
    var t = "fastBindOnce";
    angular.module("app").directive(t, ["$parse", e])
}(),
function () {
    "use strict";
    angular.module("common").directive("highchart", function () {
        function e(e, t, n) {
            var i = e[t];
            e[t] = function () {
                var e = Array.prototype.slice.call(arguments);
                return n.apply(this, e), i ? i.apply(this, e) : void 0
            }
        }

        function t(e, n) {
            for (var i in n) n[i] && n[i].constructor && n[i].constructor === Object ? (e[i] = e[i] || {}, t(e[i], n[i])) : e[i] = n[i];
            return e
        }
        var n = function (e, t, n) {
                void 0 === n && (n = 0), n < 0 && (n += e.length), n < 0 && (n = 0);
                for (var i = e.length; n < i; n++)
                    if (n in e && e[n] === t) return n;
                return -1
            },
            i = 0,
            o = function (e) {
                var t = !1;
                return angular.forEach(e, function (e) {
                    angular.isDefined(e.id) || (e.id = "series-" + i++, t = !0)
                }), t
            },
            r = ["xAxis", "yAxis"],
            a = function (n, i, o) {
                var a = {},
                    s = {
                        chart: {
                            events: {}
                        },
                        title: {},
                        subtitle: {},
                        series: [],
                        credits: {},
                        plotOptions: {},
                        navigator: {
                            enabled: !1
                        },
                        legend: {
                            enabled: !1
                        }
                    };
                return a = o.options ? t(s, o.options) : s, a.chart.renderTo = i[0], angular.forEach(r, function (t) {
                    o[t] && (e(a.chart.events, "selection", function (e) {
                        var i = this;
                        e[t] ? n.$apply(function () {
                            n.config[t].currentMin = e[t][0].min, n.config[t].currentMax = e[t][0].max
                        }) : n.$apply(function () {
                            n.config[t].currentMin = i[t][0].dataMin, n.config[t].currentMax = i[t][0].dataMax
                        })
                    }), e(a.chart.events, "addSeries", function (e) {
                        n.config[t].currentMin = this[t][0].min || n.config[t].currentMin, n.config[t].currentMax = this[t][0].max || n.config[t].currentMax
                    }), a[t] = angular.copy(o[t]))
                }), o.title && (a.title = o.title), o.subtitle && (a.subtitle = o.subtitle), o.credits && (a.credits = o.credits), o.credits && (a.plotOptions = o.plotOptions), a
            },
            s = function (e, t) {
                var n = e.getExtremes();
                t.currentMin === n.dataMin && t.currentMax === n.dataMax || e.setExtremes(t.currentMin, t.currentMax, !1)
            },
            c = function (e, t, n) {
                (t.currentMin || t.currentMax) && e[n][0].setExtremes(t.currentMin, t.currentMax, !0)
            },
            l = function (e) {
                return angular.extend({}, e, {
                    data: null,
                    visible: null
                })
            };
        return {
            restrict: "EAC",
            replace: !0,
            template: "<div></div>",
            scope: {
                config: "=",
                chartwidth: "=",
                chartheight: "="
            },
            link: function (e, t, i) {
                var u = {};
                Highcharts.setOptions({
                    global: {
                        useUTC: !0,
                        timezoneOffset: timezoneOffset * -1
                    }
                });
                var d = function (e) {
                        var t = [];
                        if (e) {
                            var i = o(e);
                            if (i) return !1;
                            angular.forEach(e, function (e) {
                                t.push(e.id);
                                var n = g.get(e.id);
                                n ? angular.equals(u[e.id], l(e)) ? (void 0 !== e.visible && n.visible !== e.visible && n.setVisible(e.visible, !1), n.options.data !== e.data && n.setData(angular.copy(e.data), !1)) : n.update(angular.copy(e), !1) : g.addSeries(angular.copy(e), !1), u[e.id] = l(e)
                            })
                        }
                        for (var r = g.series.length - 1; r >= 0; r--) {
                            var a = g.series[r];
                            n(t, a.options.id) < 0 && a.remove(!1)
                        }
                        return !0
                    },
                    g = !1,
                    f = function () {
                        g && g.destroy();
                        var n = e.config || {},
                            i = a(e, t, n);
                        g = n.useHighStocks ? new Highcharts.StockChart(i) : new Highcharts.Chart(i);
                        for (var o = 0; o < r.length; o++) n[r[o]] && c(g, n[r[o]], r[o]);
                        n.loading && g.showLoading(), e.chartwidth && (g.chartWidth = e.chartwidth), e.chartheight && (g.chartHeight = e.chartheight)
                    };
                f(), e.$watch("config.series", function (e, t) {
                    var n = d(e);
                    n && g.redraw()
                }, !0), e.$watch("config.title", function (e) {
                    g.setTitle(e, !0)
                }, !0), e.$watch("config.subtitle", function (e) {
                    g.setTitle(!0, e)
                }, !0), e.$watch("config.loading", function (e) {
                    e ? g.showLoading() : g.hideLoading()
                }), e.$watch("config.credits.enabled", function (e) {
                    e ? g.credits.show() : g.credits && g.credits.hide()
                }), e.$watch("config.useHighStocks", function (e) {
                    f()
                }), angular.forEach(r, function (t) {
                    e.$watch("config." + t, function (e, n) {
                        e !== n && e && (g[t][0].update(e, !1), s(g[t][0], angular.copy(e)), g.redraw())
                    }, !0)
                }), e.$watch("config.options", function (e, t, n) {
                    e !== t && (f(), d(n.config.series), g.redraw())
                }, !0), e.$on("$destroy", function () {
                    g && g.destroy(), t.remove()
                })
            }
        }
    })
}(),
function () {
    "use strict";
    angular.module("fastBind").directive("fastBindOnNotify", ["$parse", function (e) {
        var t = "fast-bind-notify";
        return {
            compile: function (n, i) {
                var o = e(i.fastBindOnNotify),
                    r = i.fastBindOnNotifyName || t;
                return function (e, t, n, i, a) {
                    var s;
                    e.$on(r, function () {
                        var n = o(e);
                        n !== s && t.text(n), s = n
                    })
                }
            }
        }
    }])
}(),
function () {
    "use strict";
    angular.module("fastBind").directive("fastBindHtmlOnNotify", ["$compile", "$sce", "$parse", function (e, t, n) {
        var i = "fast-bind-notify";
        return {
            compile: function (t, o) {
                var r = n(o.fastBindHtmlOnNotify),
                    a = o.fastBindOnNotifyName || i;
                return function (t, n) {
                    var i;
                    t.$on(a, function () {
                        var o = r(t);
                        if (o !== i) {
                            n.html(o);
                            var a = e(n.contents());
                            a(t)
                        }
                        i = o
                    })
                }
            }
        }
    }])
}(),
function () {
    "use strict";
    angular.module("fastBind").directive("fastBindNotifier", ["$parse", function (e) {
        var t = {
                SHALLOW: "shallow",
                DEEP: "deep",
                COLLECTION: "collection"
            },
            n = "fast-bind-notify",
            i = t.SHALLOW;
        return {
            scope: !0,
            compile: function (o, r) {
                var a = e(r.fastBindNotifier),
                    s = r.fastBindNotifierName || n,
                    c = r.fastBindNotifierMode || i;
                return function (e, n) {
                    var i = function (e, t, n) {
                        n.$broadcast(s, e, t)
                    };
                    switch (c) {
                        case t.SHALLOW:
                        case t.DEEP:
                            e.$watch(a, i, c === t.DEEP);
                            break;
                        case t.COLLECTION:
                            e.$watchCollection(a, i);
                            break;
                        default:
                            throw Error('fast-bind-notifier: Invalid mode "' + c + '"')
                    }
                }
            }
        }
    }])
}(),
function () {
    "use strict";
    angular.module("fastBind").directive("fastBindOnce", ["$parse", function (e) {
        return {
            transclude: !0,
            compile: function (t, n) {
                e(n.fastBindOnce);
                return function (e, t, n, i, o) {
                    o(e, function (e) {
                        t.prepend(e)
                    })
                }
            }
        }
    }])
}(),
function () {
    "use strict";
    angular.module("fastBind").directive("fastBindAttrOnNotify", ["$parse", function (e) {
        var t = "fast-bind-notify";
        return {
            compile: function (n, i) {
                var o = e(i.fastBindAttrOnNotify),
                    r = i.fastBindOnNotifyName || t;
                return function (e, t, n) {
                    var i = {};
                    e.$on(r, function () {
                        var t = o(e);
                        angular.forEach(t, function (e, t) {
                            e !== i[t] && n.$set(t, e), i[t] = e
                        })
                    })
                }
            }
        }
    }])
}(),
function () {
    "use strict";
    angular.module("fastBind").directive("fastBindAttrOnce", ["$parse", function (e) {
        return {
            compile: function (t, n) {
                var i = e(n.fastBindAttrOnce);
                return function (e, t, o) {
                    var r = i(e);
                    angular.forEach(r, function (e, t) {
                        n.$set(t, e)
                    })
                }
            }
        }
    }])
}(),
function () {
    "use strict";

    function e(e) {
        return {
            restrict: "A",
            scope: {
                issueSymbol: "=hbSearchInput",
                methodKeyDown: "&hbSearchActionKeydown",
                methodBlur: "&hbSearchActionBlur",
                methodNotifyChange: "&hbSearchNotifyChange"
            },
            controller: "hbSearchInputCtrl",
            controllerAs: "vm",
            templateUrl: "loadPartial/SearchInput",
            link: function (t, n, i) {
                function o() {
                    c = t.issueSymbol
                }

                function r() {
                    t.onblur();
                    return e.$q.all([onblur]).then(function (e) {
                        return s && s(), e
                    })
                }
                var a = t.methodKeyDown,
                    s = t.methodBlur,
                    c = "",
                    l = n.find("#inputIssue");
                l.bind("keyup", function (e) {
                    a && a(), 13 == e.which && r();
                    var t = l.val(),
                        n = l.val();
                    n && (n = n.replace(/[^a-zA-Z0-9 \*&]*/g, ""), t !== n && l.val(n))
                }), l.bind("blur", function (e) {
                    r()
                }), l.bind("focus", function (e) {
                    o()
                })
            }
        }
    }
    var t = "hbSearchInput";
    angular.module("app").directive(t, ["common", e])
}(),
function () {
    "use strict";

    function e() {
        return function (e, t, n) {
            t.bind("blur", function () {
                e.$apply(n.blur)
            })
        }
    }
    var t = "blur";
    angular.module("app").directive(t, [e])
}(),
function () {
    "use strict";

    function e() {
        function e(e, t, n) {
            e.$watch(n.hbDivId, function () {
                t.attr("id", "div" + n.hbDivId)
            })
        }
        return {
            restricti: "A",
            link: e
        }
    }
    var t = "hbDivId";
    angular.module("app").directive(t, [e])
}(),
function (e) {
    "use strict";

    function t(t, n) {
        return {
            restrict: "A",
            scope: {
                config: "=hbIeCanvasTable",
                collection: "&hbCanvasTableCollection",
                columnClickCallback: "&hbCanvasTableColumnClick",
                buttonClickCallback: "&hbCanvasTableButtonClick",
                dragStartCallback: "&hbCanvasTableStartDrag",
                keyColumn: "=hbCanvasTableKeyColumn",
                sortColumn: "&hbCanvasTableSortColumn",
                sortAsc: "&hbCanvasTableSortAsc",
                rowClickCallback: "&hbCanvasTableRowClick"
            },
            link: function (i, o, r) {
                function a(e) {
                    if (W) {
                        var t = R;
                        if (e.wheelDelta) R -= e.wheelDelta, R = Math.min(Math.max(0, R), N - M.height);
                        else if (e.deltaY) {
                            var n = 1;
                            "firefox" === P && (n = 9), R += e.deltaY * n, R = Math.min(Math.max(0, R), N - M.height)
                        }
                        if (R !== t) return s(e), !1
                    }
                }

                function s(e) {
                    e = e || window.event, e.preventDefault && e.preventDefault(), e.stopPropagation && e.stopPropagation(), e.returnValue = !1
                }

                function c() {
                    for (var e = 0, t = D.columns, n = 0, i = t.length; n < i; n++) t[n].visible && (e |= 1 << 1 + n);
                    return e
                }

                function l() {
                    var e = new Date;
                    I = E(), U = 0, F = I.length;
                    var t = !1;
                    w !== I.length && (R = 0, t = !0), fe !== A() && (t = !0, fe = A()), pe !== k() && (t = !0, pe = k()), null !== he && he === D.theme.color || (he = D.theme.color, t = !0);
                    var n, i = D.columns,
                        o = D.theme;
                    if (o.color) {
                        var r = M.getBoundingClientRect(),
                            a = H[0],
                            s = a.getBoundingClientRect(),
                            l = s.height + 15,
                            f = r.top - s.top - R;
                        U = ~~(R / Y), F = ~~(l / Y) + U + 2, F = Math.min(F, I.length);
                        var p = J.width(),
                            h = !1;
                        (w !== I.length || p !== y || C) && (R = 0, y = p, T = l, C = !1, w = I.length, N = Y * I.length + Y, M.height = l - f - Y, M.width = y, b = M.width - ae, S = M.height, m = b + ae / 2, v = S - ae / 2, W = ~~(S / Y - 1) < I.length, ee = -1, te = -1, h = !0, t = !0);
                        var _ = c();
                        if (ce !== _ || h) {
                            h = !1, t = !0, ce = _;
                            for (var P = 0, $ = 0, G = 0, V = i.length; G < V; G++) n = i[G], n.visible && (P += n.width, $++);
                            for (var z = (100 - P) / $, G = 0, V = i.length; G < V; G++) n = i[G], n.visible ? B[G] = b * ((z + n.width) / 100) : B[G] = 0;
                            x[0] = 0;
                            for (var G = 1, V = B.length; G < V; G++) x[G] = x[G - 1] + B[G - 1]
                        }
                        ge !== R && (t = !0), ge = R;
                        for (var X, j, K, le, ve, be = new Array(F - U), Se = new Array(F - U), ye = new Array(F - U), G = 0; G < F - U; G++) be[G] = new Array(i.length + 1), ye[G] = u(I[G + U], i[L].name), X = q[ye[G]], j = G + U + 1, ve = !1, le = me[ye[G]], le && le === G || (ve = !0), me[ye[G]] = G, Se[G] = d(X, be[G], G) || ee === j || te === j || ve, K = Se[G], X ? (Se[G] |= X[i.length], X[i.length] = K) : be[G][i.length] = Se[G];
                        t && (O.clearRect(0, 0, b + ae, S), O.fillStyle = o.backgroundColor, O.fillRect(0, Y, b, S));
                        for (var Te = R % Y, Ce = Array.apply(null, Array(i.length)).map(function (e, t) {
                                return !1
                            }), we = Array.apply(null, Array(i.length)).map(function (e, t) {
                                return !1
                            }), Ie = null, G = 0, V = i.length; G < V; G++) i[G].visible && (i[G].overlay ? (Ie ? (Ce[G] = i[Ie].overlay.color !== i[G].overlay.color, we[Ie] = Ce[G]) : Ce[G] = !0, Ie = G) : Ie && (we[Ie] = !0, Ie = null));
                        Ie && (we[Ie] = !0), O.fillStyle = o.oddBackgroundColor;
                        for (var G = 1; G < F - U + 1; G++)
                            if (t || Se[G - 1]) {
                                G + U & !0 ? (O.fillStyle = o.oddBackgroundColor, O.fillRect(0, G * Y - Te, b, Y)) : (O.fillStyle = o.backgroundColor, O.fillRect(0, G * Y - Te, b, Y));
                                for (var _e = 0, Pe = i.length; _e < Pe; _e++)
                                    if (i[_e].overlay && i[_e].visible) {
                                        var Me = x[_e],
                                            Oe = G * Y - Te,
                                            Ee = B[_e],
                                            De = Y;
                                        Ce[_e] && (Me += 3, Ee -= 3, O.fillStyle = i[_e].overlay.border, O.fillRect(Me, Oe, 1, De)), we[_e] && (Ee -= 3, O.fillStyle = i[_e].overlay.border, O.fillRect(Me + Ee - 1, Oe, 1, De)), O.fillStyle = i[_e].overlay.color, O.fillRect(Me, Oe, Ee, De)
                                    }
                                ee === G + U ? (O.fillStyle = o.hovered.backgroundColor, O.fillRect(0, G * Y - Te, b, Y), O.fillStyle = o.hovered.borderColor, O.fillRect(0, G * Y - Te, b, 1), O.fillRect(0, G * Y - Te + Y - 1, b, 1), O.fillRect(0, G * Y - Te, 1, Y), O.fillRect(b - 1, G * Y - Te, 1, Y)) : te === G + U && (O.fillStyle = o.hovered.backgroundColor, O.fillRect(0, G * Y - Te, b, Y), O.fillStyle = o.hovered.borderColor, O.fillRect(0, G * Y - Te, b, 1), O.fillRect(0, G * Y - Te + Y - 1, b, 1), O.fillRect(0, G * Y - Te, 1, Y), O.fillRect(b - 1, G * Y - Te, 1, Y))
                            }
                        var Ae = 0,
                            ke = 0;
                        O.fillStyle = o.color;
                        for (var G = 0; G < F - U; G++) X = q[ye[G]], (t || Se[G]) && (ke = G * Y + Y - Te, Ae = G * Y + Z + Y - Te, G + U === ee - 1 ? O.fillStyle = o.hovered.color : G + U === te - 1 ? O.fillStyle = o.selected.color : O.fillStyle = o.color, g(O, X, be[G], G, Ae, ke)), null == X && (q[ye[G]] = be[G]);
                        O.fillStyle = o.header.backgroundColor, O.fillRect(0, 0, b, Y);
                        for (var G = 0, V = i.length; G < V; G++)
                            if (i[G].overlay && i[G].visible) {
                                var Me = x[G],
                                    Ee = B[G];
                                Ce[G] && (Me += 3, Ee -= 3, O.fillStyle = i[G].overlay.border, O.fillRect(Me, 0, 1, Y)), we[G] && (Ee -= 3, O.fillStyle = i[G].overlay.border, O.fillRect(Me + Ee - 1, 0, 1, Y)), O.fillStyle = i[G].overlay.border, O.fillRect(Me, 0, Ee, 1), O.fillRect(Me, Math.min(S - 1, (F - U + 1) * Y), Ee, 1), O.fillStyle = i[G].overlay.color, O.fillRect(Me, 0, Ee, Y)
                            }(!ne.src || ne.src.indexOf(o.sorting.caretUp) < 0) && (ne.src = o.sorting.caretUp, ie.src = o.sorting.caretDown), O.font = Q, O.fillStyle = o.header.color;
                        for (var G = 0, V = i.length; G < V; G++) n = i[G], i[G].overlay && i[G].overlay.border ? O.fillStyle = i[G].overlay.border : O.fillStyle = o.header.color, n.visible && (O.fillText(n.title, x[G] + 10, Z), n.name == fe && (pe ? O.drawImage(ne, x[G] + O.measureText(n.title).width + 10, 0) : O.drawImage(ie, x[G] + O.measureText(n.title).width + 10, 0)));
                        if (W) {
                            O.fillStyle = o.scrollbar.color;
                            var Le = (M.height - Y) / Y,
                                xe = Le / I.length * v,
                                $e = R / N * v + se,
                                Be = m + (oe - re) / 2,
                                Re = Be + re / 2,
                                Ne = Be + re;
                            O.fillRect(Be, $e, re, xe), O.beginPath(), O.moveTo(Re, 0), O.lineTo(Ne, re), O.lineTo(Be, re), O.closePath(), O.fill(), O.beginPath(), O.moveTo(Re, S), O.lineTo(Ne, S - re), O.lineTo(Be, S - re), O.closePath(), O.fill()
                        }
                        if (D.emptyRows.isWatchList && 0 == D.emptyRows.watchListLength) {
                            var Ue = M.width / 2,
                                Fe = M.height / 2;
                            O.fillStyle = o.backgroundColor, O.fillRect(0, Y, b, S), O.fillStyle = o.emptyRows.shadowBackgroundColor, O.fillRect(5, Y + 5, b - 10, S - 10), O.beginPath(), O.strokeStyle = "#FFFFFF", O.setLineDash && O.setLineDash([10, 5]), O.rect(5, Y + 5, b - 10, S - 30), O.stroke(), O.textAlign = "center", O.font = "bold 10pt Arial", O.fillStyle = o.emptyRows.colorTitle, O.fillText(D.emptyRows.emptyRowsTitle, Ue, Fe), O.textAlign = "center", O.font = "bold 10pt Arial", O.fillStyle = o.emptyRows.colorSubtitle, O.fillText(D.emptyRows.emptyRowsSubtitle, Ue, Fe + 17), O.textAlign = "center", O.font = "bold 10pt Arial", O.fillStyle = o.emptyRows.colorTitle, O.fillText(D.emptyRows.trashTitle, Ue, Fe + 40),
                                1 == D.emptyRows.culture ? O.drawImage(ue, Ue + 59, Fe + 25, 16, 20) : O.drawImage(ue, Ue + 34, Fe + 25, 16, 20), O.textAlign = "left"
                        }
                        var Ge = new Date;
                        de = Ge.getTime() - e.getTime() + 100
                    }
                }

                function u(e, t) {
                    for (var n, i, o, r, a = t.split("."), s = 0, c = a.length; s < c; s++) n = a[s], o = n.indexOf("]"), o > 0 ? (i = n.indexOf("["), r = n.substr(i + 1, o - i - 1), e = e[n.substr(0, i)][r]) : e[n] && (e = e[n]);
                    return e
                }

                function d(e, t, n) {
                    for (var i, o, r = I[n + U], a = D.columns, s = !1, c = 0, l = a.length; c < l; c++) o = a[c], i = o.type, "float" === i || "int" === i || "money" === i || "percentage" === i ? t[c] = u(r, o.name) : "string" === i && (t[c] = u(r, o.name)), e && t[c] === e[c] || (s = !0);
                    return s
                }

                function g(e, t, n, i, o, r) {
                    for (var a, s = D.columns, c = (n[L], 0), l = 0, u = s.length; l < u; l++) a = s[l], a.visible && (e.font = (a.font ? a.font : "") + K, f(e, t, n, l, i, c, o)), c++
                }

                function f(t, n, i, o, r, a, s) {
                    var c, l = D.columns[a],
                        d = l.type;
                    if (c = "float" === d ? _(i[o], ve) : "int" === d ? _(i[o], be) : "money" === d ? _(i[o], ye) : "percentage" === d ? _(i[o], Se) : i[o], l.useEllipsis) {
                        var g = t.measureText(c).width;
                        if (g > B[a] - 10) {
                            for (; g > B[a] - 10;) c = c.substr(0, c.length - 1), g = t.measureText(c).width;
                            c = c.substr(0, c.length - 1) + "..."
                        }
                    }
                    var f = "number" == typeof l.reference,
                        h = l.reference;
                    if (l.reference && !f && (h = u(I[r + U], l.reference)), l.animateOnChange && n && n[o] != i[o]) {
                        var m = p(t, r, a, n[o], i[o]);
                        t.fillText(c, x[a] + 10, s), t.fillStyle = m, n[o] = i[o]
                    } else l.reference !== e && null !== l.reference ? i[o] < h && l.color && l.color.negative ? (m = t.fillStyle, t.fillStyle = l.color.negative, t.fillText(c, x[a] + 10, s), t.fillStyle = m) : i[o] > h && l.color && l.color.positive ? (m = t.fillStyle, t.fillStyle = l.color.positive, t.fillText(c, x[a] + 10, s), t.fillStyle = m) : t.fillText(c, x[a] + 10, s) : t.fillText(c, x[a] + 10, s)
                }

                function p(e, t, n, i, o) {
                    var r = D.theme.blink,
                        a = i < o ? r.positive.color : r.negative.color,
                        s = e.fillStyle;
                    return e.fillStyle = a, e.fillRect(x[n], t * Y + Y - R % Y, B[n], Y), e.fillStyle = D.theme.color, s
                }
                var h, m, v, b = 0,
                    S = 0,
                    y = 0,
                    T = 0,
                    C = !1,
                    w = 0,
                    I = [],
                    _ = t("hbNumberFormatter"),
                    P = n(),
                    M = o[0],
                    O = M.getContext("2d"),
                    E = i.collection,
                    D = i.config,
                    A = i.sortColumn,
                    k = i.sortAsc,
                    L = i.keyColumn,
                    x = [],
                    B = [],
                    R = 0,
                    N = 0,
                    U = 0,
                    F = 0,
                    G = !1,
                    V = 0,
                    W = !1,
                    z = o,
                    H = z.closest(".gbm-monitor").parent().parent(),
                    J = z.parent().parent(),
                    q = {},
                    Y = 22,
                    X = " Helvetica",
                    j = " 1em",
                    Q = " 10px" + X,
                    K = " " + j + X,
                    Z = 16,
                    ee = -1,
                    te = -1,
                    ne = new Image,
                    ie = new Image,
                    oe = 1,
                    re = 9,
                    ae = 20,
                    se = 8,
                    C = !1,
                    ce = 0,
                    le = !1,
                    ue = new Image;
                ue.src = "Content/images/trash_blanco.png";
                var de = 100;
                i.$on("window_resized_completed", function () {
                    setTimeout(function () {
                        C = !0
                    }, 400)
                }), i.$on("$destroy", function () {
                    h && clearInterval(h)
                }), M.onmousedown = function (e) {
                    i.dragStartCallback()(null);
                    var t = M.getBoundingClientRect(),
                        n = e.clientX - t.left;
                    if (n < m + ae / 2 && n > m - ae / 2) G = !0, V = e.clientY;
                    else {
                        var o = e.clientY - t.top + R % Y,
                            r = Math.floor(o / Y);
                        i.dragStartCallback()(I[r - 1 + U])
                    }
                }, M.onmouseup = function () {
                    G = !1
                }, M.onmousemove = function (e) {
                    if (G) {
                        var t = V - e.clientY;
                        R -= t / M.height * N, R = Math.min(Math.max(0, R), N - M.height), V = e.clientY
                    } else {
                        var n = M.getBoundingClientRect(),
                            i = e.clientX - n.left;
                        if (i >= b) return void(ee = -1);
                        var o = e.clientY - n.top + R % Y;
                        ee = ~~(o / Y) + U
                    }
                }, $(M).bind("touchstart", function (e) {
                    var t = e.originalEvent.touches[0],
                        n = M.getBoundingClientRect(),
                        i = t.clientX - n.left;
                    i < m + ae / 2 && i > m - ae / 2 ? (V = t.clientY, le = !0) : (V = t.clientY, le = !1)
                }), $(M).bind("touchend", function (e) {}), $(M).bind("touchmove", function (e) {
                    var t = e.originalEvent.touches[0];
                    if (le) {
                        var n = V - t.clientY;
                        R -= n / M.height * N, R = Math.min(Math.max(0, R), N - M.height), V = t.clientY
                    } else {
                        var n = V - t.clientY;
                        R += n / M.height * N, R = Math.min(Math.max(0, R), N - M.height), V = t.clientY
                    }
                }), M.onmouseleave = function (e) {
                    ee = -1, G = !1
                }, "safari" === P ? M.addEventListener("mousewheel", a, !1) : M.addEventListener("wheel", a, !1), M.onclick = function (e) {
                    var t = M.getBoundingClientRect(),
                        n = e.clientY - t.top + R % Y,
                        o = Math.floor(n / Y),
                        r = e.clientX - t.left;
                    if (!(r >= b))
                        if (0 === o || e.clientY - t.top < Y) {
                            for (var a = 0, s = 0, c = x.length; s < c && !(r < x[s]); s++) a = s;
                            var l = D.columns[a];
                            "checkbox" !== l.type && i.columnClickCallback()(l.name)
                        } else {
                            if (o - 1 + U < 0) return;
                            for (var a = 0, s = 0, c = x.length; s < c && !(r < x[s]); s++) a = s;
                            var l = D.columns[a];
                            "checkbox" === l.type && i.buttonClickCallback()(l.name, I[o - 1 + U]), i.rowClickCallback()(I[o - 1 + U]), te = o + U
                        }
                };
                var ge = -1,
                    fe = A(),
                    pe = k(),
                    he = null,
                    me = {},
                    ve = {
                        minDecimals: 2,
                        maxDecimals: 2
                    },
                    be = {
                        maxDecimals: 0,
                        scaleLengths: [4, 6],
                        scalePrefixes: ["K", "M"],
                        scaleDecimals: [1, 1],
                        scaleDividers: [1e3, 1e6]
                    },
                    Se = {
                        minDecimals: 2,
                        maxDecimals: 2,
                        suffix: "%"
                    },
                    ye = {
                        negativePrefix: "-",
                        negativeSuffix: "",
                        currency: !0
                    };
                h = setInterval(l, de)
            }
        }
    }
    var n = "hbIeCanvasTable";
    angular.module("app").directive(n, ["$filter", "hbBrowserSvc", t])
}(),
function (e) {
    "use strict";

    function t(t, n, i) {
        return {
            restrict: "A",
            transclude: !0,
            scope: {
                tabs: "=hbTabbedPaneTabs",
                selectedTabId: "=hbTabbedPaneSelectedId",
                newTabCallback: "&hbTabbedPaneNewCallback",
                tabMenuCallback: "&hbTabbedPaneMenuCallback",
                tabMenuItemsBuilder: "&hbTabbedPaneMenuItemsBuilder",
                tabDropCallback: "&hbTabbedPaneDropCallback",
                tabDragOverCallback: "&hbTabbedPaneDragOverCallback",
                tabsSorted: "&hbTabbedPaneTabsSorted",
                sortingProperty: "@hbTabbedPaneSortingProperty",
                options: "=hbTabbedPaneOptions",
                tabClass: "=hbTabbedPaneTabsClass",
                contentClass: "=hbTabbedPaneContentClass",
                isMobile: "=hbTabbedPaneIsMobile",
                debug: "=hbTabbedPaneDebug"
            },
            link: function (e, t, n) {
                var i = t.find(".custom-controls");
                if (i && i.length > 0) {
                    var o = t.find(".hb-tab-controls-container");
                    o.append(i)
                }
            },
            controller: ["$scope", "$sce", "$attrs", function (t, o, r) {
                function a() {
                    s(), S = t.$watch(function () {
                        return t.selectedTabId
                    }, function (e, t) {
                        e !== t && s()
                    })
                }

                function s() {
                    for (var n = 0; n < t.tabs.length; n++) {
                        var i = t.tabs[n].id === e ? t.tabs[n].dashBoardId : t.tabs[n].id;
                        if (i === t.selectedTabId) {
                            t.selectedItem = t.tabs[n];
                            break
                        }
                    }
                }

                function c() {
                    var e = angular.element("." + t.instanceId),
                        n = e.children(".hb-tabs-container"),
                        i = n.children(".hb-tabs").children(".hb-tabitem"),
                        o = ~~(100 / i.length);
                    i.css("width", o + "%"), $(i[0]).css("width", o + (100 - o * i.length) + "%"), n.width("100%")
                }

                function l() {
                    setTimeout(function () {
                        d(), u()
                    }, 0)
                }

                function u() {
                    var e = angular.element("." + t.instanceId),
                        n = e.width(),
                        i = e.children(".hb-tab-controls-container").width();
                    if (t.isWide) c();
                    else {
                        var o = e.children(".hb-tabs-container"),
                            r = o.children(".hb-tabs").width();
                        r = Math.min(r, n - i), r > 0 && o.width(r)
                    }
                    p()
                }

                function d() {
                    var e = angular.element("." + t.instanceId);
                    if (0 !== e.children(".hb-tabs-container").children(".hb-tabs").length) {
                        var n = e.children(".hb-tabs-container").children(".hb-tabs")[0].offsetWidth,
                            i = e.width(),
                            o = e.children(".hb-tab-controls-container").width();
                        if (n > i - o) {
                            if (t.isWide) c();
                            else {
                                var r = e.children(".hb-tabs-container"),
                                    a = r.children(".hb-tabs").width();
                                a = Math.min(a, i - o), r.width(a)
                            }
                            p(), t.previousTabCount !== t.tabs.length && g()
                        } else t.isWide ? c() : e.children(".hb-tabs-container").width(n), p();
                        t.previousTabCount = t.tabs.length
                    }
                }

                function g() {
                    var e = angular.element(".hb-tabitem.selected"),
                        n = e.offset();
                    if (n) {
                        var i = e.parent().parent(),
                            o = i.offset(),
                            r = n.left - o.left;
                        if (r + e.width() > i.width()) {
                            t.offset = -r;
                            var a = angular.element("." + t.instanceId).children(".hb-tabs-container"),
                                s = a.width(),
                                c = a.children(".hb-tabs").width(),
                                l = -(c - s);
                            l >= t.offset && (t.offset = l), 0 !== t.offset && f(t.offset)
                        }
                    }
                }

                function f(e) {
                    var n = $(angular.element("." + t.instanceId).children(".hb-tabs-container").children(".hb-tabs")[0]);
                    n.clearQueue(), n.stop(), n.animate({
                        left: e
                    })
                }

                function p() {
                    var e = angular.element("." + t.instanceId);
                    t.offset >= 0 ? (t.offset = 0, e.find(".left-slide").addClass("disabled")) : e.find(".left-slide").removeClass("disabled");
                    var n = e.children(".hb-tabs-container"),
                        i = n.width(),
                        o = n.children(".hb-tabs").width(),
                        r = -(o - i);
                    r >= t.offset ? (t.offset = r, e.find(".right-slide").addClass("disabled")) : e.find(".right-slide").removeClass("disabled")
                }

                function h() {
                    var e = (new Date).getTime(),
                        t = "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function (t) {
                            var n = (e + 16 * Math.random()) % 16 | 0;
                            return e = Math.floor(e / 16), ("x" == t ? n : 7 & n | 8).toString(16)
                        });
                    return t
                }

                function m(e, t) {
                    var n = /^\w+[\s\w+]*$/.test(t.name);
                    if (!n) return void(t.invalidName = !0);
                    switch (t.invalidName = !1, e.keyCode) {
                        case 13:
                            t && "function" == typeof t.editNameCallback && t.editNameCallback(!0).then(function (e) {
                                return t.editName = !1, l(), e
                            }, function (e) {
                                t.invalidName = !0
                            });
                            break;
                        case 27:
                            t && (t.editName = !1, t && "function" == typeof t.editNameCallback && t.editNameCallback(!1))
                    }
                }

                function v(e) {
                    e && (e.invalidName = !1, e.editName = !1, "function" == typeof e.editNameCallback && e.editNameCallback(!1))
                }

                function b(e) {
                    var n, i = t.tabs.filter(function (t) {
                        return t.id == e
                    });
                    return i.length > 0 && (n = i[0]), n
                }
                t.offset = 0, t.previousTabCount = 0, t.dndHelper = n, t.tabSortingEnabled = null !== t.sortingProperty && t.sortingProperty !== e, t.isWide = !1, t.isSlim = !1, t.options && (t.options.wide && (t.isWide = !0), t.options.slim && (t.isSlim = !0));
                var S = null;
                if (t.isMobile && a(), t.isMobile !== e && t.$watch(function () {
                        return t.isMobile
                    }, function (t, n) {
                        t !== e && (null !== S && S(), t && a())
                    }), !t.tabSortingEnabled) {
                    t.sortingProperty = "sortOrder";
                    for (var y = 0, T = t.tabs.length; y < T; y++) t.tabs[y][t.sortingProperty] = y
                }
                t.tabMenuSelected = function (e, n, i) {
                    return i.preventDefault(), i.stopPropagation(), t.isMobile ? t.tabMenuCallback().call(t.$parent, t.selectedItem, n) : t.tabMenuCallback().call(t.$parent, e, n), e.isContextMenuOpen = !1, !1
                }, t.instanceId = h(), t.selectTab = function (e) {
                    e && e.id !== t.selectedTabId && (t.animateSlide = !0, t.selectedTabId = e.id, t.isMobile && s())
                }, t.createNewTab = function () {
                    t.newTabCallback().call(t.$parent)
                }, t.isWide && i(c, 500);
                t.$watchCollection("tabs", function (e, t) {
                    l()
                }), $(window).resize(function () {
                    l()
                }), t.onKeyUp = m, t.onBlur = v, t.leftSlide = function () {
                    angular.element("." + t.instanceId + " .left-slide").hasClass("disabled") || (t.offset += 100, p(), f(t.offset))
                }, t.rightSlide = function () {
                    angular.element("." + t.instanceId + " .right-slide").hasClass("disabled") || (t.offset -= 100, p(), f(t.offset))
                }, t.renderHtml = function (e) {
                    return o.trustAsHtml(e)
                }, t.dropCallback = function (e, n, i, o) {
                    t.tabDropCallback && t.tabDropCallback() && t.tabDropCallback()(i, o), t.dndHelper.clearMessage()
                }, t.dragOverCallback = function (e, i, o) {
                    if (t.draggedTab) {
                        for (var r, a, s = t.tabs, c = 0, l = s.length; c < l; c++) s[c] === o && (r = c), s[c] === t.draggedTab && (a = c);
                        var u = s[r];
                        return s[r] = s[a], void(s[a] = u)
                    }
                    t.tabDragOverCallback && t.tabDragOverCallback() ? t.tabDragOverCallback()(o) : n.accepts(["inexisting-source"])
                }, t.dragCallback = function (e, n, i) {
                    if (t.tabSortingEnabled) {
                        t.draggedTab !== i && (t.draggedTab = i);
                        var o = $(n.helper.context).prev();
                        o = o.hasClass("cloned-tab") ? o.prev() : o;
                        var r = o && o.length > 0 ? o.offset().left + o.width() / 2 : -1,
                            a = $(n.helper.context).next();
                        a = a.hasClass("cloned-tab") ? a.next() : a;
                        var s = a && a.length > 0 ? a.offset().left + a.width() / 2 : -1;
                        r > n.offset.left && o.before(n.helper.context), s < n.offset.left + n.helper.width() && a.after(n.helper.context)
                    }
                }, t.updateTabSorting = function (e, n, i) {
                    t.draggedTab && (t.draggedTab = null, $(n.helper).closest("ul").find("li[data-tabid]:not(.cloned-tab)").each(function (e, n) {
                        var i = b(n.attributes["data-tabid"].value);
                        i && (i[t.sortingProperty] = e)
                    }), t.tabsSorted()())
                }, t.dragOutCallback = function () {
                    t.draggedTab || n.out()
                }, t.getTabClone = function (e) {
                    var t = $(e.currentTarget).clone();
                    return t.addClass("cloned-tab").css("opacity", .5), t
                }, t.animateSlide = !1
            }],
            templateUrl: "app/directives/hb-tabbed-pane-template.html"
        }
    }

    function n() {
        return {
            addClass: function (e, t, n) {
                var i = e.offset(),
                    o = e.position(),
                    r = e.parents(".box-content");
                if (0 !== r.length) {
                    e.css({
                        position: "absolute",
                        left: 2 * o.left,
                        opacity: 0,
                        width: r.width(),
                        height: r.height() - (i.top - r.offset().top),
                        overflow: "hidden",
                        display: "block"
                    }), $(e).animate({
                        left: o.left,
                        opacity: 1
                    }, {
                        duration: 500,
                        queue: !1,
                        always: function () {
                            e.css({
                                position: "",
                                top: "",
                                left: "",
                                height: "",
                                width: "",
                                display: "",
                                overflow: ""
                            }), n()
                        }
                    });
                    var a = e.scope();
                    return a.animateSlide = !1,
                        function () {
                            var t = e.scope();
                            t.animateSlide && (t.animateSlide = !1)
                        }
                }
            }
        }
    }
    var i = "hbTabbedPane";
    angular.module("app").directive(i, ["$document", "hbDragNDropHelperSvc", "$timeout", t]), angular.module("app").animation(".slide-content", n)
}(),
function () {
    "use strict";
    var e = "hbBoxesMonitor";
    angular.module("app").directive(e, function () {
        return {
            scope: {
                issues: "=hbBoxesMonitor"
            },
            controller: ["$scope", function (e) {
                function t() {
                    e.minChange = 1e6, e.maxChange = -1e6, e.maxVolume = 0
                }

                function n() {
                    if (e.issues) {
                        e.issues.length !== e.issuesCount && (t(), e.issuesCount = e.issues.length);
                        for (var n = e.maxVolume, i = e.minChange, o = e.maxChange, r = 0, a = e.issues.length; r < a; r++) i > e.issues[r].hechos.body.changeAvg ? i = e.issues[r].hechos.body.changeAvg : o < e.issues[r].hechos.body.changeAvg && (o = e.issues[r].hechos.body.changeAvg), (!n || n < e.issues[r].hechos.body.aggVolume) && (n = e.issues[r].hechos.body.aggVolume);
                        e.maxVolume = n, e.minChange = i, e.maxChange = o
                    }
                }
                e.selectedBoxes = function (e) {
                    return e.hechos.body.aggVolume > 0
                }, this.scope = e, e.issuesCount = 0, n();
                var i = setInterval(n, 1e3);
                e.$on("$destroy", function () {
                    clearInterval(i)
                })
            }]
        }
    }), angular.module("app").directive("hbBoxesMonitorBox", function () {
        return {
            require: "^hbBoxesMonitor",
            scope: {
                issue: "=hbBoxesMonitorBox",
                selectedIssueCallback: "&hbBoxesMonitorBoxCallback",
                getMessage: "&hbBoxesMonitorBoxGetMessage",
                startDrag: "&hbBoxesMonitorBoxStartDrag",
                onDrop: "&hbBoxesMonitorBoxOnDrop",
                onOver: "&hbBoxesMonitorBoxOnOver",
                onOut: "&hbBoxesMonitorBoxOnOut"
            },
            link: function (e, t, n, i) {
                function o() {
                    if (!i.scope.maxVolume) return "1em";
                    var e = a.issue.hechos.body.aggVolume / i.scope.maxVolume,
                        t = 1.3 * e + .7;
                    a.fontSize = t + "em"
                }

                function r() {
                    if (a.issue.hechos.body.changeAvg > 0) {
                        var e = a.issue.hechos.body.changeAvg / i.scope.maxChange * l;
                        e = Math.min(~~(e + s), 255), a.backgroundColor = "#00" + e.toString(16) + "00"
                    } else if (a.issue.hechos.body.changeAvg < 0) {
                        var e = a.issue.hechos.body.changeAvg / i.scope.minChange * l;
                        e = Math.min(~~(e + s), 255), a.backgroundColor = "#" + e.toString(16) + "0000"
                    } else a.backgroundColor = "#000000"
                }
                var a = e,
                    s = 128,
                    c = 255,
                    l = c - s;
                a.$watch("issue.hechos.body.aggVolume", function () {
                    o()
                }), a.$watch("issue.hechos.body.changeAvg", function () {
                    r()
                }), i.scope.$watch("maxVolume", function () {
                    o()
                }), i.scope.$watch("maxChange", function () {
                    r()
                }), i.scope.$watch("minChange", function () {
                    r()
                }), a.selectedIssue = function (e) {
                    a.selectedIssueCallback().call(a.$parent, e)
                }, a.startDragIssue = function (e) {
                    a.startDrag().call(a.$parent, e)
                }, a.onDropIssue = function () {
                    a.onDrop().call(a.$parent, a.getMessage())
                }, a.onOverIssue = function () {
                    a.onOver().call(a.$parent)
                }, a.onOutIssue = function () {
                    a.onOut().call(a.$parent)
                }, o(), r()
            },
            templateUrl: "app/directives/hb-boxes-monitor-box-template.html"
        }
    })
}(),
function () {
    "use strict";
    var e = "hbFixedBoxesMonitor";
    angular.module("app").directive(e, function () {
        return {
            scope: {
                issues: "=hbFixedBoxesMonitor"
            },
            controller: ["$scope", "$element", function (e, t) {
                function n() {
                    e.minChange = 1e6, e.maxChange = -1e6, e.maxVolume = 0
                }

                function i() {
                    if (e.issues) {
                        e.issues.length !== e.issuesCount && (n(), e.issuesCount = e.issues.length);
                        for (var t = e.maxVolume, i = e.minChange, o = e.maxChange, r = 0, a = e.issues.length; r < a; r++) i > e.issues[r].hechos.body.changeAvg ? i = e.issues[r].hechos.body.changeAvg : o < e.issues[r].hechos.body.changeAvg && (o = e.issues[r].hechos.body.changeAvg), (!t || t < e.issues[r].hechos.body.aggVolume) && (t = e.issues[r].hechos.body.aggVolume);
                        e.maxVolume = t, e.minChange = i, e.maxChange = o
                    }
                }
                e.selectedBoxes = function (e) {
                    return e.hechos.body.aggVolume > 0
                }, this.scope = e, e.issuesCount = 0, i();
                var o = setInterval(i, 1e3);
                e.$on("$destroy", function () {
                    clearInterval(o)
                })
            }]
        }
    }), angular.module("app").directive("hbFixedBoxesMonitorBox", function () {
        return {
            require: "^hbFixedBoxesMonitor",
            scope: {
                issue: "=hbFixedBoxesMonitorBox"
            },
            link: function (e, t, n, i) {
                function o() {
                    if (!i.scope.maxVolume) return void(a.boxClass = "box-1");
                    var e = a.issue.hechos.body.aggVolume / i.scope.maxVolume;
                    e < .25 ? a.boxClass = "box-1" : e < .5 ? a.boxClass = "box-2" : e < .75 ? a.boxClass = "box-3" : e < 1 && (a.boxClass = "box-4")
                }

                function r() {
                    if (a.issue.hechos.body.changeAvg > 0) {
                        var e = a.issue.hechos.body.changeAvg / i.scope.maxChange * l;
                        e = Math.min(~~(e + s), 255), a.backgroundColor = "#00" + e.toString(16) + "00"
                    } else if (a.issue.hechos.body.changeAvg < 0) {
                        var e = a.issue.hechos.body.changeAvg / i.scope.minChange * l;
                        e = Math.min(~~(e + s), 255), a.backgroundColor = "#" + e.toString(16) + "0000"
                    } else a.backgroundColor = "#000000"
                }
                var a = e,
                    s = 128,
                    c = 255,
                    l = c - s;
                a.$watch("issue.hechos.body.aggVolume", function () {
                    o()
                }), a.$watch("issue.hechos.body.changeAvg", function () {
                    r()
                }), i.scope.$watch("maxVolume", function () {
                    o()
                }), i.scope.$watch("maxChange", function () {
                    r()
                }), i.scope.$watch("minChange", function () {
                    r()
                }), o(), r()
            },
            templateUrl: "app/directives/hb-fixed-boxes-monitor-box-template.html"
        }
    })
}(),
function (e) {
    "use strict";

    function t(e) {
        function t(t, n) {
            var i = e(n.hbInputFocus);
            return function (e, t, n) {
                e.$watch(i, function (e) {
                    e && t[0].focus()
                })
            }
        }
        return {
            restrict: "A",
            compile: t
        }
    }
    var n = "hbInputFocus";
    e.directive(n, ["$parse", t])
}(angular.module("app")),
function () {
    "use strict";

    function e(e, t) {
        function n(n, i, o, r) {
            function a(t) {
                switch (l.test(t) || (t = 0, r.$setViewValue(t), r.$render()), c = o.hbFormat.split(":"), c[0]) {
                    case "currency":
                        i.val("$" + e("number")(t, void 0 === c[1] ? 0 : c[1]));
                        break;
                    case "percentage":
                        i.val(e("number")(t, void 0 === c[1] ? 0 : c[1]) + "%");
                        break;
                    case "currencyPrice":
                        i.val("$" + e("number")(t, t < 1 ? 3 : 2));
                        break;
                    case "currencyPriceFund":
                        i.val("$" + e("number")(t, 6));
                        break;
                    case "onlyNumbers":
                        i.val(t);
                        break;
                    default:
                        i.val(e("number")(t, void 0 === c[1] ? 0 : c[1]))
                }
            }

            function s() {
                i.val(i.val().replace("$", "")), i.val(i.val().replace("%", ""))
            }
            var c = o.hbFormat.split(":");
            o.$observe("hbFormat", function (e) {
                a(r.$viewValue)
            });
            var l = /^\d*\.?\d*$/,
                u = function () {
                    s();
                    var e = i.val().replace(/,/g, "");
                    a(e)
                };
            r.$render = function () {
                var e = r.$viewValue;
                a(e)
            }, i.bind("blur", u), i.bind("paste cut", function () {
                t.defer(u)
            }), i.bind("focus", function () {
                "$0.000" == i[0].value ? i[0].value = "" : (i.val(i.val().replace(/,/g, "")), s()), "onlyNumbers" === o.hbFormat && "0" === i[0].value && (i[0].value = "")
            })
        }
        return {
            restrict: "A",
            require: "?ngModel",
            link: n
        }
    }
    var t = "hbFormat";
    angular.module("app").directive(t, ["$filter", "$browser", e])
}(),
function (e) {
    "use strict";

    function t() {
        return {
            restrict: "A",
            scope: {
                nextIndex: "=hbFocusNextOnEnter"
            },
            link: function (t, n, i) {
                var o = angular.element("[data-focusable]");
                o && 0 !== o.length || (o = angular.element("[focusable]")), o.sort(function (e, t) {
                    return parseInt(angular.element(e).data("focusable")) - parseInt(angular.element(t).data("focusable"))
                }), n.bind("keydown", function (i) {
                    var r = i.keyCode || i.which;
                    if (13 === r) {
                        var a = 0;
                        null !== t.nextIndex && t.nextIndex !== e ? a = t.nextIndex : (n.attr("focusable") || n.attr("data-focusable")) && (a = parseInt(n.attr("focusable") || n.attr("data-focusable")) + 1), "undefined" != typeof o[a] && o[a].focus()
                    }
                })
            }
        }
    }
    var n = "hbFocusNextOnEnter";
    angular.module("app").directive(n, [t])
}(),
function () {
    "use strict";

    function e() {
        return {
            restrict: "A",
            require: "?ngModel",
            link: function (e, t, n, i) {
                i && (i.$parsers.push(function (e) {
                    var t = 0;
                    return t = String(e).replace(/[^0-9]+/g, ""), String(e) !== String(t) && (i.$setViewValue(parseInt(t)), i.$render()), parseInt(t)
                }), t.bind("keypress", function (e) {
                    32 === e.keyCode && e.preventDefault()
                }), t.bind("focus", function (e) {
                    0 == t[0].value && (t[0].value = "")
                }))
            }
        }
    }
    var t = "hbNumberOnlyInput";
    angular.module("app").directive(t, ["common", e])
}(),
function (e) {
    "use strict";

    function t(e, t, n) {
        return {
            restrict: "A",
            link: function (e, i, o) {
                function r() {
                    s && (s.spin(i[0]), c(e) || (i[0].disabled = !0))
                }

                function a() {
                    s && (s.stop(), c(e) || (i[0].disabled = !1))
                }
                var s = null,
                    c = t(o.hbSpinnerEnableAlways),
                    l = t(o.hbSpinnerIndicator);
                e.$watch(o.hbSpinner, function (e) {
                    s = new n.Spinner(e)
                }, !0), e.$watch(function (e) {
                    return l(e)
                }, function (e) {
                    e ? r() : a()
                })
            }
        }
    }
    var n = "hbSpinner";
    angular.module("app").directive(n, ["$compile", "$parse", "$window", t])
}(),
function (e) {
    "use strict";

    function t(t, n) {
        function i(e, t) {
            t ? ["a", "i", "div"].indexOf(e[0].localName) >= 0 ? e.addClass("deactive") : e[0].disabled = !0 : ["a", "i", "div"].indexOf(e[0].localName) >= 0 ? e.removeClass("deactive") : e[0].disabled = !1
        }
        return {
            restrict: "A",
            link: function (n, o, r) {
                r.hbDebounceFlag !== e ? n.$watch(function () {
                    return n[r.hbDebounceFlag]
                }, function (e, t) {
                    i(o, e)
                }) : r.hbDebounceSeconds && o.bind("click", function () {
                    i(o, !0);
                    var e = 1e3 * parseInt(r.hbDebounceSeconds);
                    t(function () {
                        i(o, !1)
                    }, e)
                })
            }
        }
    }
    var n = "hbDebounce";
    angular.module("app").directive(n, ["$timeout", "$compile", t])
}(),
function (e) {
    "use strict";

    function t() {
        return {
            restrict: "A",
            link: function (e, t, n) {
                e.$watch(t.data("hbFocusOnce"), function (n, i) {
                    n && (t.focus(), e.trigger = !1)
                })
            }
        }
    }
    var n = "hbFocusOnce";
    angular.module("app").directive(n, [t])
}(),
function () {
    "use strict";
    angular.module("app").directive("hbToggleSwitch", [function () {
        var e = 0;
        return {
            restrict: "A",
            scope: {
                status: "=hbToggleSwitch",
                beforeCb: "&hbToggleSwitchBefore",
                labels: "=hbToggleSwitchLabels",
                loading: "=hbToggleSwitchLoading"
            },
            template: function (e, t) {
                return '<div class="toggle-switch" data-ng-click="toggle()" data-hb-debounce data-hb-debounce-seconds="2"><div data-ng-if="loading" class="loading-mask"></div><div class="off-state state" data-ng-class="{ \'off-state-visible\': !status, \'off-state-hidden\': status }"><div class="state-label">{{labels.off}}</div><div class="indicator"></div></div><div class="on-state state" data-ng-class="{ \'on-state-visible\': status, \'on-state-hidden\': !status }"><div class="indicator"></div><div class="state-label">{{labels.on}}</div></div></div>'
            },
            transclude: !0,
            link: function (t, n, i, o, r) {
                function a() {
                    r(t.$parent, function (e, t) {
                        for (var i = 0, o = e.length; i < o; i++) {
                            var r = angular.element(e[i]),
                                a = r.attr("data-hb-toggle-switch-off"),
                                s = r.attr("data-hb-toggle-switch-on");
                            void 0 !== a && a !== !1 && (n.find(".off-state .state-label").remove(), n.find(".off-state").prepend(r)), void 0 !== s && s !== !1 && (n.find(".on-state").append(r), n.find(".on-state .state-label").remove())
                        }
                    }), "boolean" != typeof t.status && (t.status = !1), t.labels.on || (t.labels.on = "On"), t.labels.off || (t.labels.off = "Off");
                    for (var e = c(), i = n.find(".state-label"), o = 0, a = i.length; o < a; o++) {
                        var l = angular.element(i[o]);
                        l.css("width", e + "px");
                        var u = Math.ceil(parseFloat(l.css("margin-left")) + parseFloat(l.css("margin-right")));
                        p = Math.max(p, e + u);
                        var d = l.parent();
                        u = Math.ceil(parseFloat(d.css("margin-left")) + parseFloat(d.css("margin-right"))), f = Math.max(f, l.parent().width() + u)
                    }
                    n.css("width", f), n.addClass(g), s(p)
                }

                function s(e) {
                    var t = document.createElement("style");
                    t.type = "text/css", t.innerHTML = "." + g + " .on-state-visible { left: 0; } ." + g + " .on-state-hidden { left: " + e + "px; } ." + g + " .off-state-visible { left: 0; } ." + g + " .off-state-hidden { left: -" + e + "px; }", document.getElementsByTagName("head")[0].appendChild(t)
                }

                function c() {
                    var e = 0,
                        i = angular.element('<div style="position: absolute; float: left; white-space: nowrap; visibility: hidden;"></div>');
                    return n.append(i), e = Math.max(e, l(i, n.find("[data-hb-toggle-switch-on]"), t.labels.on)), e = Math.max(e, l(i, n.find("[data-hb-toggle-switch-off]"), t.labels.off)), i.remove(), e
                }

                function l(e, t, n) {
                    var i = 0;
                    return t.length > 0 ? i = Math.max(i, Math.ceil(t.width())) : (e.html(n), i = Math.ceil(e.width())), i
                }

                function u() {
                    t.beforeCb() ? t.beforeCb()(!t.status).then(function () {
                        t.status = !t.status
                    }, function () {}) : t.status = !t.status
                }
                var d = e++,
                    g = "toggle-switch-" + d,
                    f = 0,
                    p = 0;
                n.find(".off-state"), n.find(".on-state");
                t.$watch("status", function (e, t) {}), t.toggle = u, a()
            }
        }
    }])
}(),
function () {
    "use strict";
    angular.module("app").filter("hbCustomCurrency", ["$filter", function (e) {
        return function (t, n) {
            var i = e("currency");
            return t < 0 ? i(t, n).replace("(", "-").replace(")", "") : i(t, n)
        }
    }])
}(),
function () {
    "use strict";
    angular.module("app").filter("hbNumberFormatter", ["$locale", function (e) {
        function t() {
            e.NUMBER_FORMATS && (e.NUMBER_FORMATS.DECIMAL_SEP && (n.decimalSeparator = e.NUMBER_FORMATS.DECIMAL_SEP, i.decimalSeparator = e.NUMBER_FORMATS.DECIMAL_SEP), e.NUMBER_FORMATS.GROUP_SEP && (n.groupSeparator = e.NUMBER_FORMATS.GROUP_SEP, i.groupSeparator = e.NUMBER_FORMATS.GROUP_SEP), e.NUMBER_FORMATS.PATTERNS && e.NUMBER_FORMATS.PATTERNS.length && e.NUMBER_FORMATS.PATTERNS.length > 1 && (e.NUMBER_FORMATS.PATTERNS[0].minFrac && (n.minDecimals = e.NUMBER_FORMATS.PATTERNS[0].minFrac), e.NUMBER_FORMATS.PATTERNS[0].maxFrac && (n.maxDecimals = e.NUMBER_FORMATS.PATTERNS[0].maxFrac), e.NUMBER_FORMATS.PATTERNS[0].negPre && (n.negativePrefix = e.NUMBER_FORMATS.PATTERNS[0].negPre), e.NUMBER_FORMATS.PATTERNS[0].negSuf && (n.negativeSuffix = e.NUMBER_FORMATS.PATTERNS[0].negSuf), e.NUMBER_FORMATS.PATTERNS[1].minFrac && (i.minDecimals = e.NUMBER_FORMATS.PATTERNS[1].minFrac), e.NUMBER_FORMATS.PATTERNS[1].maxFrac && (i.maxDecimals = e.NUMBER_FORMATS.PATTERNS[1].maxFrac), e.NUMBER_FORMATS.PATTERNS[1].negPre && (i.negativePrefix = e.NUMBER_FORMATS.PATTERNS[1].negPre), e.NUMBER_FORMATS.PATTERNS[1].negSuf && (i.negativeSuffix = e.NUMBER_FORMATS.PATTERNS[1].negSuf)), e.NUMBER_FORMATS.CURRENCY_SYM && (i.prefix = e.NUMBER_FORMATS.CURRENCY_SYM))
        }
        var n = {
                decimalSeparator: ".",
                groupSeparator: ",",
                minDecimals: 0,
                maxDecimals: 3,
                negativePrefix: "-",
                negativeSuffix: "",
                prefix: "",
                suffix: "",
                scaleLengths: [],
                scalePrefixes: [],
                scaleDecimals: [],
                scaleDividers: []
            },
            i = {
                decimalSeparator: ".",
                groupSeparator: ",",
                minDecimals: 2,
                maxDecimals: 2,
                negativePrefix: "(",
                negativeSuffix: ")",
                prefix: "$",
                suffix: "",
                scaleLengths: [],
                scalePrefixes: [],
                scaleDecimals: [],
                scaleDividers: []
            };
        return t(),
            function (e, t) {
                e = +e || 0;
                var o = {};
                if (t && t.currency)
                    for (var r in i) o[r] = i[r];
                else
                    for (var r in n) o[r] = n[r];
                for (var r in t) o[r] = t[r];
                var a, s = "",
                    c = o.maxDecimals,
                    l = o.minDecimals,
                    u = "",
                    d = Math.abs(parseFloat(e)),
                    g = "";
                if (t.currency && d < 1) c = parseFloat(d.toFixed(3)) < 1 ? 3 : c, d = parseFloat(d.toFixed(c)), a = Math.floor(Math.abs(d)), u = a + "", g = (d - a).toFixed(c).slice(2);
                else
                    for (d = parseFloat(d.toFixed(c)), a = Math.floor(Math.abs(d)), u = a + "", g = (d - a).toFixed(c).slice(2); c > l && "0" === g[g.length - 1];) g = g.slice(0, g.length - 1), c--;
                for (var f = -1, p = o.scaleLengths.length - 1; p >= 0; p--)
                    if (o.scaleLengths[p] < u.length) {
                        f = p;
                        break
                    }
                if (f >= 0) {
                    var h = o.scaleLengths[f],
                        m = 0 === o.scaleDividers.length ? Math.pow(10, h) : o.scaleDividers[f];
                    s = (a / m).toFixed(o.scaleDecimals[f]) + o.scalePrefixes[f]
                } else {
                    var v;
                    v = (v = u.length) > 3 ? v % 3 : 0, u = (v ? u.substr(0, v) + o.groupSeparator : "") + u.substr(v).replace(/(\d{3})(?=\d)/g, "$1" + o.groupSeparator), s += u, g.length > 0 && (s += o.decimalSeparator + g)
                }
                return s = o.prefix + s + o.suffix, e < 0 && (s = o.negativePrefix + s + o.negativeSuffix), s
            }
    }])
}(),
function () {
    "use strict";
    angular.module("app").directive("hbIframeOnload", [function () {
        return {
            scope: {
                callBack: "&hbIframeOnload"
            },
            link: function (e, t, n) {
                function i() {
                    e.callBack(), o()
                }

                function o() {
                    t[0].removeEventListener("load", i, !0), t[0].addEventListener("load", i, !1)
                }
                o()
            }
        }
    }])
}(),
function () {
    "use strict";

    function e() {
        return {
            link: function (e, t, n) {
                var i = parseInt(n.slideToggleDuration, 10) || 500;
                n.$observe("hbSlideToggle", function (e) {
                    "true" == e ? t.stop().slideDown(i) : t.stop().slideUp(i)
                })
            }
        }
    }
    angular.module("app").directive("hbSlideToggle", [e])
}(),
function (e) {
    "use strict";
    var t = "hbEndRepeat";
    angular.module("app").directive(t, ["$timeout", function (e) {
        return {
            restrict: "A",
            link: function (t, n, i) {
                t.$last === !0 && e(function () {
                    t.$emit("ngRepeatFinished")
                })
            }
        }
    }])
}(),
function () {
    "use strict";

    function e(e, n, i, o, r, a, s, c, l) {
        function u() {
            p.startDissolving = !0, $(".loading-overlay").on("transitionend webkitTransitionEnd oTransitionEnd MSTransitionEnd", function () {
                l.$apply(function () {
                    p.displayLoading = !1
                })
            })
        }

        function d() {
            o.logging("HomeBroker dashboard loaded!", o.loggingTypes.DEBUG), n.activateController([r.load("Dashboard")], t)
        }

        function g(e) {
            p.isBusy = e
        }

        function f() {
            c.reset(), c.setInitialLoading(!0), p.displayLoading = !0, p.startDissolving = !1
        }
        var p = this,
            h = i.events;
        p.isBusy = !0, p.spinnerOptions = {
            radius: 40,
            lines: 7,
            length: 0,
            width: 30,
            speed: 1.7,
            corners: 1,
            trail: 100,
            color: "#F58A00"
        }, p.dashboardLoaded = !1, p.displayLoading = !1, p.startDissolving = !1, p.loadingState = c.state, p.progress = 0, p.currentTask = "", e.$on("loading.tasks_completed", function (e, t) {
            p.dashboardLoaded = !0, u()
        }), d(), e.$on("$routeChangeStart", function (e, t, n) {
            "loadPartial/Dashboard/Index" === t.loadedTemplateUrl || "loadPartial/Dashboard/Index" === t.$$route.templateUrl ? f() : p.displayLoading = !1
        }), "loadPartial/Dashboard/Index" === a.current.templateUrl && f(), e.$on(h.controllerActivateSuccess, function (e) {
            g(!1)
        }), e.$on(h.spinnerToggle, function (e) {
            g(e.show)
        })
    }
    var t = "shell";
    angular.module("app").controller(t, ["$rootScope", "common", "config", "hbLoggingSvc", "hbGlobalizationSvc", "$route", "$timeout", "hbLoadingSvc", "$scope", e])
}(),
function () {
    "use strict";

    function e(e, t, n, i, o, r, a, s, c, l, u, d, g, f, p, h, m, v, b, S, y, T, C, w, I) {
        function _(e) {
            T.getUserConfiguration().then(function (t) {
                var n = t;
                n.solaceNotifications = e, T.updateUserConfiguration(n).then(function () {})
            })
        }

        function P() {
            ee = setInterval(function () {
                te && (K.timeOfDay = A(), e.$$phase || e.$digest())
            }, 1e3, 0, !1)
        }

        function M() {
            O(), ne = setInterval(function () {
                D()
            }, ie)
        }

        function O() {
            ne && clearInterval(ne)
        }

        function E(e, t) {
            K.amountSelected.label = e, K.amountSelected.amount = t, K.displayPositionDropdown = !1
        }

        function D() {
            te = !1, ee || P(), K.user.user && (O(), p.getCentralHour().then(function (e) {
                e.data.response;
                te = !0, K.dayOfTheWeek = k(), K.shortDate = L(), K.scheduleStatus = x()
            })["finally"](function () {
                M()
            }))
        }

        function A() {
            var e = moment().tz("America/Mexico_City");
            return e.format("HH:mm:ss")
        }

        function k() {
            var e = new Date,
                t = e.getDay();
            return d.getResource("TopNav_DayOfTheWeek_" + t, !0)
        }

        function L() {
            var e = new Date,
                t = e.getMonth() + 1,
                n = e.getDate();
            return (n < 10 ? "0" + n : n) + "/" + (t < 10 ? "0" + t : t) + "/" + e.getFullYear()
        }

        function x() {
            var e = new Date,
                t = e.getMinutes(),
                n = (e.getSeconds(), e.getHours());
            if (!oe || !re) return "";
            if (n >= oe.getHours() && n <= re.getHours())
                if (n === oe.getHours()) {
                    if (t >= oe.getMinutes()) return K.outOfSchedule = !1, d.getResource("TopNav_InOperationSchedule", !0)
                } else {
                    if (n !== re.getHours()) return K.outOfSchedule = !1, d.getResource("TopNav_InOperationSchedule", !0);
                    if (t < re.getMinutes()) return K.outOfSchedule = !1, d.getResource("TopNav_InOperationSchedule", !0)
                }
            return K.outOfSchedule = !0, d.getResource("TopNav_OutOfOperationSchedule", !0)
        }

        function $() {
            U();
            var e = [R(), d.load("TopNav")];
            g.$q.all(e).then(function () {
                D(), B(), K.totalLabel = d.getResource("TopNav_Total", !0), K.buyPowerLabel = d.getResource("TopNav_BuyPower", !0), K.sellPowerlLabel = d.getResource("TopNav_SellPower", !0), K.marginLabel = d.getResource("TopNav_Margin", !0), K.amountSelected.label = K.totalLabel, K.amountSelected.amount = K.totals.total.marketValueSubTot, C.gridsterContainer.relocation = !0
            })
        }

        function B() {
            w.getInteractiveDataUser().then(function (e) {
                K.enabledGraphics = e.data.response
            })
        }

        function R() {
            return S.getCapitalMarketOperationTime().then(function (e) {
                oe = e.startTime, re = e.endTime
            })
        }

        function N() {
            return a.logout().then(function () {
                c.path("/login")
            })
        }

        function U() {
            K.navRoutes = r.filter(function (e) {
                return e.config.settings && e.config.settings.nav
            }).sort(function (e, t) {
                return e.config.settings.nav > t.config.settings.nav
            })
        }

        function F(e) {
            if (!e.config.title || !n.current || !n.current.title) return "";
            var t = e.config.title;
            return n.current.title.substr(0, t.length) === t ? "active" : ""
        }

        function G() {
            return K.user && K.user.hasOwnProperty("name")
        }

        function V() {
            K.isOpeningSettingsWindow = !0;
            var t = m.open({
                scope: e,
                templateUrl: "loadPartial/Dashboard/Settings",
                controller: "hbSettingsCtrl as cfg"
            });
            t.opened.then(function () {
                K.isOpeningSettingsWindow = !1
            })
        }

        function W() {
            return K.token = "", K.requestingSessionUpgrade = !0, a.updateSession(K.token).then(function (e) {
                return K.requestingSessionUpgrade = !1, e
            }, function (e) {
                K.requestingSessionUpgrade = !1
            })
        }

        function z(e) {
            if (!e || 13 === e.keyCode) return "" != K.token ? (K.requestingSessionUpgrade = !0, a.updateSession(K.token).then(function (e) {
                return K.requestingSessionUpgrade = !1, K.token = "", e
            }, function (e) {
                e && 409 === e.status && y.logging(d.getResource("TopNav_JS_MSG_Resync", !0), y.loggingTypes.INFORMATION), K.requestingSessionUpgrade = !1
            })) : void y.logging(d.getResource("TopNav_JS_MSG_ConfirmTransactionTokenRequired", !0), y.loggingTypes.EXCEPTION)
        }

        function H() {
            K.headerCollapsed = !K.headerCollapsed
        }

        function J() {
            document.cookie = "hash=" + i.defaults.headers.common.GBMDigitalIdentityHash + ";", document.cookie = "app=" + i.defaults.headers.common.GBMDigitalIdentityApp + ";", document.cookie = "userId=" + i.defaults.headers.common.GBMDigitalIdentityUser + ";", document.cookie = "ip=" + i.defaults.headers.common["X-Forwarded-For"] + ";", ae = window.open("loadPartial/AdvancedCharts/Charts", "_blank", "toolbar=no, scrollbars=yes, resizable=yes")
        }

        function q(e) {
            if (e) {
                var t = v.defer();
                return z(), t.reject(), t.promise
            }
            var t = v.defer();
            return W(), t.reject(), t.promise
        }

        function Y() {
            angular.element(document.querySelector("#span-nav-open-right")).trigger("click");
            t.toggleVisibleSlideBar ? setTimeout(function () {
                t.toggleVisibleSlideBar = !1
            }, 0) : t.toggleVisibleSlideBar = !0
        }

        function X(e) {
            s.setDefaultContract(e)
        }

        function j() {
            var t = m.open({
                scope: e,
                templateUrl: "loadPartial/TopNav/ComissionsTable",
                controller: "hbCommissionsModalCtrl as commissionsVM",
                windowClass: "commissions-table",
                resolve: {
                    commissions: function () {
                        return K.defaultContractDetail.commissions
                    }
                }
            });
            t.opened.then(function () {})
        }

        function Q() {
            if (K.defaultContractDetail.commissions && K.defaultContractDetail.commissions.length > 0) {
                var e = K.defaultContractDetail.commissions.reduce(function (e, t, n) {
                        var i = t.maxAmount ? t.maxAmount : K.defaultContractDetail.capitalTransactions;
                        return K.defaultContractDetail.capitalTransactions >= t.minAmount && K.defaultContractDetail.capitalTransactions <= i ? {
                            item: t,
                            index: n
                        } : e
                    }, {
                        item: {},
                        index: -1
                    }),
                    t = K.defaultContractDetail.commissions.length;
                K.currentCommissionLvl = e.item, K.currentCommissionLvlIsMax = t > 0 && K.defaultContractDetail.commissions[K.defaultContractDetail.commissions.length - 1] === K.currentCommissionLvl, K.commissionProgress = K.currentCommissionLvlIsMax ? 100 : K.defaultContractDetail.capitalTransactions / K.currentCommissionLvl.maxAmount * 100, K.nextCommissionLvl = K.defaultContractDetail.commissions[Math.min(e.index + 1, t - 1)]
            }
        }
        var K = this;
        t.toggleVisibleSlideBar = !1, K.showNav = Y, K.showCommissionsWindow = j, K.showCommissionsLevel = showCommissionsLevel, K.sink = function (e) {
            return e.preventDefault(), e.stopPropagation(), !1
        };
        var Z = !0;
        K.isCurrent = F, K.showUserDetails = G, K.user = a.user, K.disconnectUser = N, K.auth = a, K.contracts = s.contracts, K.defaultContract = s.defaultContract, K.defaultContractDetail = s.defaultContractDetail, K.showSettingsWindow = V, K.cultures = l.cultures, K.defaultCulture = l.defaultCulture, K.upgradeSession = z, K.downgradeSession = W, K.openAdvancedCharts = J, K.setDefaultContract = X, K.headerCollapsed = !0, K.toggleHeader = H, K.writeSessionEnabled = K.user.isReadAndWrite, K.changeWriteSessionStatus = q, K.setAmountSelected = E, K.token = "", K.lastMessageTime = "", K.timeOfDay = "", K.dayOfTheWeek = "", K.shortDate = "", K.swichtSolace = !0, K.scheduleStatus = "", K.outOfSchedule = !1, K.sellingPower = 0, K.buyingPower = 0, K.margin = 0, K.totals = b.getTotals(), K.swichtSolace = T.enabledSolace, K.showLastMessageReceived = !1, K.lastMessageMarqueeTimer, K.requestingSessionUpgrade = !1, K.isOpeningSettingsWindow = !1, K.enabledGraphics = !1, K.totalLabel = "", K.buyPowerLabel = "", K.sellPowerlLabel = "", K.marginLabel = "", K.amountSelected = {
            label: "-",
            amount: 0
        };
        var ee, te = !1,
            ne = void 0,
            ie = I.min1;
        K.currencyFormat = {
            negativePrefix: "-",
            negativeSuffix: "",
            currency: !0
        };
        var oe, re, ae = null;
        e.$watch(function () {
            return a.loggedIn()
        }, function (e, t) {
            e && D()
        }), e.$watch(function () {
            return K.totals
        }, function (e, t) {
            switch (K.amountSelected.label) {
                case K.totalLabel:
                    K.amountSelected.amount = K.totals.total.marketValueSubTot;
                    break;
                case K.buyPowerLabel:
                    K.amountSelected.amount = K.totals.buyingPower;
                    break;
                case K.sellPowerlLabel:
                    K.amountSelected.amount = K.totals.sellingPower;
                    break;
                case K.marginLabel:
                    K.amountSelected.amount = K.totals.margin
            }
        }, !0), e.$watch(function () {
            return K.user.isReadAndWrite
        }, function (e, t) {
            K.writeSessionEnabled = e
        }), e.$watch("vm.token", function () {
            var e = /^\d*\.?\d*$/;
            e.test(K.token) || (K.token = "")
        }), e.$watch("vm.swichtSolace", function (e, t) {
            e !== t && Z && _(e), e ? h.connectSolace() : h.disconnectSolace(), Z = !0
        }), e.$watch(function () {
            return T.enabledSolace
        }, function (e, t) {
            e !== t && K.swichtSolace !== e && (Z = !1, K.swichtSolace = T.enabledSolace)
        }), e.$on("$destroy", function () {
            ae && ae.close()
        }), e.$watch("vm.defaultContractDetail.updatedTimeStamp", function (e, t) {
            Q()
        }), $(), e.redirect = function (e) {
            var t = e.url;
            c.path(t)
        }
    }
    var t = "topnav";
    angular.module("app").controller(t, ["$scope", "$rootScope", "$route", "$http", "config", "routes", "hbSecuritySvc", "hbContractManagementSvc", "$location", "hbCultureManagementSvc", "$interval", "hbGlobalizationSvc", "common", "hbOperationSvc", "hbUtilitiesSvc", "hbSolaceSvc", "$modal", "$q", "hbTotalsSvc", "hbAppManagementSvc", "hbLoggingSvc", "hbUserAppConfigSvc", "hbDashboardSvc", "hbResearchSvc", "timeoutConfig", e])
}(),
function () {
    "use strict";

    function e(e, t, n, i) {
        function o(e) {
            return "medal-" + e.description.toLowerCase()
        }
        var r = this,
            a = n.slice(0);
        a.sort(function (e, t) {
            return e.commisionPercentage - t.commisionPercentage
        }), r.commissions = a, r.getMedalClass = o, r.defaultContractDetail = i.defaultContractDetail, e.dismiss = function () {
            t.dismiss("cancel")
        }, e.accept = function () {
            t.close()
        }
    }
    angular.module("app").controller("hbCommissionsModalCtrl", ["$scope", "$modalInstance", "commissions", "hbContractManagementSvc", e])
}(),
function () {
    "use strict";

    function e(e, t, n, i, o) {
        function r() {
            d.menuItems = d.widgets.active.map(function (e) {
                return new c(e)
            })
        }

        function a() {
            g = new Swiper(".swiper-container", {
                pagination: ".swpagination",
                slidesPerView: d.size,
                mode: "horizontal",
                speed: 500,
                onTouchStart: function () {}
            })
        }

        function s(e, n) {
            t.addUserDashBoardWidget(e, n).then(function (e) {
                d.showAddWidget = !1, setTimeout(function () {
                    u(e)
                }, 1e3)
            })
        }

        function c(e) {
            function t() {
                var e = "img-widget img-widget-" + n._item.widgetTypeId;
                return e
            }
            var n = this;
            n._item = e, n.iconClass = t()
        }

        function l() {
            u("top")
        }

        function u(e) {
            t.showCurrentWidget(e, function () {})
        }
        var d = this,
            g = null;
        d.menuItems = [], d.widgets = t.widgets, d.userWidgetsTypes = t.userWidgetsTypes, d.scrollSpeed = "firefox" === n() ? 20 : 1, d.scrollViewWidth = "215px", d.goToWidget = u, d.goToTop = l, d.size = 6, d.addWidget = s, d.showAddWidget = !1, e.$watchCollection("vm.widgets.active", function (e, t) {
            r(), g && setTimeout(function () {
                g.reInit()
            }, 1e3)
        }), d.userWidgetsTypes = t.userWidgetsTypes.active, e.$on("$locationChangeStart", function (e) {
            e.preventDefault()
        }), e.$on("ngRepeatFinished", function () {
            g || a()
        })
    }
    angular.module("app").controller("hbMobileNavCtrl", ["$scope", "hbDashboardSvc", "hbBrowserSvc", "$location", "$anchorScroll", e])
}(),
function () {
    "use strict";

    function e(e, t, n, i, o, r) {
        function a(t, n, i) {
            n = n || "default", e.propertyScopes[n] = i || e, t && (P[n] = t)
        }

        function s(t) {
            t = t || "default";
            var n = e.propertyScopes[t],
                i = e.widget.config;
            i && (S(i.binding), p(i.bindNotifications), angular.forEach(P[t], function (e) {
                var o = e.value.split(".");
                if (o.length > 0) {
                    for (var r = n, a = 0; a < o.length - 1; a++) r = r[o[a]];
                    i.properties[t] && i.properties[t][e.name] && (r[o[o.length - 1]] = i.properties[t][e.name])
                }
            })), angular.forEach(P[t], function (e) {
                void 0 !== e.isArray && e.isArray ? n.$watch(e.value, function (e, t) {
                    c(e, t)
                }, !0) : n.$watch(e.value, function (e, t) {
                    c(e, t)
                })
            });
            var o = $.inArray(".swiper-container-title-" + e.widget.id, e.swipers),
                a = !1;
            if (o == -1) {
                new Swiper(".swiper-container-title-" + e.widget.id, {
                    slidesPerView: 1,
                    mode: "horizontal",
                    speed: 500,
                    onTouchMove: function (t) {
                        if (console.log("swiper.touches.startX: " + t.touches.startX + ", swiper.touches.current: " + t.touches.current + ", lock: " + a), t.touches.startX < 100 && t.touches.current > 80 && 0 == a && (e.displayDeleteMessage = !0, console.log("alert!")), t.touches.startX < 100 && t.touches.current > 250 && 0 == a) {
                            console.log("delete!");
                            var n = 0;
                            for (n = 0; n <= r.widgets.active.length - 1 && r.widgets.active[n].id != e.widget.id; n++);
                            I(n), a = !0
                        }
                    },
                    onTouchEnd: function (t) {
                        a = !1, e.displayDeleteMessage = !1
                    }
                });
                e.swipers.push(".swiper-container-title-" + e.widget.id)
            }
        }

        function c(t, n) {
            t != n && Object.keys(P).length > 0 && e.$emit("widget_update_config", e.widget.id, l())
        }

        function l(t) {
            var n = {};
            for (var i in P) {
                var o = e.propertyScopes[i];
                n[i] = {};
                for (var r in P[i])
                    if (r && P[i][r]) {
                        var a = P[i][r];
                        n[i][a.name] = a.value.split(".").reduce(function (e, t) {
                            if ("object" == typeof e && void 0 !== e[t]) return e[t]
                        }, o)
                    }
            }
            var s = {
                widgetTypeId: e.widget.widgetType,
                config: {
                    bindNotifications: e.bindNotifications,
                    binding: e.selectedBinding,
                    properties: n
                }
            };
            return s
        }

        function u(n, i) {
            t.open({
                scope: e,
                templateUrl: "loadPartial/Dashboard/WidgetSettings",
                controller: "WidgetSettingsCtrl",
                resolve: {
                    widget: function () {
                        return n
                    },
                    index: function () {
                        return i
                    }
                }
            })
        }

        function d(n, i) {
            e.isOpeningShareWindow = !0;
            var o = t.open({
                scope: e,
                templateUrl: "loadPartial/Dashboard/WidgetReportDownload",
                controller: "WidgetReportDownloadCtrl",
                windowClass: "share-report",
                resolve: {
                    widget: function () {
                        return n
                    },
                    index: function () {
                        return i
                    },
                    downloadDataFunction: function () {
                        return e.getDownloadDataFunction
                    },
                    exts: function () {
                        return e.downloadExt
                    }
                }
            });
            o.opened.then(function () {
                e.isOpeningShareWindow = !1
            })
        }

        function g(t) {
            10 === e.widget.widgetType && (t ? e.$broadcast("hide_Applet" + e.widget.id) : e.$broadcast("show_Applet" + e.widget.id))
        }

        function f() {
            e.bindNotifications = !e.bindNotifications
        }

        function p(t) {
            e.bindNotifications = t
        }

        function h(e, t, i) {
            _ ? _.registerHandlers(i, e, t) : (_ = n.buildInstance(e, t, i), _.registerHandlers(i))
        }

        function m(t) {
            _ && e.bindNotifications && _.registerHandlers(t)
        }

        function v(e) {
            _ && _.unRegisterHandler(e)
        }

        function b(t, n, i) {
            e.bindNotifications && _ && _.notify(t, n, i)
        }

        function S(e) {
            e && _ && (p(!0), _.selectedBinding = e)
        }

        function y(t) {
            e.showRefreshIcon = !0, D = t
        }

        function T() {
            D && D()
        }

        function C(t, n) {
            e.getDownloadDataFunction = t, e.downloadExt = n
        }

        function w(e) {
            i.$broadcast("dashboard.widget_initialized", e)
        }

        function I(t) {
            e.$emit("ez_gridster.widget_removed", r.widgets.active[t]), r.widgets.active.splice(t, 1)
        }
        var _, P = {},
            M = n.eventBindings,
            O = M[0].name,
            E = M[0].color,
            D = void 0;
        e.swipers = [], e.displayDeleteMessage = !1, e.propertyScopes = {}, e.openShareWindow = d, e.openSettings = u, e.bindNotifications = !0, e.toggleBindNotifications = f, e.subscribreToNotifications = h, e.prepareConfiguration = a, e.setBindNotifications = p, e.notify = b, e.eventBindings = M, e.selectedBinding = O, e.selectBinding = S, e.selectedColor = E, e.loadConfiguration = s, e.setRefreshFunction = y, e.refreshData = T, e.showRefreshIcon = !1, e.supportsDownload = !1, e.setSupportedDownloadExt = C, e.downloadExt = [], e.getDownloadDataFunction = null, e.notifyWidgetReady = w, e.isOpeningShareWindow = !1, e.removeWidget = e.removeWidget || I, e.toggleNotification = g, e.showWidget = r.showWidget, e.$watch("bindNotifications", function (t, n) {
            if (t)
                for (var i in e.propertyScopes) m(i);
            else
                for (var i in e.propertyScopes) v(i);
            c(t, n)
        }), e.$watch("selectedBinding", function (t, n) {
            if (t && t !== n) {
                for (var i in e.propertyScopes) v(i), m(i);
                for (var o = 0, r = e.eventBindings.length; o < r; o++)
                    if (e.eventBindings[o].name === t) {
                        e.selectedColor = e.eventBindings[o].color;
                        break
                    }
            }
            c(t, n)
        }), e.$watch(function (e) {
            return _ ? _.selectedBinding : O
        }, function (t, n) {
            t && _ && (e.selectedBinding = _.selectedBinding)
        }), e.$on("$destroy", function () {
            for (var t in e.propertyScopes) v(t)
        }), e.isSubscribed = function () {
            return !!_
        }
    }
    var t = "CustomWidgetCtrl";
    angular.module("app").controller(t, ["$scope", "$modal", "hbEventNotificationSvc", "common", "usSpinnerService", "hbDashboardSvc", e])
}(),
function () {
    "use strict";

    function e(e, t, n, i, o) {
        e.widget = i, e.remove = function () {
            e.removeWidget(o), n.close()
        }, e.dismiss = function () {
            n.close()
        }
    }
    var t = "WidgetSettingsCtrl";
    angular.module("app").controller(t, ["$scope", "$rootScope", "$modalInstance", "widget", "index", e])
}(),
function () {
    "use strict";

    function e(e, t, n, i, o) {
        function r() {
            n.close()
        }

        function a() {
            return s.invalidName = !1, 0 === s.dashboardName.length ? void(s.invalidName = !0) : (s.dashboard.name = s.dashboardName, void(o.editName ? i.updateDashboard(s.dashboard).then(function (e) {
                r()
            }) : i.addDashboard(s.dashboard).then(function (e) {
                i.dashboards.push(e), i.selectedDashboardId = e.dashBoardId, r()
            })))
        }
        var s = this;
        s.dashboardName = o ? o.name : "", s.dashboard = o, s.invalidName = !1, s.dismiss = r, s.save = a
    }
    var t = "dashboardElementCtrl";
    angular.module("app").controller(t, ["$scope", "$rootScope", "$modalInstance", "dashboardCtrl", "dashboard", e])
}(),
function () {
    "use strict";

    function e(e, t, n, i, o, r, a, s, c) {
        function l() {
            var e = u();
            e = e.substr(0, e.length - 4);
            var t = new jsPDF("portrait", "mm", "letter");
            return t.setProperties({
                title: e,
                subject: e,
                author: "GBM Homebroker",
                keywords: "generated, gbm, homebroker, report",
                creator: "GBM Homebroker"
            }), t
        }

        function u() {
            if (!(e.downloadOptions && e.downloadOptions.filename && e.downloadOptions.format && e.downloadOptions.format.extension)) return "";
            var t = e.downloadOptions.filename,
                n = "." + e.downloadOptions.format.extension;
            return t.lastIndexOf(n) !== t.length - 4 && (t += n), t
        }

        function d(t) {
            var n = angular.element("#asyncFileGenerationForm");
            n.find("#fileBase64").val(t.stream), n.find("#fileName").val(t.name), n.find("#fileType").val(t.type), n.submit(), e.downloadOptions.format = null
        }

        function g(e, t) {
            var n = "",
                i = "";
            if (e) {
                for (var o = 0, r = e.length; o < r; o++) {
                    var a = e[o] + "";
                    i += '"' + a.replace(/"/g, '""') + '",'
                }
                i = i.slice(0, -1), n += i + "\r\n"
            }
            for (var o = 0, r = t.length; o < r; o++) {
                for (var i = "", s = 0, c = t[o].length; s < c; s++) {
                    var a = t[o][s] + "";
                    i += '"' + a.replace(/"/g, '""') + '",'
                }
                i = i.slice(0, -1), n += i + "\r\n"
            }
            return n
        }
        var f = !1,
            p = [];
        e.availableFormats = [], e.widget = i, e.downloadGenerated = !1, e.downloadEnabled = !1, e.generationEnabled = !1, e.generatingFile = !1, e.downloading = !1, e.progress = 0, e.downloadOptions = {
            format: null,
            filename: ""
        };
        var h = {};
        e.UrlFile = "", e.$on("downloadAvailabilityChange", function () {
                e.downloadEnabled = e.downloadGenerated && e.downloadOptions.filename.length > 0 && e.downloadOptions.format
            }), e.$watch("downloadOptions.filename", function (t, n) {
                e.generationEnabled = t.length > 0;
                var i = angular.element("#report-download-link");
                i.attr("download", u()), e.$emit("downloadAvailabilityChange")
            }), e.$watch("downloadOptions.format", function (t, n) {
                e.downloadGenerated = !1, e.downloadOptions.format && e.generateDownload()
            }), e.dismiss = function () {
                if (e.generatingFile) {
                    for (var t = 0, i = p.length; t < i; t++) clearTimeout(p[t]);
                    f = !0
                }
                n.close()
            }, e.generateDownload = function () {
                if (e.generatingFile = !0, e.downloadOptions.format)
                    if ("pdf" === e.downloadOptions.format.extension) {
                        var t = r(e.downloadOptions);
                        if (e.progress = 10, "DOM" === t.type) {
                            for (var n = t.domElements, i = n.length, o = [], a = 0; a < i; a++) o.push({});
                            var s = 0,
                                c = l();
                            p = [];
                            for (var a = 0, m = n.length; a < m; a++) ! function (i) {
                                var o = setTimeout(function () {
                                    html2canvas(n[i], {
                                        onrendered: function (n) {
                                            s++, e.progress = 10 + s / m * 90;
                                            var o = 4;
                                            if (c.addImage(n.toDataURL("image/jpeg"), "JPEG", 15, 15, n.width / o, n.height / o), i < m - 1 && c.addPage(), s == m) {
                                                var r = c.output("dataurlstring");
                                                e.downloadGenerated = !0, e.generatingFile = !1, e.$emit("downloadAvailabilityChange"), (t.generationCompleted || f) && t.generationCompleted(), h.stream = r, h.type = "pdf", h.name = u(), d(h)
                                            }
                                        }
                                    })
                                }, 1e3 * i);
                                p.push(o)
                            }(a)
                        } else if ("image" === t.type) {
                            var c = new jsPDF;
                            c.fromHTML(t.domElement, 15, 15, {
                                width: 170,
                                elementHandlers: function (e, t) {
                                    return !0
                                }
                            }), c.save(u())
                        }
                    } else if ("csv" === e.downloadOptions.format.extension) {
                    var t = r(e.downloadOptions),
                        v = g(t.header, t.rows);
                    h.stream = v, h.type = "csv", h.name = u(), d(h), e.downloadGenerated = !0, e.generatingFile = !1, e.$emit("downloadAvailabilityChange")
                }
            },
            function () {
                for (var t = 0, n = a.length; t < n; t++) "pdf" === a[t] ? e.availableFormats.push({
                    name: "Adobe PDF (*.pdf)",
                    extension: "pdf",
                    icon: "Content/images/pdf_bw_icon.png"
                }) : "csv" === a[t] && e.availableFormats.push({
                    name: "Comma Separated Values (*.csv)",
                    extension: "csv",
                    icon: "Content/images/csv_bw_icon.png"
                });
                var i = function (e) {
                        return e < 10 ? "0" + e : e
                    },
                    o = e.widget.name,
                    r = new Date;
                e.downloadOptions.filename = o + "_" + r.getFullYear() + "-" + i(r.getMonth() + 1) + "-" + i(r.getDate()) + "_" + i(r.getHours()) + "-" + i(r.getMinutes())
            }(), e.formPosted = function () {
                e.downloadGenerated && n.close()
            }
    }
    var t = "WidgetReportDownloadCtrl";
    angular.module("app").controller(t, ["$scope", "$rootScope", "$modalInstance", "widget", "index", "downloadDataFunction", "exts", "$http", "hbLoggingSvc", e])
}(),
function () {
    "use strict";

    function e(e, n, i, o, r, a, s, c) {
        function l() {
            var e = [r.load("Login")];
            n.activateController(e, t).then(function () {
                var e = !y.user;
                y.focusUsernameField = e, y.focusPasswordField = !e, y.isMobileBrowser ? $zopim(function () {
                    $zopim.livechat.hideAll()
                }) : $zopim(function () {
                    $zopim.livechat.clearAll()
                })
            }), i.loggedIn() && u()
        }

        function u() {
            r.load("Dashboard").then(function () {
                e.path("/")
            })
        }

        function d() {
            y.loggingIn || "" !== y.user && void 0 !== y.user && "" !== y.password && void 0 !== y.password && (y.loggingIn = !0, i.login(y.user, y.password, y.token).then(function (e) {
                if (y.loggingIn = !1, y.rememberMe) {
                    var t = new Date;
                    t.setFullYear(t.getFullYear() + 1), document.cookie = "username=" + y.user + "; expires=" + t.toUTCString() + ";"
                } else delete s.username;
                u()
            }, function (e) {
                y.loggingIn = !1, y.error = !0, e && 409 === e.status && (o.logging("Token needs to be re-synced", o.loggingTypes.INFORMATION), y.resyncTokenVisible = !0)
            }))
        }

        function g() {
            return 0 === y.token.length ? void o.logging(r.getResource("Login_JS_MSG_TokenRequired", !0), o.loggingTypes.EXCEPTION) : void i.updateSession(y.token).then(function (e) {
                o.logging(r.getResource("Login_JS_MSG_UpdateSession", !0), o.loggingTypes.SUCCESS), a.dismiss()
            }, function (e) {
                y.error = !0, o.logging(r.getResource("Login_JS_MSG_ProblemUpdating", !0), o.loggingTypes.EXCEPTION)
            })
        }

        function f() {
            y.forgotPasswordVisible = !1, y.forgotPasswordEmail = "", y.validEmailFormat = !0, y.passwordRecovered = !1
        }

        function p(e) {
            var t = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
            return t.test(e)
        }

        function h() {
            p(y.forgotPasswordEmail) ? (y.validEmailFormat = !0, y.forgotPasswordEmail && y.forgotPasswordEmail.length > 0 && (y.requestingPasswordRecovery = !0, i.recoverPassword(y.forgotPasswordEmail).then(function (e) {
                y.requestingPasswordRecovery = !1, e && 200 === e.status && (y.passwordRecovered = !0)
            }, function (e) {
                o.logging(e.data, o.loggingTypes.EXCEPTION), y.requestingPasswordRecovery = !1
            }))) : y.validEmailFormat = !1
        }

        function m() {
            y.resyncTokenVisible = !1, y.resyncEmail = "", y.resyncSerial = "", y.resyncToken1 = "", y.resyncToken2 = ""
        }

        function v() {
            return "" === y.resyncToken1 && "" === y.resyncToken2 ? (y.validatedData = !1, !1) : y.resyncToken1 === y.resyncToken2
        }

        function b() {
            y.requestingTokenResync = !0, i.reSyncToken(y.resyncEmail, y.resyncToken1, y.resyncToken2).then(function (e) {
                y.requestingTokenResync = !1, e && 200 === e.status && (y.tokenResynced = !0, y.showConfirm = !0)
            }, function (e) {
                y.requestingTokenResync = !1, o.logging("Error syncing token", o.loggingTypes.EXCEPTION)
            })
        }

        function S(e) {
            var t = /^\d*\.?\d*$/;
            return t.test(e)
        }
        var y = this;
        y.user = "", y.password = "", y.token = "", y.login = d, y.updateSession = g, y.error = !1, y.forgotPasswordVisible = !1, y.forgotPasswordEmail = "", y.cancelForgotPassword = f, y.recoverPassword = h, y.requestingPasswordRecovery = !1, y.passwordRecovered = !1, y.validEmailFormat = !0, y.resyncTokenVisible = !1, y.cancelResyncToken = m, y.synchronizeToken = b, y.resyncEmail = "", y.resyncPassword = "", y.resyncToken1 = "", y.resyncToken2 = "", y.requestingTokenResync = !1, y.tokenResynced = !1, y.showConfirm = !1, y.validatedData = !1, y.validateTokens = v, y.isMobileBrowser = function () {
            var e = !1;
            return function (t, n) {
                (/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino/i.test(t) || /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(t.substr(0, 4))) && (e = !0)
            }(navigator.userAgent || navigator.vendor || window.opera), e
        }(), y.loggingIn = !1, s.username && (y.rememberMe = !0, y.user = s.username), a.$watch("vm.token", function () {
            S(y.token) || (y.token = "")
        }), a.$watch("vm.resyncToken1", function () {
            S(y.resyncToken1) || (y.resyncToken1 = "")
        }), a.$watch("vm.resyncToken2", function () {
            S(y.resyncToken2) || (y.resyncToken2 = "")
        }), l()
    }
    var t = "login";
    angular.module("app").controller(t, ["$location", "common", "hbSecuritySvc", "hbLoggingSvc", "hbGlobalizationSvc", "$scope", "$cookies", "hbCheckBrowserSvc", e])
}(),
function () {
    "use strict";

    function e(e, n, i, o, r, a) {
        function s() {
            var o = [];
            n.activateController(o, t).then(function () {}), i.loggedIn() && e.path("/")
        }

        function c() {}
        var l = this;
        l.user = "", l.password = "", l.error = !1, l.resendingEmail = !1, l.email = "", l.resendEmail = c, s()
    }
    var t = "hbActivateCtrl";
    angular.module("app").controller(t, ["$location", "common", "hbSecuritySvc", "hbLoggingSvc", "hbGlobalizationSvc", "$scope", e])
}(),
function () {
    "use strict";

    function e(e, n, i, o) {
        function r() {
            var e = [];
            o.activateController(e, t)
        }

        function a() {
            i.reSyncToken(s.username, s.serial, s.first, s.second).then(function (t) {
                e.path("/login")
            }, function (e) {
                n.logging("Error syncing token", n.loggingTypes.EXCEPTION)
            })
        }
        var s = this;
        s.username = "", s.serial = "", s.first = "", s.second = "", s.sync = a, r()
    }
    var t = "hbSyncTokenCtrl";
    angular.module("app").controller(t, ["$location", "hbLoggingSvc", "hbSecuritySvc", "common", e])
}(),
function () {
    "use strict";

    function e(e, n, i, o, r, a) {
        function s() {
            var e = [];
            i.activateController(e, t).then(function () {})
        }
        var c = this;
        c.error = !1, s(), n.dismiss = function () {
            a.close()
        }
    }
    var t = "hbUpdateSessionCtrl";
    angular.module("app").controller(t, ["$location", "$scope", "common", "hbSecuritySvc", "hbLoggingSvc", "$modalInstance", e])
}(),
function () {
    "use strict";

    function e(e, n, i, o, r, a, s, c, l, u, d, g, f, p, h, m, v, b, S) {
        function y() {
            var e = [x(), d.load("Dashboard")];
            s.activateController(e, t).then(function () {
                L().then(function () {
                    l.logging("Activated GBM Dashboard View", l.loggingTypes.DEBUG), q(), I()
                })
            })
        }

        function T() {
            j || (j = !0, c.getAgreementType().then(function (t) {
                var n = t.data;
                n.length > 0 && C(n).then(function (t) {
                    for (var n = t, i = !1, r = 0; r < n.length; r++) {
                        var a = n[r];
                        if (a.contracts.length > 0) {
                            i = !0;
                            break
                        }
                    }
                    i && o.open({
                        scope: e,
                        templateUrl: "loadPartial/Advertisement/",
                        size: "lg",
                        controller: "hbAdvertisementCtrl as vm",
                        backdrop: "static",
                        keyboard: "false",
                        resolve: {
                            options: function () {
                                return {
                                    agreements: n
                                }
                            }
                        }
                    })
                })
            }, function (e) {
                l.logging(e.data, l.loggingTypes.EXCEPTION)
            }))
        }

        function C(e) {
            for (var t = s.$q.defer(), n = [], i = 0; i < e.length; i++) n.push({
                type: e[i],
                contracts: [],
                excluded: []
            });
            var o = b.contracts;
            return 0 === o.length && t.resolve(n), w(n).then(function () {
                for (var e = "", i = 0; i < o.length; i++) e = "" === e ? o[i].contractId : e + "," + o[i].contractId;
                b.getContracts(e).then(function (e) {
                    for (var i = 0; i < e.data.length; i++) {
                        var o = e.data[i];
                        if (null !== o || void 0 !== o)
                            for (var r = 0; r < n.length; r++) {
                                var a = n[r];
                                switch (a.type) {
                                    case 1:
                                        if (o.tradeShortSell)
                                            if (a.excluded.length > 0) {
                                                for (var s = !0, c = 0; c < a.excluded.length; c++)
                                                    if (a.excluded[c].contractId === o.contractID) {
                                                        s = !1;
                                                        break
                                                    }
                                                s && a.contracts.push(o)
                                            } else a.contracts.push(o);
                                        break;
                                    case 2:
                                        if (o.tradeMargin)
                                            if (a.excluded.length > 0) {
                                                for (var s = !0, c = 0; c < a.excluded.length; c++)
                                                    if (a.excluded[c].contractId === o.contractID) {
                                                        s = !1;
                                                        break
                                                    }
                                                s && a.contracts.push(o)
                                            } else a.contracts.push(o)
                                }
                            }
                    }
                    t.resolve(n)
                }, function (e) {
                    t.resolve(n), l.logging(e.data, l.loggingTypes.EXCEPTION)
                })
            }, function (e) {
                t.reject("error")
            }), t.promise
        }

        function w(e) {
            var t = s.$q.defer(),
                n = {
                    agreementTypeId: 0
                };
            return c.getAgreementLog(n).then(function (n) {
                for (var i = n.data, o = 0; o < e.length; o++) {
                    var r = e[o];
                    r.excluded.push.apply(r.excluded, i.filter(function (e) {
                        return e.agreementTypeId === r.type
                    }))
                }
                t.resolve({})
            }, function (e) {
                t.reject("error"), l.logging(e.data, l.loggingTypes.EXCEPTION)
            }), t.promise
        }

        function I() {
            S.getUser().then(function (e) {
                Y.isMobile || $zopim(function () {
                    $zopim.livechat.addTags("Contrato: " + b.defaultContract.contractId), $zopim.livechat.setName(Y.user.name), $zopim.livechat.setEmail(e.data.userName)
                })
            })
        }

        function _() {
            if (!ne && g.loggedIn()) {
                var e = this;
                ne = o.open({
                    templateUrl: "loadPartial/Dashboard/SlideSession",
                    windowClass: "slide-session-window",
                    controller: "hbSlideSessionCtrl as vm",
                    backdrop: "static",
                    keyboard: "false",
                    resolve: {
                        parentCtrl: function () {
                            return e
                        }
                    }
                })
            }
        }

        function P(e) {
            c.deleteUserDashBoardWidget(e).then(function (e) {
                return Y.isMobile && Y.widgets.active.length > 0 && v.showCurrentWidget(Y.widgets.active[0], function () {}), l.logging("Widget deleted successfully!!", l.loggingTypes.DEBUG), e
            }, function (e) {
                l.logging(e.data, l.loggingTypes.EXCEPTION)
            })
        }

        function M() {
            K && (Y.startDissolving = !0, Q = f(function () {
                Y.displayLoading = !1
            }, 1e3))
        }

        function O() {
            Q && (f.cancel(Q), Q = null)
        }

        function E() {
            var e = document.body,
                t = document.documentElement,
                n = Math.max(e.scrollHeight, e.offsetHeight, t.clientHeight, t.scrollHeight, t.offsetHeight);
            Y.splashHeight = n
        }

        function D() {
            O(), E(), p.reset(), Y.displayLoading = !0, Y.startDissolving = !1
        }

        function A(e) {
            c.deleteUserDashboard(e.dashBoardId).then(function (t) {
                e.dashBoardId === Y.selectedDashboardId && (Y.widgets.active = []);
                for (var n = 0, i = 0, o = Y.dashboards.length; i < o; i++)
                    if (Y.dashboards[i].dashBoardId === e.dashBoardId) {
                        n = i;
                        break
                    }
                var r = Y.dashboards.slice(n + 1);
                return Y.dashboards.length = n, Y.dashboards.push.apply(Y.dashboards, r), l.logging("Dashboard removed successufully!!", l.loggingTypes.DEBUG), t
            }, function (e) {
                l.logging(e.data, l.loggingTypes.EXCEPTION)
            })
        }

        function k(e, t) {
            v.addUserDashBoardWidget(e, t)
        }

        function L() {
            s.$broadcast("dashboard.retrieving_dashboards");
            var e = window.innerWidth,
                t = window.innerHeight;
            return e < 1920 && (e = 1280, t = 720), e >= 1920 && (e = 1920, t = 1080), c.getUserDashboards(e, t).then(function (e) {
                Y.dashboards = e.data;
                var t = u.dashboardSorting;
                return $.each(Y.dashboards, function (e, n) {
                    n.id = n.dashBoardId, n.sortIndex = t.indexOf(n.dashBoardId)
                }), $.each(Y.dashboards, function (e, t) {
                    if (t.isActive) return Y.selectedDashboardId = t.dashBoardId, !1
                }), Y.selectedDashboardId || (1 === Y.dashboards.length ? Y.selectedDashboardId = Y.dashboards[0].dashBoardId : Y.selectedDashboardId = Y.dashboards[Y.dashboards.length - 1].dashBoardId), s.$broadcast("dashboard.dashboards_retrieved", Y.dashboards.length), e
            }, function (e) {
                l.logging(e.data, l.loggingTypes.EXCEPTION)
            })
        }

        function x() {
            function e(e) {
                for (var t = [], n = [1, 2, 14, 4, 9, 15, 13, 11, 7, 8, 10], i = 0, o = e.length; i < o; r ? i++ : i) {
                    var r = !1,
                        a = n.length > 0 ? n.shift() : function () {
                            var i = t.map(function (e) {
                                return e.widgetTypeId
                            });
                            return n = e.reduce(function (e, t) {
                                return i.indexOf(t.widgetTypeId) < 0 && e.push(t.widgetTypeId), e
                            }, []), n.shift()
                        }();
                    for (var s in e) {
                        var c = e[s];
                        if (c.widgetTypeId == a) {
                            t.push(c), r = !0;
                            break
                        }
                    }
                }
                return t
            }
            return s.$broadcast("dashboard.retrieving_widget_types"), c.getUserWidgetTypes().then(function (t) {
                var n = e(t.data);
                return Y.userWidgetsTypes = n, v.userWidgetsTypes.active.length = 0, v.userWidgetsTypes.active.push.apply(v.userWidgetsTypes.active, n), s.$broadcast("dashboard.widget_types_retrieved"), t
            })
        }

        function B() {
            Z = Y.widgets.active.length;
            var e = Z > 0;
            e && (ee = !0), Y.widgets.active.length = 0, s.$broadcast("dashboard.retrieving_dashboard_widgets");
            var t = R();
            t.then(function (t) {
                null != t.data && void 0 != t.data && t.data.length > 0 ? (t.data.sort(function (e, t) {
                    return e.row - t.row
                }), angular.forEach(t.data, function (e) {
                    var t = {
                            id: e.id,
                            col: e.col,
                            row: e.row,
                            size_y: e.size_y,
                            size_x: e.size_x,
                            min_sizey: e.min_sizey > 0 && e.min_sizey,
                            min_sizex: e.min_sizex > 0 && e.min_sizex,
                            max_sizey: e.max_sizey > 0 && e.max_sizey,
                            max_sizex: e.max_sizex > 0 && e.max_sizex,
                            name: e.name,
                            init: e.init,
                            widgetTypeId: e.widgetTypeId
                        },
                        n = i("filter")(Y.userWidgetsTypes, {
                            widgetTypeId: e.widgetTypeId
                        }, !0);
                    n.length > 0 ? Y.widgets.active.push(t) : P(e.id), Y.isMobile && f(function () {
                        v.showCurrentWidget(v.widgets.active[0], function () {})
                    }, 1e3)
                }), s.$broadcast("dashboard.dashboard_widgets_retrieved", Y.widgets.active.length)) : e ? setTimeout(function () {
                    s.$broadcast("dashboard.dashboard_widgets_retrieved", 0)
                }, 1e3) : (Y.loadingState.progress = 100, s.$broadcast("dashboard.dashboard_widgets_retrieved", 0))
            })
        }

        function R() {
            return v.getWidgetsInUserDashBoard()
        }

        function N(e) {
            return c.addUserDashboard(e).then(function (t) {
                if (Y.isMobile) return e.dashBoardId = t.data.response, e.id = t.data.response, e;
                var n = Y.dashboards[Y.dashboards.length - 1];
                return n.dashBoardId = t.data.response, n.id = t.data.response, n
            })
        }

        function U() {
            v.updateWidgetsInUserDashboard()
        }

        function F() {
            function e(e) {
                function n() {
                    var e = Y.dashboards.length - 1,
                        t = Y.dashboards.slice(e + 1);
                    Y.dashboards.length = e, Y.dashboards.push.apply(Y.dashboards, t)
                }
                var i = s.$q.defer();
                return e ? N(t).then(function (e) {
                    Y.selectedDashboardId = e.dashBoardId, i.resolve(e)
                }, function (e) {
                    i.reject(!1)
                }) : n(), i.promise
            }
            var t = {
                name: "",
                editName: !1
            };
            return Y.isMobile ? void G(t) : (t.editName = !0, t.editNameCallback = e, void Y.dashboards.push(t))
        }

        function G(t) {
            o.open({
                scope: e,
                templateUrl: "loadPartial/Dashboard/ConfigTab",
                windowClass: "add-widget",
                controller: "dashboardElementCtrl as dash",
                resolve: {
                    dashboardCtrl: function () {
                        return Y
                    },
                    widgetTypes: function () {
                        return Y.userWidgetsTypes
                    },
                    dashboard: function () {
                        return t
                    }
                }
            })
        }

        function V(e) {
            var t = {
                applicationId: 1,
                dashBoardId: e.dashBoardId,
                name: e.name,
                isActive: !0,
                widgets: e.widgets
            };
            return c.updateUserDashboard(t)
        }

        function W() {
            Y.showMenu = !Y.showMenu
        }

        function z() {
            return ['<i class="fa fa-font"></i> Rename', '<i class="fa fa-trash-o"></i> Delete']
        }

        function H(e, t) {
            if (0 === t) e.previousName = e.name, Y.isMobile ? G(e) : e.editNameCallback = function (t) {
                return t ? V(e) : void(e.name = e.previousName)
            }, e.editName = !0;
            else if (1 === t) {
                for (var n = Y.dashboards[0], i = 0, o = Y.dashboards.length; i < o; i++)
                    if (Y.dashboards[i].dashBoardId === e.dashBoardId) {
                        i > 0 ? n = Y.dashboards[i - 1] : i < o - 1 && (n = Y.dashboards[i + 1]);
                        break
                    }
                Y.selectedDashboardId = n.dashBoardId, A(e)
            }
        }

        function J() {
            u.dashboardSorting.length = 0;
            for (var e = 0, t = Y.dashboards.length; e < t; e++) u.dashboardSorting.push(Y.dashboards[e].dashBoardId)
        }

        function q() {
            var e = $(".gridster-container").offset(),
                t = window.innerHeight - (void 0 == e ? 0 : e.top),
                n = window.innerWidth - (void 0 == e ? 0 : e.left);
            Y.scrollViewHeight = t - 20 + "px", Y.scrollViewWidth = n + "px", v.viewHeight.value = t - 20
        }
        for (var Y = this, X = e; null === X.pageYScrollPosition || void 0 === X.pageYScrollPosition;) X = e.$parent;
        var j = !1;
        Y.isMobile = s.mobileProperties.isMobile, Y.toggleSlidebar = n.toggleVisibleSlideBar, Y.user = g.user, Y.dashboards = [], Y.widgets = v.widgets, Y.userWidgetsTypes = [], Y.selectedDashboardId, Y.deleteDashboard = A, Y.addWidget = k, Y.getUserDashboardWidgets = B, Y.showMenu = !1, Y.toggleShowMenu = W, Y.tabMenuItemsBuilder = z, Y.tabMenuItemSelected = H, Y.tabsSortedCallback = J, Y.addDashboard = N, Y.addDashboardClicked = F, Y.updateDashboard = V, Y.setupScrollbars = q, Y.displayLoading = !1, Y.startDissolving = !1, Y.loadingState = p.state, Y.progress = 0, Y.currentTask = "", Y.gridsterOptions = m, Y.gridsterOptions.resizable.stop = function (t, n, i) {
            U(), e.$broadcast("window_resized_completed")
        }, Y.gridsterOptions.draggable.stop = function (e, t, n) {
            U()
        }, Y.customItemMap = {
            row: "widget.row",
            col: "widget.col",
            sizeX: "widget.size_x",
            sizeY: "widget.size_y",
            minSizeX: "widget.min_sizex",
            minSizeY: "widget.min_sizey"
        }, Y.showToolBar = function () {
            var e = Y.dashboards.length > 0;
            return e && 1 == Y.dashboards.length ? !Y.dashboards[0].editName : e
        };
        var Q = null,
            K = !1,
            Z = 0,
            ee = !1;
        e.$watch(function () {
            return s.mobileProperties.isMobile
        }, function (e, t) {
            Y.isMobile = e, v.isMobile.value = e
        }), e.$watch(function () {
            return n.toggleVisibleSlideBar
        }, function (e, t) {
            Y.toggleSlidebar = e
        }), e.$watch("vm.selectedDashboardId", function (e, t) {
            void 0 !== e && null !== e && (v.selectedDashboard.id = Y.selectedDashboardId, B(), t && (K = !0, D()))
        }), e.getItem = function () {
            return ItemStore.currentItem
        }, y(), e.$on("ez_gridster.get_widgets", function (e, t) {
            U()
        }), e.$on("hb-gridster-item-destroyed", function () {
            Z--, 0 === Z && ee && (ee = !1)
        }), e.$on("widget_update_config", function (e, t, n) {
            c.updateWidgetConfiguration(t, n).then(function (e) {
                return l.logging("Widget Id: " + t + " updated successfully!!", l.loggingTypes.DEBUG), e
            }, function (e) {
                l.logging(e.data, l.loggingTypes.EXCEPTION)
            })
        }), e.$on("ez_gridster.widget_removed", function (e, t, n) {
            P(t.id)
        }), e.$on("hb-gridster-resized", function (e, t) {
            Y.gridsterOptions.columns = Y.gridsterOptions.columns < t ? t : Y.gridsterOptions.columns
        }), e.$watchCollection(Y.dashboards, function () {
            Y.dashboards && Y.dashboards.length > 0 && J()
        }), window.onresize = function () {
            q()
        }, n.$on("loading.tasks_completed", function (e, t) {
            T(), K && (E(), M())
        }), angular.element(r).bind("resize", function () {
            e.$broadcast("window_resized")
        });
        var te = 0,
            ne = null,
            ie = setInterval(function () {
                if (te++, !ne) {
                    if (te < 10) return;
                    te = 0
                }
                var e = h.getSessionStatus();
                e === h.SessionStatus.Normal ? ne && (ne.close(), ne = null) : e === h.SessionStatus.ExpiringWrite ? _() : e === h.SessionStatus.Expiring ? _() : e === h.SessionStatus.Expired && ne && (ne.close(), ne = null)
            }, 1e3);
        e.$on("$destroy", function () {
            clearInterval(ie)
        }), e.$watch(function () {
            return X.pageYScrollPosition
        }, function (e, t) {
            +e > +t ? Y.headerClass = "small" : Y.headerClass = "full"
        });
        var oe = e.$watch(function () {
            return v.gridsterContainer.relocation
        }, function (e) {
            e && (q(), oe())
        })
    }
    var t = "hbDashboardCtrl";
    angular.module("app").controller(t, ["$scope", "$rootScope", "$filter", "$modal", "$window", "$interval", "common", "hbAppManagementSvc", "hbLoggingSvc", "hbUserAppConfigSvc", "hbGlobalizationSvc", "hbSecuritySvc", "$timeout", "hbLoadingSvc", "hbSessionSliderSvc", "hbGridsterOptions", "hbDashboardSvc", "hbContractManagementSvc", "hbUserSvc", e])
}(),
function () {
    function e(e, t, n, i, o, r, a, s, c, l) {
        function u(e) {
            var t = !0;
            if (t = e && e.length >= 8) {
                for (var n, i = !1, o = !1, r = !1, a = !1, s = 0, c = e.length; s < c; s++) n = e.charCodeAt(s), n >= 48 && n <= 57 ? r = !0 : n >= 65 && n <= 90 ? i = !0 : n >= 97 && n <= 122 ? o = !0 : a = !0;
                t &= (o || i) && r
            }
            return t
        }

        function d() {
            return h.newPassword !== h.retypeNewPassword ? void(h.mismatchedPasswords = !0) : u(h.newPassword) ? (h.securityPolicyError = !1, h.mismatchedPasswords = !1, h.requestinPasswordChange = !0, void c.updatePassword(h.previousPassword, h.newPassword).then(function (e) {
                h.requestinPasswordChange = !1, 200 === e.status && (r.logging(m, r.loggingTypes.SUCCESS), h.dismiss())
            }, function (e) {
                r.logging(e.data, r.loggingTypes.EXCEPTION)
            })) : void(h.securityPolicyError = !0)
        }

        function g() {
            l.getUserConfiguration().then(function (e) {
                h.defaultCulture = e.cultureId, h.swichtSolace = e.solaceNotifications, h.alias = e.alias, h.userName = e.userName, h.notificationsEmail = e.notificationsEmail, h.telephone = e.telephone;
                for (var t = "Dark", n = 0, i = h.themes.length; n < i; n++)
                    if (h.themes[n].name === e.themeName) {
                        t = h.themes[n].name;
                        break
                    }
                h.currentTheme = t
            })
        }

        function f() {
            h.changingPassword = !0
        }

        function p() {
            h.changingPassword = !1
        }
        var h = this,
            m = s.getResource("Dashboard_ChangedPassword", !0);
        h.cultures = i.cultures, h.defaultCulture = 0, h.swichtSolace = !0, h.alias = "", h.userName = "", h.notificationsEmail = "", h.telephone = "", h.themes = [{
            name: "Dark"
        }, {
            name: "Light"
        }], h.currentTheme = "Dark", h.changingPassword = !1, h.previousPassword = "", h.newPassword = "", h.retypeNewPassword = "", h.changePassword = f, h.cancelChangePassword = p, h.requestinPasswordChange = !1, g(), e.$watch("cfg.newPassword", function () {
            h.mismatchedPasswords = !1
        }), e.$watch("cfg.retypeNewPassword", function () {
            h.mismatchedPasswords = !1
        }), h.save = function () {
            if (h.changingPassword) return void d();
            var e = {
                cultureId: h.defaultCulture,
                solaceNotifications: h.swichtSolace,
                themeName: h.currentTheme,
                alias: h.alias,
                userName: h.userName,
                notificationsEmail: h.notificationsEmail,
                telephone: h.telephone
            };
            l.updateUserConfiguration(e).then(function () {
                h.swichtSolace ? a.connectSolace() : a.disconnectSolace(), h.dismiss()
            })
        }, h.dismiss = function () {
            n.close()
        }
    }
    var t = "hbSettingsCtrl";
    angular.module("app").controller(t, ["$scope", "$rootScope", "$modalInstance", "hbCultureManagementSvc", "hbAppManagementSvc", "hbLoggingSvc", "hbSolaceSvc", "hbGlobalizationSvc", "hbSecuritySvc", "hbUserAppConfigSvc", e])
}(),
function () {
    "use strict";

    function e(e, t, n, i, o, r, a) {
        function s() {
            n.close()
        }

        function c() {
            return i.updateSession(S.token)
        }

        function l() {
            if (S.processing = !0, S.hasError = !1, S.errorMessage = "", S.user.isReadAndWrite) u().then(function () {
                a.logging("Clausulados actualizados con Ã©xito.", a.loggingTypes.SUCCESS), s()
            });
            else {
                if (0 === S.token.length) return S.hasError = !0, S.errorMessage = "Por favor, debes ingresar tu token para poder continuar con la aceptaciÃ³n de los clausulados.", void(S.processing = !1);
                c().then(function () {
                    u().then(function () {
                        a.logging("Clausulados actualizados con Ã©xito.", a.loggingTypes.SUCCESS), s()
                    })
                }, function () {
                    S.processing = !1, S.hasError = !0, S.errorMessage = "Token incorrecto, favor de reintentar."
                })
            }
        }

        function u() {
            var n = t.$q.defer();
            if (S.indicator.tradeShortSell && S.indicator.tradeMargin) {
                if (!S.acceptTradeShortSell && !S.acceptTradeMargin) return S.hasError = !0, S.errorMessage = "Por favor, debe de aceptar los clausualados para continuar.", S.processing = !1, n.reject({}), n.promise;
                if (!S.acceptTradeShortSell && S.acceptTradeMargin) return S.hasError = !0, S.errorMessage = "Para aceptar MÃ¡rgenes IntradÃ­a, debes aceptar tambiÃ©n las Ventas en Corto.", S.processing = !1, n.reject({}), n.promise
            }
            if (S.indicator.tradeShortSell && !S.indicator.tradeMargin && !S.acceptTradeShortSell) return S.hasError = !0, S.errorMessage = "Por favor, debes aceptar el clausulado antes de continuar.", S.processing = !1, n.reject({}), n.promise;
            if (!S.indicator.tradeShortSell && S.indicator.tradeMargin && !S.acceptTradeMargin) return S.hasError = !0, S.errorMessage = "Por favor, debes aceptar el clausulado antes de continuar.", S.processing = !1, n.reject({}), n.promise;
            if (S.indicator.tradeShortSell && S.indicator.tradeMargin) {
                if (S.acceptTradeShortSell && !S.acceptTradeMargin) {
                    var i = '<span class="adv-pop-title">Â¿SÃ³lo ventas en corto?</span>',
                        o = '<div class="advertisement">        <div class="row">            <div class="col-sm-12">                <center>                    <div>                        <span class="text">                            EstÃ¡s aceptando solamente los clausulados de Ventas en Corto.                         </span>                        <span class="text bold">                            Â¿EstÃ¡s de acuerdo?                        </span>                    </div>                </center>            </div>        </div></div>',
                        r = {
                            title: i,
                            message: o,
                            buttons: {
                                cancel: {
                                    caption: "NO",
                                    classes: "btn adv-button"
                                },
                                ok: {
                                    caption: "SI",
                                    classes: "btn btn-success adv-button-prin"
                                }
                            },
                            action: d,
                            isPromise: !0
                        };
                    return t.displayConfirmation(e, r).then(function (e) {
                        e ? (S.processing = !1, n.reject({})) : (S.processing = !1, n.resolve({}))
                    }), n.promise
                }
                return d()
            }
            return d()
        }

        function d() {
            for (var e = t.$q.defer(), n = 0, i = 0; i < S.agreements.length; i++) {
                var o = S.agreements[i],
                    r = 0;
                1 == o.type && (r = S.acceptTradeShortSell ? 2 : 3), 2 == o.type && (r = S.acceptTradeMargin ? 2 : 3), m(o.type, o.contracts, r).then(function () {
                    n++, n >= S.agreements.length && (S.processing = !1, e.resolve({}))
                }, function () {
                    n++, n >= S.agreements.length && (S.processing = !1, e.resolve({}))
                })
            }
            return e.promise
        }

        function g() {
            if (S.processing = !0, S.hasError = !1, S.errorMessage = "", S.user.isReadAndWrite) f().then(function () {
                a.logging("Clausulados actualizados con Ã©xito.", a.loggingTypes.SUCCESS), s()
            });
            else {
                if (0 === S.token.length) return S.hasError = !0, S.errorMessage = "Por favor, debes ingresar tu token para poder continuar con los clausulados.", void(S.processing = !1);
                c().then(function () {
                    f().then(function () {
                        a.logging("Clausulados actualizados con Ã©xito.", a.loggingTypes.SUCCESS), s()
                    })
                }, function () {
                    S.processing = !1, S.hasError = !0, S.errorMessage = "Token incorrecto, favor de reintentar."
                })
            }
        }

        function f() {
            var n = t.$q.defer(),
                i = '<span class="adv-pop-title">No acepto los clausulados</span>',
                o = '<div class="advertisement">        <div class="row bottomtext">            <div class="col-sm-12">                <center>                    <div>                        <span class="text bold">                            No estÃ¡s aceptando ninguno de los clausulados y los servicios serÃ¡n cancelados.                        </span>                    </div>                </center>            </div>        </div>        <div class="row">            <div class="col-sm-12">                <center>                    <span class="text">Las Ã³rdenes abiertas con estos servicios seguirÃ¡n activas, pero no serÃ¡ posible crear nuevas Ã³rdenes.</span>                </center>            </div>        </div>        <div class="row">            <div class="col-sm-12">                <center>                    <span class="text">Para futuras activaciones del servicio, favor de llamar a nuestro Centro de AtenciÃ³n a Clientes al 54 80 58 46 o al 01 800 426 4663</span>                </center>            </div>        </div></div>',
                r = {
                    title: i,
                    message: o,
                    buttons: {
                        cancel: {
                            caption: "REGRESAR",
                            classes: "btn adv-button"
                        },
                        ok: {
                            caption: "NO ACEPTO LOS CLAUSULADOS",
                            classes: "btn adv-button-grey"
                        }
                    },
                    action: d,
                    isPromise: !0
                };
            return t.displayConfirmation(e, r).then(function (e) {
                e ? (S.processing = !1, n.reject({})) : (S.processing = !1, n.resolve({}))
            }), n.promise
        }

        function p(e) {
            for (var t = 0; t < S.agreements.length; t++) {
                var n = S.agreements[t];
                if (n.type === e) return n.contracts
            }
        }

        function h() {
            for (var e = 0; e < S.agreements.length; e++) {
                var t = S.agreements[e];
                switch (t.type) {
                    case 1:
                        S.indicator.tradeShortSell = t.contracts.length > 0;
                        for (var n = 0; n < t.contracts.length; n++) {
                            var i = {};
                            angular.copy(t.contracts[n], i), b(1, i.contractID)
                        }
                        break;
                    case 2:
                        S.indicator.tradeMargin = t.contracts.length > 0;
                        for (var n = 0; n < t.contracts.length; n++) {
                            var i = {};
                            angular.copy(t.contracts[n], i), b(2, i.contractID)
                        }
                }
            }
        }

        function m(e, n, i) {
            var o = t.$q.defer();
            if (0 === n.length) return o.resolve({}), o.promise;
            for (var r = 0, a = 0; a < n.length; a++) {
                var s = n[a],
                    c = {
                        agreementTypeId: e,
                        contractId: s.contractID,
                        agreementStatusTypeId: i
                    };
                v(c).then(function () {
                    r++, r >= n.length && o.resolve({})
                }, function () {
                    r++, r >= n.length && o.resolve({})
                })
            }
            return o.promise
        }

        function v(e) {
            return r.addApplicationAgreementLog(e).then(function () {}, function (e) {
                a.logging(e.data, a.loggingTypes.EXCEPTION)
            })
        }

        function b(e, t) {
            var n = {
                agreementTypeId: e,
                contractId: t,
                agreementStatusTypeId: 1
            };
            v(n)
        }
        var S = this;
        S.agreements = o.agreements, S.token = "", S.hasError = !1, S.errorMessage = "", S.dismiss = s, S.indicator = {
            tradeShortSell: !1,
            tradeMargin: !1
        }, S.acceptTradeShortSell = !1, S.acceptTradeMargin = !1, S.processing = !1, S.cancel = s, S.send = l, S.reject = g, S.getAgreementContracts = p, S.user = i.user, e.$watch(function () {
            return i.loggedIn()
        }, function (e, t) {
            e || s()
        }), h()
    }
    angular.module("app").controller("hbAdvertisementCtrl", ["$scope", "common", "$modalInstance", "hbSecuritySvc", "options", "hbAppManagementSvc", "hbLoggingSvc", e])
}(),
function (undefined) {
    "use strict";

    function hbMonitorCtrl($filter, $modal, $scope, $rootScope, common, notificationTypes, hbLoggingSvc, hbMarketSvc, hbSolaceSvc, hbDragNDropHelperSvc, hbWatchListSvc, hbGlobalizationSvc, hbContractManagementSvc, hbCultureManagementSvc, hbUserAppConfigSvc, hbGridsterOptions, hbBrowserSvc) {
        function dragStartCallback(e) {
            vm.draggedIssue = e
        }

        function dragSymbol() {
            if (null === vm.draggedIssue || vm.draggedIssue === undefined) return $("<div></div>");
            var e = '<div class="drag-symbol">\n<div class="drag-symbol-container">\n   <div class="drag-icon"></div>\n   <div class="drag-text">' + vm.draggedIssue.symbol + "</div></div>\n</div>\n",
                t = $(e);
            return vm.dndHelper.ghostElement = t, t
        }

        function dragCallback(e, t) {
            return null === vm.draggedIssue ? void vm.dndHelper.setMessage(null) : (t.position.left = e.pageX - 35, t.position.top = e.pageY - 15, void vm.dndHelper.setMessage("monitor", vm.draggedIssue))
        }

        function dropCallback(e, t, n) {
            n && n.source && ("monitor" === n.source ? addIssueToWatchList(n.payload.symbol) : "level2" === n.source && console.log(n.payload))
        }

        function tabAcceptedDropSources(e) {
            var t = e.name.toLowerCase();
            "bmv" !== t && "sic" !== t && "opt" !== t ? vm.dndHelper.accepts(["monitor"]) : vm.dndHelper.accepts(["inexisting-source"])
        }

        function droppedIssue(e, t) {
            var n = e.name.toLowerCase();
            "bmv" !== n && "sic" !== n && "opt" !== n && t && "monitor" === t.source && addIssueToWatchList(t.payload.symbol, e.id)
        }

        function dragOverCallback() {
            vm.dndHelper.accepts(["monitor", "level2"])
        }

        function dragOutCallback() {
            vm.dndHelper.out()
        }

        function activate() {
            var e = hbContractManagementSvc.isUserSicEnabled().then(function (e) {
                    e && tabs.push({
                        id: -2,
                        name: "SIC",
                        symbols: ["*"],
                        sortIndex: 1,
                        searchText: ""
                    })
                }),
                t = [e, initConfiguration(), hbGlobalizationSvc.load("Monitor"), getThemeConfig()];
            common.activateController(t, controllerId).then(function () {
                for (var e = vm.canvasConfig.columns, t = 0, n = e.length; t < n; t++) e[t].title = hbGlobalizationSvc.getResource("Monitor_ColumnName" + t, !0).toUpperCase();
                $scope.loadConfiguration !== undefined && $scope.loadConfiguration(), vm.canvasConfig.emptyRows.emptyRowsTitle = hbGlobalizationSvc.getResource("Monitor_emptyRowsTitle", !0), vm.canvasConfig.emptyRows.emptyRowsSubtitle = hbGlobalizationSvc.getResource("Monitor_emptyRowsSubtitle", !0), vm.canvasConfig.emptyRows.trashTitle = hbGlobalizationSvc.getResource("Monitor_trashTitle", !0), common.$broadcast("dashboard.widget_initialized", "Monitor")
            }), $scope.setRefreshFunction(hbSolaceSvc.refresh)
        }

        function getThemeConfig() {
            return hbUserAppConfigSvc.getUserConfiguration().then(function (e) {
                appConfig = e
            })
        }

        function initConfiguration() {
            var e = [{
                name: "sortingProp",
                value: "vm.sortingProp"
            }, {
                name: "sortReverse",
                value: "vm.sortReverse"
            }, {
                name: "selectedTabId",
                value: "vm.selectedTabId"
            }, {
                name: "tabsSortIndex",
                value: "vm.tabsSortIndex",
                isArray: !0
            }, {
                name: "selectedView",
                value: "vm.selectedView"
            }, {
                name: "selectedBoxSorting",
                value: "vm.selectedBoxSorting"
            }, {
                name: "boxSortingProp",
                value: "vm.boxSortingProp"
            }];
            vm.isMobile || e.push({
                name: "visibleColumns",
                value: "vm.visibleColumns",
                isArray: !0
            }), "undefined" != typeof $scope.prepareConfiguration && $scope.prepareConfiguration(e)
        }

        function getOperatedSymbols() {
            return hbMarketSvc.getMarketPriceMonitorDetailOptimize().then(function (e) {
                var t = e.data.map(function (e, t) {
                    return e.issueID
                });
                return tabs.push({
                    id: -1,
                    name: "Opt",
                    symbols: t,
                    sortIndex: 2
                }), e
            })
        }

        function getSymbols() {
            if (vm.selectedTabId) {
                var e = tabs.filter(function (e, t) {
                    return e.id == vm.selectedTabId
                });
                if (e.length > 0) return e = e[0], e.symbols.length > 0 && "*" === e.symbols[0] ? "bmv" === e.name.toLowerCase() ? vm.nac : vm.sic : e.symbols.map(function (e, t) {
                    return hbSolaceSvc.getSymbol({
                        symbol: e
                    })
                })
            }
        }

        function verifySelectedTab(e) {
            var t = tabs.filter(function (t, n) {
                return t.id == e
            });
            t.length > 0 && (t = t[0], vm.selectedTab = t, vm.canvasConfig.emptyRows.isWatchList = t.id >= 1, vm.canvasConfig.emptyRows.watchListLength = vm.selectedTab.symbols.length, vm.searchText = t.searchText, 0 === t.symbols.length ? hbWatchListSvc.getWatchListDetail(e).then(function (e) {
                return vm.selectedSymbols = getSymbols(), e
            }) : vm.selectedSymbols = getSymbols())
        }

        function addMoreItems() {
            vm.itemsDisplayed += 10
        }

        function setOrder(e) {
            e && "" != e && (resetItemsDisplayed(), e === vm.sortingProp ? vm.sortReverse = !vm.sortReverse : (vm.sortingProp = e, vm.sortReverse = !0))
        }

        function getCaretClass() {
            return vm.sortReverse ? "fa fa-caret-down" : "fa fa-caret-up"
        }

        function watchList(e) {
            return vm.watchedSymbols
        }

        function toggleInWatchList(e, t) {
            showWatchListModal(t)
        }

        function selectSymbol(e) {
            notify(e)
        }

        function resetItemsDisplayed() {
            vm.itemsDisplayed = MAXLIMIT
        }

        function pageChanged(e) {
            vm.paging.currentPage = e
        }

        function updateWidgetTitle() {
            $scope.widget && $scope.widget.name
        }

        function addIssueToWatchList(e, t) {
            return hbWatchListSvc.addIssueWatchList(e, t || vm.selectedTabId)
        }

        function deleteIssueToWatchList(e) {
            return hbWatchListSvc.deleteIssueWatchList(e, vm.selectedTabId)
        }

        function getWatchListDetail(e) {
            return hbWatchListSvc.getWatchListDetail(e)
        }

        function showWatchListModal(e) {
            $modal.open({
                scope: $scope,
                templateUrl: "loadPartial/Monitor/WatchListSettings",
                windowClass: "watchList",
                controller: "hbWatchListCtrl",
                resolve: {
                    monitorCtrl: function () {
                        return vm
                    },
                    issue: function () {
                        return e
                    }
                }
            })
        }

        function notify(e) {
            if (e) {
                var t = {
                    emitter: $scope.widget.name,
                    symbol: e.symbol,
                    lastPrice: e.hechos.body.Last
                };
                $scope.notify(notificationTypes.SELECTED_SYMBOL, t)
            }
        }

        function createWatchList() {
            function e(e) {
                var t;
                if (e) {
                    var o = this;
                    vm.tabs.filter(function (e) {
                        return e.name === o.name
                    }).length > 1 ? (vm.tabs.splice(n, 1), t = common.$q.when(!1), vm.selectedTabId = i) : t = hbWatchListSvc.addWatchList(this.name, "").then(function (e) {
                        return tabsSortedCallback(), e
                    }, function (e) {
                        throw hbLoggingSvc.logging(e.data, hbLoggingSvc.loggingTypes.ERROR), new Error(e.data)
                    })
                } else vm.tabs.splice(n, 1), t = common.$q.when(!0);
                return t
            }
            var t = {
                id: 0,
                name: "",
                sortIndex: vm.tabs.length - 1,
                editName: !0,
                editNameCallback: e
            };
            vm.tabs.push(t);
            var n = getTabIndexById(0),
                i = vm.selectedTabId;
            vm.selectedTabId = 0
        }

        function showConfigureVisibleColumnsWindow() {
            var e = vm.canvasConfig.columns.map(function (e) {
                    return {
                        label: e.title,
                        enabled: e.visible
                    }
                }),
                t = this,
                n = $modal.open({
                    scope: $scope,
                    templateUrl: "loadPartial/ConfigureColumns/Index",
                    windowClass: "configure-columns",
                    controller: "configureColumnsCtrl",
                    resolve: {
                        parentCtrl: function () {
                            return t
                        },
                        columns: function () {
                            return e
                        }
                    }
                });
            n.result.then(function (t) {
                for (var n = 0, i = vm.visibleColumns.length; n < i; n++) vm.visibleColumns[n] = e[n].enabled
            })
        }

        function tabMenuItemSelected(e, t) {
            function n(e) {
                if (e) return tabsSortedCallback(), hbWatchListSvc.updateWatchList({
                    watchListTypeId: this.id,
                    title: this.name,
                    configuration: ""
                })["catch"](function (e) {
                    throw hbLoggingSvc.logging(e.data, hbLoggingSvc.loggingTypes.ERROR), new Error(e.data)
                })
            }
            switch (t) {
                case 0:
                    e.id > 0 ? (e.editName = !0, e.editNameCallback = n) : showConfigureVisibleColumnsWindow();
                    break;
                case 1:
                    e.id > 0 && showConfigureVisibleColumnsWindow();
                    break;
                case 2:
                    angular.isNumber(e.id) && hbWatchListSvc.deleteWatchList(e.id).then(function (e) {
                        return vm.selectedTabId = -3, e
                    })
            }
        }

        function tabMenuItemsBuilder(e) {
            if (e.id < 0) {
                var t = ['<i class="fa fa-edit"></i> ' + hbGlobalizationSvc.getResource("Monitor_Tab_Menu_Edit_Columns", !0, "")];
                return t
            }
            var n = ['<i class="fa fa-font"></i> ' + hbGlobalizationSvc.getResource("Monitor_Tab_Menu_Change_Name", !0, ""), '<i class="fa fa-edit"></i> ' + hbGlobalizationSvc.getResource("Monitor_Tab_Menu_Edit_Columns", !0, ""), '<i class="fa fa-trash-o"></i> ' + hbGlobalizationSvc.getResource("Monitor_Tab_Menu_Delete", !0, "")];
            return n
        }

        function generatePdfDomPage(e, t, n) {
            var i = "740px",
                o = $("<div></div>");
            o.css("width", i).css("margin-top", "1000px").addClass("operation"), o.css("background-color", "#FFFFFF"), appConfig.themeName && "dark" === appConfig.themeName.toLowerCase() && o.addClass("pdf-monitor");
            var r = $("<div></div>");
            r.css("text-align", "center"), r.html("<h2>Monitor</h2>"), o.append(r);
            var a = $("<table></table>");
            a.addClass("table").addClass("table-striped").addClass("table-hover").addClass("table-condensed"), a.css("background-color", "#FFFFFF").css("width", i);
            for (var s = vm.canvasConfig.columns, c = $("<tr></tr>"), l = 0, u = s.length; l < u; l++)
                if (vm.canvasConfig.columns[l].visible) {
                    var d = $("<td></td>"),
                        g = hbGlobalizationSvc.getResource("Monitor_ColumnName" + l, !0).toUpperCase();
                    d.text(g).addClass("report-header"), c.append(d)
                }
            a.append(c);
            for (var f = [], l = 0, u = s.length; l < u; l++) vm.canvasConfig.columns[l].visible && f.push(s[l]);
            for (var p = $filter("hbNumberFormatter"), h = {
                    minDecimals: 2,
                    maxDecimals: 2
                }, m = {
                    maxDecimals: 0,
                    scaleLengths: [4, 6],
                    scalePrefixes: ["K", "M"],
                    scaleDecimals: [1, 1],
                    scaleDividers: [1e3, 1e6]
                }, v = {
                    minDecimals: 2,
                    maxDecimals: 2,
                    suffix: "%"
                }, b = {
                    negativePrefix: "-",
                    negativeSuffix: "",
                    currency: !0
                }, l = e; l <= t; l++) {
                for (var c = $("<tr></tr>"), S = 0, y = f.length; S < y; S++) {
                    var T, d = $("<td></td>"),
                        C = f[S],
                        w = C.type,
                        I = getPropertieValue(n[l], C.name);
                    T = "float" === w ? p(I, h) : "int" === w ? p(I, m) : "money" === w ? p(I, b) : "percentage" === w ? p(I, v) : I, d.text(T).addClass("report-row"), c.append(d)
                }
                a.append(c)
            }
            o.append(a);
            var _ = $('<div class="light"></div>');
            return _.append(o), _.css("width", i), _
        }

        function getPropertieValue(e, t) {
            return t.split(".").reduce(function (e, t) {
                if ("object" == typeof e && e[t] !== undefined) return e[t]
            }, e)
        }

        function getDownloadData(options) {
            var filteredCollection = $filter("orderBy")(vm.selectedSymbols, vm.sortingProp, vm.sortReverse);
            if ("pdf" === options.format.extension) {
                var domElements = [],
                    rowsPerPage = 40,
                    from = 0,
                    to = 0,
                    pivot = 0,
                    total = filteredCollection.length,
                    stepCount = ~~(total / rowsPerPage);
                total % rowsPerPage !== 0 && stepCount++;
                for (var step = 0; step < stepCount; step++) {
                    pivot = rowsPerPage * step, from = pivot > 0 ? pivot + 1 : pivot, to = pivot + rowsPerPage >= filteredCollection.length ? filteredCollection.length - 1 : pivot + rowsPerPage;
                    var containerElem = generatePdfDomPage(from, to, filteredCollection);
                    domElements.push(containerElem[0]), $(document.body).append(containerElem)
                }
                return {
                    type: "DOM",
                    domElements: domElements,
                    generationCompleted: function () {
                        for (var e = 0, t = domElements.length; e < t; e++);
                    }
                }
            }
            if ("csv" === options.format.extension) {
                for (var columns = vm.canvasConfig.columns, headers = [], colvisibles = [], i = 0, ilen = columns.length; i < ilen; i++)
                    if (vm.canvasConfig.columns[i].visible) {
                        var colName = hbGlobalizationSvc.getResource("Monitor_ColumnName" + i, !0).toUpperCase();
                        headers.push(colName), colvisibles.push(columns[i])
                    }
                for (var rows = [], i = 0, ilen = filteredCollection.length; i < ilen; i++) {
                    for (var row = [], j = 0, jlen = colvisibles.length; j < jlen; j++) {
                        var attribute = colvisibles[j];
                        row.push(eval("filteredCollection[i]." + attribute.name))
                    }
                    rows.push(row)
                }
                return {
                    header: headers,
                    rows: rows
                }
            }
        }

        function dropTrashCallback(e, t, n) {
            deleteIssueToWatchList(n.payload.symbol)
        }

        function tabsSortedCallback() {
            vm.tabsSortIndex.length > 0 && (vm.tabsSortIndex.length = 0), tabs.sort(function (e, t) {
                return e.sortIndex - t.sortIndex
            });
            for (var e = 0, t = tabs.length; e < t; e++) vm.tabsSortIndex[e] = tabs[e].name
        }

        function setBoxSorting(e) {
            "watchlist" === e ? "watchlist" === vm.boxSortingProp ? vm.boxSortingProp = "" : vm.boxSortingProp = e : e === vm.boxSortingProp ? vm.boxSortingProp = "-" + e : vm.boxSortingProp = e, vm.selectedBoxSorting = vm.boxSortingProp
        }

        function getTabsById(e) {
            var t;
            return t = vm.tabs.filter(function (t, n) {
                return t.id == e
            }), t = t[0]
        }

        function getTabIndexById(e) {
            for (var t, n = 0; n < vm.tabs.length; n++)
                if (vm.tabs[n].id == e) {
                    t = n;
                    break
                }
            return t
        }

        function setupScrollbars() {
            var e = $scope.$parent.widget.size_y * hbGridsterOptions.colWidth;
            e && (vm.scrollViewHeight = e - 140 + "px")
        }
        var itemsChanged = [],
            MAXLIMIT = 10,
            tabs = [{
                id: -3,
                name: "BMV",
                symbols: ["*"],
                sortIndex: 0,
                searchText: ""
            }],
            vm = this,
            appConfig = {};
        vm.selectedView = "Canvas", vm.canvasTemplate = "iecanvas", vm.nac = hbSolaceSvc.getNac(), vm.sic = hbSolaceSvc.getSic(), vm.tabs = tabs, vm.selectedTab = tabs[0], vm.selectedTabId = tabs[0].id, vm.selectedSymbols = [], vm.tabsSortIndex = [], vm.updateTimePosturas = hbSolaceSvc.TimePosturas, vm.updateTimeHechos = hbSolaceSvc.TimeHechos, vm.sortingProp = "symbol", vm.sortReverse = !1, vm.setOrder = setOrder, vm.getCaretClass = getCaretClass, vm.searchText = "", vm.itemsDisplayed = MAXLIMIT, vm.selectSymbol = selectSymbol, vm.watchList = watchList, vm.toggleInWatchList = toggleInWatchList, vm.watchedSymbols = {}, vm.draggedIssue = null, vm.showWatchListModal = showWatchListModal, vm.watchListArr = hbWatchListSvc.watchListArr, vm.scrollViewHeight = 0, vm.scrollSpeed = "firefox" === hbBrowserSvc() ? 20 : 1, vm.createWatchList = createWatchList, vm.tabMenuItemSelected = tabMenuItemSelected, vm.tabMenuItemsBuilder = tabMenuItemsBuilder, vm.allowEmptyValues = !0, vm.dragCallback = dragCallback, vm.dragStartCallback = dragStartCallback, vm.dndHelper = hbDragNDropHelperSvc, vm.dropCallback = dropCallback, vm.dropTrashCallback = dropTrashCallback, vm.dragOverCallback = dragOverCallback, vm.dragOutCallback = dragOutCallback, vm.dragTableRow = dragSymbol, vm.droppedIssue = droppedIssue, vm.tabAcceptedDropSources = tabAcceptedDropSources, vm.tabsSortedCallback = tabsSortedCallback, vm.setBoxSorting = setBoxSorting, vm.boxSortingProp = vm.selectedBoxSorting = "symbol", vm.visibleColumns, vm.isMobile = common.mobileProperties.isMobile, vm.notify = notify;
        var darkTheme = {
                color: "#FFFFFF",
                backgroundColor: "#292922",
                oddBackgroundColor: "#24241e",
                emptyRows: {
                    shadowBackgroundColor: "#52524A",
                    colorTitle: "#FFFFFF",
                    colorSubtitle: "#63d1bd"
                },
                header: {
                    color: "#FFFFFF",
                    backgroundColor: "#52524a"
                },
                selected: {
                    color: "#FFFFFF",
                    backgroundColor: "rgba(99, 208, 188, .15)",
                    borderColor: "#63d0bc"
                },
                hovered: {
                    color: "#FFFFFF",
                    backgroundColor: "rgba(99, 208, 188, .15)",
                    borderColor: "#63d0bc"
                },
                blink: {
                    positive: {
                        color: "#96EB50"
                    },
                    negative: {
                        color: "#cf2b18"
                    }
                },
                scrollbar: {
                    color: "#666666"
                },
                sorting: {
                    caretUp: "Content/images/caret_up.png",
                    caretDown: "Content/images/caret_down.png"
                }
            },
            lightTheme = {
                color: "#525246",
                backgroundColor: "#f4f4f4",
                oddBackgroundColor: "#FFFFFF",
                emptyRows: {
                    shadowBackgroundColor: "#52524A",
                    colorTitle: "#FFFFFF",
                    colorSubtitle: "#63d1bd"
                },
                header: {
                    color: "#000000",
                    backgroundColor: "#ededeb"
                },
                selected: {
                    color: "#FFFFFF",
                    backgroundColor: "rgba(99, 208, 188, .4)",
                    borderColor: "#63d0bc"
                },
                hovered: {
                    color: "#FFFFFF",
                    backgroundColor: "rgba(99, 208, 188, .4)",
                    borderColor: "#63d0bc"
                },
                blink: {
                    positive: {
                        color: "#96EB50"
                    },
                    negative: {
                        color: "#cf2b18"
                    }
                },
                scrollbar: {
                    color: "#63d1bd"
                },
                sorting: {
                    caretUp: "Content/images/caret_up_gray.png",
                    caretDown: "Content/images/caret_down_gray.png"
                }
            };
        vm.canvasConfig = {
            emptyRows: {
                emptyRowsTitle: "",
                emptyRowsSubtitle: "",
                trashTitle: "",
                culture: hbCultureManagementSvc.defaultCulture.cultureId,
                isWatchList: !1,
                watchListLength: 0
            },
            theme: {},
            columns: [{
                name: "symbol",
                type: "string",
                animateOnChange: !1,
                width: 16,
                title: "Issue".toUpperCase(),
                visible: !0,
                useEllipsis: !0
            }, {
                name: "hechos.closePrice",
                type: "money",
                animateOnChange: !1,
                width: 8,
                title: "Closed".toUpperCase(),
                visible: !1
            }, {
                name: "hechos.body.Last",
                type: "money",
                animateOnChange: !0,
                width: 8,
                title: "Last".toUpperCase(),
                visible: !0,
                color: {
                    negative: "#FF0000",
                    positive: "#96eb50"
                },
                reference: "hechos.closePrice"
            }, {
                name: "hechos.body.changeAvg",
                type: "percentage",
                animateOnChange: !0,
                width: 8,
                title: "Change %".toUpperCase(),
                visible: !0,
                color: {
                    negative: "#FF0000",
                    positive: "#96eb50"
                },
                reference: 0
            }, {
                name: "hechos.body.ppp",
                type: "money",
                animateOnChange: !0,
                width: 6,
                title: "WAP".toUpperCase(),
                visible: !1
            }, {
                name: "hechos.body.averageVolume6M",
                type: "int",
                animateOnChange: !1,
                width: 10,
                title: "6 Month avg.",
                visible: !1
            }, {
                name: "hechos.body.aggVolume",
                type: "int",
                animateOnChange: !0,
                width: 11,
                title: "Operation vol.".toUpperCase(),
                visible: !0
            }, {
                name: "posturas.body[0].BuyPrice",
                type: "money",
                animateOnChange: !0,
                width: 8,
                title: "Buy price".toUpperCase(),
                visible: !0,
                overlay: {
                    color: "rgba(96,162,252, 0.05)",
                    border: "#60A2FC"
                },
                color: {
                    negative: "#FF0000",
                    positive: "#96eb50"
                },
                reference: "hechos.body.Last"
            }, {
                name: "posturas.body[0].BuyVolume",
                type: "int",
                animateOnChange: !0,
                width: 8,
                title: "Buy vol.".toUpperCase(),
                visible: !0,
                overlay: {
                    color: "rgba(96,162,252, 0.05)",
                    border: "#60A2FC"
                }
            }, {
                name: "posturas.body[0].SellPrice",
                type: "money",
                animateOnChange: !0,
                width: 8,
                title: "Sell price".toUpperCase(),
                visible: !0,
                overlay: {
                    color: "rgba(168, 220, 1, 0.05)",
                    border: "#A8DC01"
                },
                color: {
                    negative: "#FF0000",
                    positive: "#96eb50"
                },
                reference: "hechos.body.Last"
            }, {
                name: "posturas.body[0].SellVolume",
                type: "int",
                animateOnChange: !0,
                width: 8,
                title: "Sell vol.".toUpperCase(),
                visible: !0,
                overlay: {
                    color: "rgba(168, 220, 1, 0.05)",
                    border: "#A8DC01"
                }
            }]
        }, $rootScope.$on("mobile-resize-" + $scope.widget.id, function (e, t) {
            $scope.$broadcast("window_resized_completed")
        }), $scope.$watch(function () {
            return common.mobileProperties.isMobile
        }, function (e, t) {
            vm.isMobile = e, vm.visibleColumns = [!0, !1, !0, !0, !1, !1, !0, !vm.isMobile, !vm.isMobile, !vm.isMobile, !vm.isMobile]
        }), $scope.$watch(function () {
            return hbSolaceSvc.TimePosturas
        }, function (e, t) {
            vm.updateTimePosturas = e, updateWidgetTitle()
        }), $scope.$watch(function () {
            return hbSolaceSvc.TimeHechos
        }, function (e, t) {
            vm.updateTimeHechos = e, updateWidgetTitle()
        }), $scope.$watch("vm.tabsSortIndex", function (e, t) {
            if ((!t || 0 === t.length) && e && e.length > 0)
                for (var n = 0, i = tabs.length; n < i; n++) tabs[n].sortIndex = e.indexOf(tabs[n].name);
            else vm.tabsSortIndex === undefined && (vm.tabsSortIndex = [])
        }), $scope.$watch("vm.selectedTabId", function (e, t) {
            if (e) {
                var n = tabs.filter(function (e, n) {
                    return e.id == t
                });
                n.length > 0 && (n = n[0], n.searchText = vm.searchText), verifySelectedTab(e)
            }
        }), $scope.$watchCollection("vm.watchListArr", function (e, t) {
            if (e) {
                if (angular.forEach(e, function (e, t) {
                        var n = getTabsById(e.id);
                        if (!n) {
                            var i = getTabIndexById(0);
                            i && (vm.tabs.splice(i, 1), vm.selectedTabId = e.id);
                            var o = new WatchListTab(e);
                            o.sortIndex = vm.tabs.length - 1, o.sortIndex = vm.tabsSortIndex.indexOf(o.name), vm.tabs.push(o)
                        }
                    }), e.length < t.length) {
                    var n = _.difference(t, e);
                    angular.forEach(n, function (e, t) {
                        for (var n = -1, i = 0; i < vm.tabs.length; i++)
                            if (vm.tabs[i].id === e.id) {
                                n = i;
                                break
                            }
                        n && vm.tabs.splice(n, 1)
                    })
                }
                verifySelectedTab(vm.selectedTabId)
            }
        }), $scope.$watchCollection("vm.selectedTab.symbols", function (e, t) {
            (e && !t || e && e.length !== t.length) && (vm.canvasConfig.emptyRows.watchListLength = vm.selectedTab.symbols.length, vm.selectedSymbols = getSymbols())
        }), $scope.$watchCollection("vm.visibleColumns", function (e, t) {
            e || (vm.visibleColumns = [!0, !1, !0, !0, !1, !1, !0, !vm.isMobile, !vm.isMobile, !vm.isMobile, !vm.isMobile]), vm.visibleColumns.forEach(function (e, t) {
                vm.canvasConfig.columns[t].visible = e
            })
        }), $scope.$watch(function () {
            return appConfig
        }, function (e, t) {
            if (e && e.themeName) {
                var n = e.themeName.toLowerCase();
                if ("light" === n) {
                    for (var i = 0, o = vm.canvasConfig.columns.length; i < o; i++) null !== vm.canvasConfig.columns[i].reference && vm.canvasConfig.columns[i].reference !== undefined && (vm.canvasConfig.columns[i].color.negative = "#FF0000", vm.canvasConfig.columns[i].color.positive = "#339933");
                    angular.extend(vm.canvasConfig.theme, lightTheme)
                } else {
                    for (var i = 0, o = vm.canvasConfig.columns.length; i < o; i++) null !== vm.canvasConfig.columns[i].reference && vm.canvasConfig.columns[i].reference !== undefined && (vm.canvasConfig.columns[i].color.negative = "#FF0000", vm.canvasConfig.columns[i].color.positive = "#96eb50");
                    angular.extend(vm.canvasConfig.theme, darkTheme)
                }
            }
        }, !0), $scope.subscribreToNotifications && $scope.subscribreToNotifications(), $scope.$watch(function () {
            return $scope.$parent.widget.size_y
        }, function () {
            setupScrollbars()
        }), activate(), $scope.setSupportedDownloadExt(getDownloadData, ["pdf", "csv"])
    }

    function WatchListTab(e) {
        this.id = e.id, this.configuration = e.configuration, this.symbols = e.symbols, this.sortIndex = 0, this._src = e, this._name = e.name, this.editName = !1, Object.defineProperty(this, "name", {
            get: function () {
                return this.editName ? this._name : this._src.name
            },
            set: function (e) {
                this._name = e
            }
        })
    }
    var controllerId = "hbMonitorCtrl";
    angular.module("app").controller(controllerId, ["$filter", "$modal", "$scope", "$rootScope", "common", "notificationTypes", "hbLoggingSvc", "hbMarketSvc", "hbSolaceSvc", "hbDragNDropHelperSvc", "hbWatchListSvc", "hbGlobalizationSvc", "hbContractManagementSvc", "hbCultureManagementSvc", "hbUserAppConfigSvc", "hbGridsterOptions", "hbBrowserSvc", hbMonitorCtrl])
}(),
function () {
    "use strict";

    function e(e, t, n, i, o) {
        e.watchListArr = n.watchListArr, e.selectedWatchList = {}, e.dismiss = function () {
            t.close()
        }, e.addToWatchList = function () {
            this.dismiss()
        }, e.selectWatchList = function (e) {
            selectedWatchList.push(e), this.dismiss()
        }, e.addWidget = function () {
            this.dismiss()
        }, e.deleteDashboard = function () {
            this.dismiss()
        }
    }
    var t = "hbWatchListCtrl";
    angular.module("app").controller(t, ["$scope", "$modalInstance", "monitorCtrl", "issue", "hbWatchListSvc", e])
}(),
function (e) {
    "use strict";

    function t(t, a, s, c, u, d, g, f, p, h, m, v) {
        function b(e, n) {
            if (t.issueMix) {
                var i = e.name.substring(0, e.name.indexOf("."));
                switch (c[i]) {
                    case c.SELECTED_SYMBOL:
                    case c.SEARCHED_SYMBOL:
                    case c.SELECTED_POSITION_CAPITAL:
                        W.searchedSymbol = n.symbol, W.selectedMobileRow = {
                            identifier: "",
                            row: {}
                        };
                        break;
                    default:
                        d.logging("unhandled notification type received", d.loggingTypes.EXCEPTION)
                }
            }
        }

        function S(e) {
            if (W.columns)
                for (var t = 0; t < W.columns.length; t++)
                    if (W.columns[t].name === e) return W.columns[t].enabled
        }

        function y(e, n) {
            for (var i = [], o = 0, r = n.length; o < r; o++) 0 === e ? [0, 8, 9].indexOf(o) === -1 && i.push(n[o]) : 1 === e ? [7, 8].indexOf(o) === -1 && i.push(n[o]) : 3 === e && [7, 8].indexOf(o) === -1 && i.push(n[o]);
            var a = this;
            p.open({
                scope: t,
                templateUrl: "loadPartial/ConfigureColumns/Index",
                windowClass: "configure-columns",
                controller: "configureColumnsCtrl",
                resolve: {
                    parentCtrl: function () {
                        return a
                    },
                    columns: function () {
                        return i
                    }
                }
            })
        }

        function T(e) {
            e && "" != e && (C(), e === W.sortingProp ? W.sortReverse = !W.sortReverse : (W.sortingProp = e, W.sortReverse = !0))
        }

        function C() {
            W.itemsDisplayed = z
        }

        function w() {
            return W.sortReverse ? "fa fa-caret-down" : "fa fa-caret-up"
        }

        function I() {
            var n = [E(), g.load("Blotter")];
            s.activateController(n, l).then(function () {
                if (t.loadConfiguration !== e) {
                    var n = t.loadConfiguration(V);
                    s.$q.all([n]).then(function () {
                        P(), t.setRefreshFunction(_, V), t.notifyWidgetReady("Blotter"), W.selectedMobileRow = {
                            identifier: "",
                            row: {}
                        }
                    })
                }
            })
        }

        function _() {
            switch (W.selectedTabId) {
                case 0:
                    h.getStockOrders(!0, !0);
                    break;
                case 1:
                    h.getFundsOrders(!0, !0);
                    break;
                case 2:
                    break;
                case 3:
                    h.getCashOrders(!0, !0)
            }
        }

        function P() {
            W.stocksColumns = [{
                name: "showActions",
                enabled: O(W.stocksColumns, 0, !0)
            }, {
                name: "showId",
                enabled: O(W.stocksColumns, 1, !1)
            }, {
                name: "showDate",
                enabled: O(W.stocksColumns, 2, !0)
            }, {
                name: "showIssuer",
                enabled: O(W.stocksColumns, 3, !0)
            }, {
                name: "showOriginal",
                enabled: O(W.stocksColumns, 4, !0)
            }, {
                name: "showLimitPrice",
                enabled: O(W.stocksColumns, 5, !0)
            }, {
                name: "showAveragePrice",
                enabled: O(W.stocksColumns, 6, !1)
            }, {
                name: "showStopPrice",
                enabled: O(W.stocksColumns, 7, !1)
            }, {
                name: "showOrderType",
                enabled: O(W.stocksColumns, 8, !0)
            }, {
                name: "showStatus",
                enabled: O(W.stocksColumns, 9, !0)
            }, {
                name: "showDirection",
                enabled: O(W.stocksColumns, 10, !1)
            }, {
                name: "showAssign",
                enabled: O(W.stocksColumns, 11, !0)
            }, {
                name: "showCancel",
                enabled: O(W.stocksColumns, 12, !1)
            }, {
                name: "showCharges",
                enabled: O(W.stocksColumns, 13, !1)
            }], W.foundsColumns = [{
                name: "showId",
                enabled: O(W.foundsColumns, 0, !1)
            }, {
                name: "showDate",
                enabled: O(W.foundsColumns, 1, !0)
            }, {
                name: "showIssuer",
                enabled: O(W.foundsColumns, 2, !0)
            }, {
                name: "showOriginal",
                enabled: O(W.foundsColumns, 3, !0)
            }, {
                name: "showLimitPrice",
                enabled: O(W.foundsColumns, 4, !0)
            }, {
                name: "showAveragePrice",
                enabled: O(W.foundsColumns, 5, !1)
            }, {
                name: "showStopPrice",
                enabled: O(W.foundsColumns, 6, !1)
            }, {
                name: "showOrderType",
                enabled: O(W.foundsColumns, 7, !0)
            }, {
                name: "showStatus",
                enabled: O(W.foundsColumns, 8, !0)
            }, {
                name: "showDirection",
                enabled: O(W.foundsColumns, 9, !1)
            }, {
                name: "showAssign",
                enabled: O(W.foundsColumns, 10, !0)
            }, {
                name: "showCancel",
                enabled: O(W.foundsColumns, 11, !1)
            }, {
                name: "showCharges",
                enabled: O(W.foundsColumns, 12, !1)
            }], W.cashColumns = [{
                name: "showId",
                enabled: O(W.cashColumns, 0, !1)
            }, {
                name: "showDate",
                enabled: O(W.cashColumns, 1, !0)
            }, {
                name: "showIssuer",
                enabled: O(W.cashColumns, 2, !0)
            }, {
                name: "showOriginal",
                enabled: O(W.cashColumns, 3, !0)
            }, {
                name: "showLimitPrice",
                enabled: O(W.cashColumns, 4, !0)
            }, {
                name: "showAveragePrice",
                enabled: O(W.cashColumns, 5, !1)
            }, {
                name: "showStopPrice",
                enabled: O(W.cashColumns, 6, !1)
            }, {
                name: "showOrderType",
                enabled: O(W.cashColumns, 7, !0)
            }, {
                name: "showStatus",
                enabled: O(W.cashColumns, 8, !0)
            }, {
                name: "showDirection",
                enabled: O(W.cashColumns, 9, !1)
}, {
                name: "showAssign",
                enabled: O(W.cashColumns, 10, !0)
            }, {
                name: "showCancel",
                enabled: O(W.cashColumns, 11, !1)
            }, {
                name: "showCharges",
                enabled: O(W.cashColumns, 12, !1)
            }], W.columns = W.stocksColumns;
            var e = ["Blotter_JS_MSG_Id", "Blotter_JS_MSG_Date", "Blotter_JS_MSG_Issuer", "Blotter_JS_MSG_Original", "Blotter_JS_MSG_LimitPrice", "Blotter_JS_MSG_AveragePrice", "Blotter_JS_MSG_StopPrice", "Blotter_JS_MSG_OrderType", "Blotter_JS_MSG_Status", "Blotter_JS_MSG_Sense", "Blotter_JS_MSG_Assign", "Blotter_JS_MSG_Cancel", "Blotter_JS_MSG_Charges"];
            M(W.cashColumns, e, "label");
            var e = ["Blotter_JS_MSG_Id", "Blotter_JS_MSG_Date", "Blotter_JS_MSG_Issuer", "Blotter_JS_MSG_Original", "Blotter_JS_MSG_LimitPrice", "Blotter_JS_MSG_AveragePrice", "Blotter_JS_MSG_StopPrice", "Blotter_JS_MSG_OrderType", "Blotter_JS_MSG_Status", "Blotter_JS_MSG_Sense", "Blotter_JS_MSG_Assign", "Blotter_JS_MSG_Cancel", "Blotter_JS_MSG_Charges"];
            M(W.foundsColumns, e, "label");
            var e = ["Blotter_JS_MSG_Actions", "Blotter_JS_MSG_Id", "Blotter_JS_MSG_Date", "Blotter_JS_MSG_Issuer", "Blotter_JS_MSG_Original", "Blotter_JS_MSG_LimitPrice", "Blotter_JS_MSG_AveragePrice", "Blotter_JS_MSG_StopPrice", "Blotter_JS_MSG_OrderType", "Blotter_JS_MSG_Status", "Blotter_JS_MSG_Sense", "Blotter_JS_MSG_Assign", "Blotter_JS_MSG_Cancel", "Blotter_JS_MSG_Charges"];
            M(W.stocksColumns, e, "label"), e = ["Blotter_JS_MSG_OPEN_ORDERS", "Blotter_JS_MSG_CLOSED_ORDERS", "Blotter_JS_MSG_PENDING_ORDERS", "Blotter_JS_MSG_PREDISPATCHED_ORDERS", "Blotter_JS_MSG_ALL_ORDERS"], M(W.customStatusList, e, "name"), e = ["Blotter_JS_MSG_STATUS_PENDING_NEW", "Blotter_JS_MSG_STATUS_NEW", "Blotter_JS_MSG_STATUS_CANCEL_PENDING", "Blotter_JS_MSG_STATUS_CANCELLED", "Blotter_JS_MSG_STATUS_CANCEL_REJECTED", "Blotter_JS_MSG_STATUS_FILLED", "Blotter_JS_MSG_STATUS_PARTIALLY_FILLED", "Blotter_JS_MSG_STATUS_REJECTED", "Blotter_JS_MSG_STATUS_ACK_GBM", "Blotter_JS_MSG_STATUS_REJECTED_GBM"], M(W.statusList, e, "name"), e = ["Blotter_JS_MSG_Buy", "Blotter_JS_MSG_Sell", "Blotter_JS_MSG_ALL_ORDERS"], M(W.orderTypeFilterList, e, "name"), e = ["Blotter_JS_MSG_Capitales", "Blotter_JS_MSG_Fondos", "Blotter_JS_MSG_Efectivo"], M(W.tabs, e, "name")
        }

        function M(e, t, n) {
            for (var i = 0, o = t.length; i < o; i++) e[i][n] = g.getResource(t[i], !0)
        }

        function O(e, t, n) {
            return e && e[t] ? e[t].enabled : n
        }

        function E() {
            var n = [{
                name: "contract",
                value: "vm.contract"
            }, {
                name: "searchText",
                value: "vm.searchText"
            }, {
                name: "sortingProp",
                value: "vm.sortingProp"
            }, {
                name: "sortReverse",
                value: "vm.sortReverse"
            }, {
                name: "selectedTabId",
                value: "vm.selectedTabId"
            }, {
                name: "selectedStatusFilter",
                value: "vm.selectedStatusFilter"
            }, {
                name: "selectedOrderTypeFilter",
                value: "vm.selectedOrderTypeFilter"
            }, {
                name: "stocksColumns",
                value: "vm.stocksColumns",
                isArray: !0
            }, {
                name: "foundsColumns",
                value: "vm.foundsColumns",
                isArray: !0
            }, {
                name: "cashColumns",
                value: "vm.cashColumns",
                isArray: !0
            }];
            t.issueMix && n.push({
                name: "searchedSymbol",
                value: "vm.searchedSymbol"
            }), t.prepareConfiguration !== e && t.prepareConfiguration(n, V, t)
        }

        function D(e) {
            var t;
            switch (e) {
                case 4:
                case 9:
                case 22:
                    t = "text-danger; item-elipsis";
                    break;
                case 8:
                case 7:
                    t = "text-success; item-elipsis"
            }
            return t
        }

        function A() {
            var e = !a.getUser().isReadAndWrite;
            e ? p.open({
                scope: t,
                templateUrl: "loadPartial/Operation/TokenNeeded",
                windowClass: "cancel-all",
                controller: "hbTokenNeededCtrl",
                resolve: {}
            }) : (h.cancelAllCapitalMarketOrders(), W.isMobile && (W.selectedMobileRow = {
                identifier: "",
                row: {}
            }))
        }

        function k(e, t) {
            e.response ? g.getResource("Blotter_JS_MSG_CANCEL_SUCCESS").then(function (e) {
                d.logging(e.replace(/\{0\}/g, t), d.loggingTypes.SUCCESS)
            }) : g.getResource("Blotter_JS_MSG_CANCEL_EXCEPTION").then(function () {
                d.logging(result.replace(/\{0\}/g, t), d.loggingTypes.EXCEPTION)
            })
        }

        function L(e) {
            var n = 0;
            n = e.vigencia ? e.vigenciaId : e.predespachador ? e.preorderId : e.sobId;
            var i = !a.getUser().isReadAndWrite;
            i ? p.open({
                scope: t,
                templateUrl: "loadPartial/Operation/TokenNeeded",
                windowClass: "cancel-all",
                controller: "hbTokenNeededCtrl",
                resolve: {}
            }) : h.cancelCapitalMarketOrder(n, !!e.predespachador, !!e.vigencia).then(function (e) {
                k(e.data, n), W.isMobile && (W.selectedMobileRow = {
                    identifier: "",
                    row: {}
                })
            }, function (e) {
                d.logging(e.data, d.loggingTypes.EXCEPTION)
            })
        }

        function x(e) {
            var n = s.$q.defer(),
                i = !a.getUser().isReadAndWrite;
            if (i) p.open({
                scope: t,
                templateUrl: "loadPartial/Operation/TokenNeeded",
                windowClass: "cancel-all",
                controller: "hbTokenNeededCtrl",
                resolve: {}
            });
            else {
                var o = 0;
                o = e.vigencia ? e.vigenciaId : e.predespachador ? e.preorderId : e.sobId, h.cancelCapitalMarketOrder(o, !!e.predespachador, e.vigencia).then(function (i) {
                    k(i.data, o);
                    var r = e.originalQuantity - e.assignedQuantity,
                        a = {
                            operation: e.bitBuy,
                            issue: e.issueId,
                            quantity: r,
                            price: e.price,
                            orderType: e.capitalOrderTypeId
                        };
                    t.notify(c.SELECTED_BLOTTER_ORDER, a), W.isMobile && (W.selectedMobileRow = {
                        identifier: "",
                        row: {}
                    }), n.resolve(i.data)
                }, function (e) {
                    d.logging(e.data, d.loggingTypes.EXCEPTION), n.reject("Error")
                })
            }
            return n.promise
        }

        function $() {
            var e = this;
            p.open({
                scope: t,
                templateUrl: "loadPartial/Blotter/CancelAll",
                windowClass: "cancel-all",
                controller: "cancelAllCtrl",
                resolve: {
                    cancelAction: function () {
                        return W.cancelAllCapitalMarketOrders.bind(e)
                    }
                }
            })
        }

        function B() {
            var e = t.$parent.widget.size_y * m.colWidth,
                n = t.$parent.widget.size_x * m.colWidth;
            e && (t.issueMix ? (W.scrollViewHeight = e - 140, W.isMobile ? W.scrollViewWidth = n - 300 : W.scrollViewWidth = n - 25) : (W.scrollViewHeight = e - 100, W.scrollViewWidth = W.isMobile ? 100 : n - 20), W.scrollViewHeight = W.scrollViewHeight + "px", W.scrollViewWidth = W.scrollViewWidth + (W.isMobile ? "%" : "px"))
        }

        function R(e) {
            if (e) switch (W.selectedTabId) {
                case 0:
                    var n = {
                        emitter: t.widget.name,
                        symbol: e.issueId
                    };
                    t.notify(c.SELECTED_SYMBOL, n);
                    break;
                case 1:
                    var n = {
                        emitter: t.widget.name,
                        symbol: e
                    };
                    t.notify(c.SELECTED_SYMBOL_FUNDS, n);
                    break;
                case 3:
                    var n = {
                        emitter: t.widget.name,
                        symbol: e
                    };
                    t.notify(c.SELECTED_SYMBOL_CASH, n)
            }
        }

        function N(e) {
            if (J) {
                var t = e.processDate + "||" + e.issueId + "||" + e.price + "||" + e.sobId + "||" + e.originalQuantity;
                W.selectedMobileRow.identifier = t, W.selectedMobileRow.row = e
            } else W.selectedMobileRow = {
                identifier: "",
                row: {}
            }, J = !0
        }

        function U(e) {
            var t = e.processDate + "||" + e.issueId + "||" + e.price + "||" + e.sobId + "||" + e.originalQuantity;
            if (W.isMobile && W.selectedMobileRow.identifier == t) return "table-row-hover-blotter"
        }

        function F(e) {
            var t = e.processDate + "||" + e.issueId + "||" + e.price + "||" + e.sobId + "||" + e.originalQuantity;
            return W.isMobile && W.selectedMobileRow.identifier == t ? H : ""
        }
        var G = [{
                sub: c.SELECTED_SYMBOL,
                unsub: e
            }, {
                sub: c.SEARCHED_SYMBOL,
                unsub: e
            }, {
                sub: c.SELECTED_POSITION_CAPITAL,
                unsub: e
            }],
            V = "blotter",
            W = this,
            z = 50,
            H = {
                "border-style": "solid",
                "border-width": "1px",
                "border-color": "#63d1bd"
            };
        W.stockOrders = h.getStockOrders(!0, !0), W.fundOrders = h.getFundsOrders(!0, !0), W.cashOrders = h.getCashOrders(!0, !0), W.cancelCapitalMarketOrder = L, W.cancelCapitalMarketOrderAndReplace = x, W.cancelAllCapitalMarketOrders = A, W.getStatusClass = D, W.notifyIssueSelected = R, W.showConfigureColumns = y, W.showColumn = S, W.columns = [], W.sortingProp = "processDate", W.sortReverse = !0, W.setOrder = T, W.getCaretClass = w, W.searchText = "", W.displayConfirm = $, W.isCancelDisabled = !1, W.tabs = [{
            id: 0
        }, {
            id: 1
        }, {
            id: 3
        }], W.selectedTabId, W.tabMenuItemSelected = o, W.tabMenuItemsBuilder = r, W.showCustomTable = !1, W.showCapitalTable = !1, W.customFilter = [], W.noRecordsFound = !1, W.noRecordsFoundCustomTable = !1, W.selectedStatusFilter, W.selectedOrderTypeFilter, W.setStatusFilter = n, W.setOrderTypeFilter = i, W.customStatusList = [{
            id: "*open",
            icon: "fa-folder-open"
        }, {
            id: "*closed",
            icon: "fa-folder"
        }, {
            id: "*pending",
            icon: "fa-exclamation"
        }, {
            id: "*predispatcher",
            icon: "fa-inbox"
        }, {
            id: "*all",
            icon: "fa-folder-o"
        }], W.clearStatusFilter = W.customStatusList[W.customStatusList.length - 1], W.statusList = [{
            id: 1
        }, {
            id: [2, 23]
        }, {
            id: 4
        }, {
            id: 5
        }, {
            id: 6
        }, {
            id: 7
        }, {
            id: 8
        }, {
            id: 9
        }, {
            id: 10
        }, {
            id: 22
        }], W.orderTypeFilterList = [{
            id: "*buy",
            icon: "fa-certificate"
        }, {
            id: "*sell",
            icon: "fa-certificate"
        }, {
            id: "*all",
            icon: "fa-folder-o"
        }], W.clearOrderTypeFilter = W.orderTypeFilterList[W.orderTypeFilterList.length - 1], W.OrderTypeList = [{
            id: 1,
            name: "CompraNormal"
        }, {
            id: 8,
            name: "VentaNormal"
        }, {
            id: 13,
            name: "VentaCorto"
        }, {
            id: 16,
            name: "CompraGlobal"
        }, {
            id: 18,
            name: "VentaGlobal"
        }, {
            id: 44,
            name: "CompraMPLActiva"
        }, {
            id: 45,
            name: "VentaMPLActiva"
        }, {
            id: 46,
            name: "CompraMPLPasiva"
        }, {
            id: 47,
            name: "VentaMPLPasiva"
        }, {
            id: 60,
            name: "CompraMPLSentidoOpuesto"
        }, {
            id: 61,
            name: "VentaMPLSentidoOpuesto"
        }, {
            id: 62,
            name: "CompraMPLVolumenOculto"
        }, {
            id: 63,
            name: "VentaMPLVolumenOculto"
        }], W.showSearch = !0, W.hideSearch = function () {
            W.showSearch = !1, W.selectedTabId = W.tabs[0].id
        }, W.scrollViewHeight = 0, W.scrollViewWidth = 0, W.scrollSpeed = "firefox" === v() ? 20 : 1, W.isMobile = s.mobileProperties.isMobile, W.selectMobileRow = N, W.validateMobileRow = U, W.styleRow = F, W.selectedMobileRow = {
            identifier: "",
            row: {}
        };
        var J = !1;
        W.orderTypeSelected = W.orderTypeFilterList[0], W.statusMobile = [], Array.prototype.push.apply(W.statusMobile, W.customStatusList), Array.prototype.push.apply(W.statusMobile, W.statusList), W.statusSelected = W.statusMobile[4], W.supressScrollX = function () {
            var e = f("filter")(W.columns, {
                enabled: !0
            }, !0);
            return !!e && e.length <= 8
        }, t.$watch("vm.searchText", function (e, t) {
            e !== t && (W.selectedMobileRow = {
                identifier: "",
                row: {}
            })
        }), t.$watch("vm.orderTypeSelected", function (e, t) {
            e !== t && W.setOrderTypeFilter(e)
        }, !0), t.$watch("vm.statusSelected", function (e, t) {
            e !== t && W.setStatusFilter(e)
        }, !0), t.$watch(function () {
            return s.mobileProperties.isMobile
        }, function (e, t) {
            W.isMobile = e
        }), t.$watch("vm.selectedStatusFilter", function (e, t) {
            e || (W.selectedStatusFilter = W.clearStatusFilter)
        }), t.$watch("vm.selectedOrderTypeFilter", function (e, t) {
            e || (W.selectedOrderTypeFilter = W.clearOrderTypeFilter)
        }), t.$watch("vm.selectedTabId", function (t, n) {
            switch (t !== e && null !== t || (t = 0), W.selectedTabId = t, t) {
                case 0:
                    W.capitalMarketOrders = W.stockOrders, W.columns = W.stocksColumns, h.subscribeToOrders(h.StockOrders), h.unsubscribeFromOrders(h.FundOrders), h.unsubscribeFromOrders(h.CashOrders);
                    break;
                case 1:
                    W.capitalMarketOrders = W.fundOrders, W.columns = W.foundsColumns, h.subscribeToOrders(h.FundOrders), h.unsubscribeFromOrders(h.StockOrders), h.unsubscribeFromOrders(h.CashOrders);
                    break;
                case 2:
                    break;
                case 3:
                    W.capitalMarketOrders = W.cashOrders, W.columns = W.cashColumns, h.subscribeToOrders(h.CashOrders), h.unsubscribeFromOrders(h.StockOrders), h.unsubscribeFromOrders(h.FundOrders)
            }
        }), t.$watch("vm.filtered", function (t, n) {
            if (t === e || null === t) W.isCancelDisabled = !0;
            else {
                for (var i = !0, o = 0; o < W.filtered.length; o++)
                    if (W.filtered[o].isCancelable) {
                        i = !1;
                        break
                    }
                i ? W.isCancelDisabled = !0 : W.isCancelDisabled = !1
            }
        }, !0), t.$watch(function () {
            return t.$parent.widget.size_y
        }, function () {
            B()
        }), t.$watch(function () {
            return t.$parent.widget.size_x
        }, function () {
            B()
        }), t.$watch(function () {
            return W.isMobile
        }, function (e) {
            1 == e && W.capitalMarketOrders.length > 0 && N(W.capitalMarketOrders[0]), B()
        }), a.$on("mobile-resize-" + t.widget.id, function (e, n) {
            W.scrollViewHeight = n.viewHeight - (t.issueMix ? 275 : 300) + "px"
        }), t.subscribreToNotifications && t.subscribreToNotifications(G, b, V), t.setLoading = function (e) {
            t.isLoading = e
        }, t.layoutDone = function () {
            t.setLoading(!1)
        }, I()
    }

    function n(e) {
        this.selectedStatusFilter = e
    }

    function i(e) {
        this.selectedOrderTypeFilter = e
    }

    function o(e, t) {
        0 === e.id ? this.vm.showConfigureColumns(e.id, this.vm.stocksColumns) : 1 === e.id ? this.vm.showConfigureColumns(e.id, this.vm.foundsColumns) : 3 === e.id && this.vm.showConfigureColumns(e.id, this.vm.cashColumns)
    }

    function r(e) {
        return ['<i class="fa fa-pencil"></i> ' + editColumnsMenuItem]
    }

    function a() {
        return function (e, t) {
            var n;
            switch (t) {
                case "*open":
                    n = e.filter(function (e) {
                        return this.status.indexOf(e.gbmIntProcessStatus) > -1
                    }, {
                        status: [1, 2, 4, 8, 10, 23]
                    });
                    break;
                case "*closed":
                    n = e.filter(function (e) {
                        return this.status.indexOf(e.gbmIntProcessStatus) > -1
                    }, {
                        status: [5, 7, 9, 22]
                    });
                    break;
                case "*all":
                    n = e;
                    break;
                case "*pending":
                    n = e.filter(function (e) {
                        return this.preOrderId === e.preorderId && this.sobId === e.sobId
                    }, {
                        preOrderId: 0,
                        sobId: 0
                    });
                    break;
                case "*predispatcher":
                    n = e.filter(function (e) {
                        return this.preOrderId !== e.preorderId && this.sobId === e.sobId
                    }, {
                        preOrderId: 0,
                        sobId: 0
                    });
                    break;
                default:
                    n = e.filter(function (e) {
                        return this.status instanceof Array ? this.status.indexOf(e.gbmIntProcessStatus) > -1 : this.status === e.gbmIntProcessStatus
                    }, {
                        status: t
                    })
            }
            return n
        }
    }

    function s() {
        return function (e, t) {
            var n;
            switch (t) {
                case "*buy":
                    n = [1, 16, 44, 46, 60, 62];
                    break;
                case "*sell":
                    n = [8, 13, 18, 45, 47, 61, 63];
                    break;
                case "*all":
                    n = []
            }
            var i = [];
            return i = 0 === n.length ? e : e.filter(function (e) {
                return this.types.indexOf(e.capitalOrderTypeId) > -1
            }, {
                types: n
            })
        }
    }

    function c() {
        return function (e, t) {
            if (!t) return e;
            var n = e.filter(function (e) {
                return this.issuer === e.issueId
            }, {
                issuer: t
            });
            return n
        }
    }
    var l = "hbBlotterCtrl";
    angular.module("app").controller(l, ["$scope", "$rootScope", "common", "notificationTypes", "hbOperationSvc", "hbLoggingSvc", "hbGlobalizationSvc", "$filter", "$modal", "hbOrderSvc", "hbGridsterOptions", "hbBrowserSvc", t]), angular.module("app").filter("filterByOrderType", s), angular.module("app").filter("filterByOrderStatus", a), angular.module("app").filter("filterOrderBySearchedSymbol", c)
}(),
function () {
    "use strict";

    function e(e, n, i, o, r, a, s, c, l, u, d, g, f, p, h, m, v, b, S, y, T) {
        function C(e, t) {
            var n = e.name.substring(0, e.name.indexOf("."));
            switch (s[n]) {
                case s.SELECTED_SYMBOL:
                    R.selectedTabId = R.tabs[0].id;
                    break;
                case s.SELECTED_SYMBOL_FUNDS:
                    R.selectedTabId = R.tabs[1].id;
                    break;
                case s.SELECTED_SYMBOL_CASH:
                    R.selectedTabId = R.tabs[2].id;
                    break;
                case s.SELECTED_BLOTTER_ORDER:
                    R.selectedTabId = R.tabs[0].id;
                    break;
                case s.SELECTED_LEVEL_2_SYMBOL:
                    R.selectedTabId = R.tabs[0].id;
                    break;
                case s.SELECTED_POSITION_CAPITAL:
                    R.selectedTabId = R.tabs[0].id;
                    break;
                case s.SELECTED_POSITION_FUNDS:
                    R.selectedTabId = R.tabs[1].id;
                    break;
                case s.SELECTED_POSITION_CASH:
                    R.selectedTabId = R.tabs[2].id;
                    break;
                default:
                    l.logging(u.getResource("Operation_JS_MSG_UnhandledNotification", !0), l.loggingTypes.EXCEPTION)
            }
        }

        function w(e, t, n) {
            "monitor" === n.source ? i.$broadcast("monitordrop", {
                symbol: n.payload.symbol,
                price: n.payload.hechos.body.Last
            }) : "level2" === n.source && i.$broadcast("level2drop", {
                symbol: n.payload.symbol,
                price: n.payload.price,
                amount: n.payload.totalVolume
            })
        }

        function I() {
            R.dndHelper.accepts(["monitor", "level2"])
        }

        function _() {
            R.dndHelper.out()
        }

        function P(e, t) {
            switch (e.id) {
                case 0:
                    0 === t && k();
                    break;
                case 1:
                    0 === t && L()
            }
        }

        function M(e) {
            switch (e.id) {
                case 0:
                    return ['<i class="fa fa-edit"></i>' + u.getResource("Operation_JS_MSG_EditTrade", !0)];
                case 1:
                    return ['<i class="fa fa-edit"></i>' + u.getResource("Operation_JS_MSG_EditTrade", !0)]
            }
        }

        function O() {
            for (var e = 0, t = V.length; e < t; e++) V[e]()
        }

        function E(e) {
            V.push(e)
        }

        function D() {
            var e = [A(), u.load("Operation")];
            r.activateController(e, t).then(function () {
                if ("undefined" != typeof i.loadConfiguration) {
                    var e = i.loadConfiguration();
                    r.$q.all([e]).then(function () {
                        var e = ["Operation_JS_MSG_Capitals", "Operation_JS_MSG_Funds", "Operation_JS_MSG_Cash"];
                        $(R.tabs, e, "name"), r.$broadcast("dashboard.widget_initialized", "Operation")
                    })
                }
                x()
            })
        }

        function A() {
            var e = [{
                name: "selectedTabId",
                value: "selectedTabId"
            }];
            "undefined" != typeof i.prepareConfiguration && i.prepareConfiguration(e)
        }

        function k() {
            a.open({
                scope: i,
                templateUrl: "loadPartial/Operation/ConfigureCapitalTab",
                windowClass: "configure-capitaltab",
                controller: "hbConfigureCapitalTabCtrl",
                resolve: {
                    parentCtrl: function () {
                        return i.propertyScopes.operationcapital
                    }
                }
            })
        }

        function L() {
            a.open({
                scope: i,
                templateUrl: "loadPartial/Operation/ConfigureFundTab",
                windowClass: "configure-fundtab",
                controller: "hbConfigureFundTabCtrl",
                resolve: {
                    parentCtrl: function () {
                        return i.propertyScopes.operationfund
                    }
                }
            })
        }

        function x() {
            var e = i.$parent.widget.size_y * y.colWidth;
            e && (R.scrollViewHeight = e - 100 + "px")
        }

        function $(e, t, n) {
            for (var i = 0, o = t.length; i < o; i++) e[i][n] = u.getResource(t[i], !0)
        }

        function B(e) {
            ++U === F && N && N("Operation")
        }
        var R = i;
        R.scrollViewHeight = 0, R.scrollSpeed = "firefox" === T() ? 20 : 1, R.dropCallback = w, R.dndHelper = g, R.dragOverCallback = I, R.dragOutCallback = _, R.tabs = [{
            id: 0
        }, {
            id: 1
        }, {
            id: 2
        }], R.selectedTabId = R.tabs[0].id, R.displayEditTrade = k, R.displayEditFund = L, R.genTabMenuItemSelected = P, R.genTabMenuItemsBuilder = M;
        var N, U = 0,
            F = 3;
        i.notifyWidgetReady && (N = i.notifyWidgetReady, i.notifyWidgetReady = B), R.isMobile = r.mobileProperties.isMobile, i.$watch(function () {
            return i.$parent.widget.size_y
        }, function () {
            x()
        }), i.$watch(function () {
            return r.mobileProperties.isMobile
        }, function (e, t) {
            R.isMobile = e
        });
        var G = [{
            sub: s.SELECTED_SYMBOL,
            unsub: void 0
        }, {
            sub: s.SELECTED_SYMBOL_FUNDS,
            unsub: void 0
        }, {
            sub: s.SELECTED_SYMBOL_CASH,
            unsub: void 0
        }, {
            sub: s.SELECTED_BLOTTER_ORDER,
            unsub: void 0
        }, {
            sub: s.SELECTED_LEVEL_2_SYMBOL,
            unsub: void 0
        }, {
            sub: s.SELECTED_POSITION_CAPITAL,
            unsub: void 0
        }, {
            sub: s.SELECTED_POSITION_FUNDS,
            unsub: void 0
        }, {
            sub: s.SELECTED_POSITION_CASH,
            unsub: void 0
        }];
        i.subscribreToNotifications && i.subscribreToNotifications(G, C);
        var V = [];
        i.setRefreshFunction(O), i.setRefreshFunction = E, D()
    }
    var t = "hbOperationCtrl";
    angular.module("app").controller(t, ["$interval", "$filter", "$scope", "$rootScope", "common", "$modal", "notificationTypes", "hbOperationSvc", "hbLoggingSvc", "hbGlobalizationSvc", "hbMarketSvc", "hbDragNDropHelperSvc", "hbSolaceSvc", "hbPortfolioSvc", "hbContractManagementSvc", "hbPositionSvc", "hbSecuritySvc", "hbOrderSvc", "hbCashSvc", "hbGridsterOptions", "hbBrowserSvc", e])
}(),
function () {
    "use strict";

    function e(e, t, n, i) {
        var o = this;
        e.vm = o, o.amountToConfigure = i.getPropertyValue("vm.amount"), o.tradeModeToConfigure = i.getPropertyValue("vm.tradeMode"), o.customButton1ToConfigure = i.getPropertyValue("vm.customButton1"), o.customButton2ToConfigure = i.getPropertyValue("vm.customButton2"), o.customButton3ToConfigure = i.getPropertyValue("vm.customButton3"), e.$watch("vm.tradeModeToConfigure", function (e, t) {
            0 == e ? (o.selectedClassNormal = "configure-container-tradeMode-selected", o.selectedClassAlterno = "configure-container-tradeMode") : (o.selectedClassNormal = "configure-container-tradeMode", o.selectedClassAlterno = "configure-container-tradeMode-selected")
        }), e.setButtonValue = function (e, t) {
            switch (e) {
                case "vm.customButton1ToConfigure":
                    o.customButton1ToConfigure = t;
                    break;
                case "vm.customButton2ToConfigure":
                    o.customButton2ToConfigure = t;
                    break;
                case "vm.customButton3ToConfigure":
                    o.customButton3ToConfigure = t
            }
        }, e.dismiss = function () {
            n.close()
        }, e.accept = function () {
            i.setPropertyValue("vm.amount", o.amountToConfigure), i.setPropertyValue("vm.tradeMode", o.tradeModeToConfigure), i.setPropertyValue("vm.customButton1", o.customButton1ToConfigure), i.setPropertyValue("vm.customButton2", o.customButton2ToConfigure), i.setPropertyValue("vm.customButton3", o.customButton3ToConfigure), n.close()
        }
    }
    var t = "hbConfigureCapitalTabCtrl";
    angular.module("app").controller(t, ["$scope", "$rootScope", "$modalInstance", "parentCtrl", e])
}(),
function () {
    "use strict";

    function e(e, t, n, i) {
        var o = this;
        e.vm = o, o.customButton1ToConfigure = i.getPropertyValue("vm.customButtonFund1"), o.customButton2ToConfigure = i.getPropertyValue("vm.customButtonFund2"), o.customButton3ToConfigure = i.getPropertyValue("vm.customButtonFund3"), e.setButtonValue = function (e, t) {
            switch (e) {
                case "vm.customButton1ToConfigure":
                    o.customButton1ToConfigure = t;
                    break;
                case "vm.customButton2ToConfigure":
                    o.customButton2ToConfigure = t;
                    break;
                case "vm.customButton3ToConfigure":
                    o.customButton3ToConfigure = t
            }
        }, e.dismiss = function () {
            n.close()
        }, e.accept = function () {
            i.setPropertyValue("vm.customButtonFund1", o.customButton1ToConfigure), i.setPropertyValue("vm.customButtonFund2", o.customButton2ToConfigure), i.setPropertyValue("vm.customButtonFund3", o.customButton3ToConfigure), n.close()
        }
    }
    var t = "hbConfigureFundTabCtrl";
    angular.module("app").controller(t, ["$scope", "$rootScope", "$modalInstance", "parentCtrl", e])
}(),
function () {
    "use strict";

    function e(e, t, n, i, o, r, a) {
        var s = this;
        e.vm = s, s.dataPackage = r, s.token = "", s.shouldAskForLogin = !n.getUser().isReadAndWrite, s.height = 320, s.isMobile = !1, s.userCanShortSelling = a.defaultContractDetail.tradeShortSell, e.$watch(function () {
            return t.mobileProperties.isMobile
        }, function (e, t) {
            s.isMobile = e
        }), e.$watch("vm.token", function () {
            var e = /^\d*\.?\d*$/;
            e.test(s.token) || (s.token = "")
        }), e.dismiss = function () {
            i.close()
        }, e.accept = function () {
            o.registerCapitalOrder(s.dataPackage.dataToBeProcessed, i, s.token, s.dataPackage.operationType)
        }, e.shortselling = function () {
            s.dataPackage.dataToBeProcessed.orders[0].capitalOrderTypeId = 13, o.registerCapitalOrder(s.dataPackage.dataToBeProcessed, i, s.token, s.dataPackage.operationType)
        }
    }
    var t = "hbConfirmationTransactionCtrl";
    angular.module("app").controller(t, ["$scope", "common", "$rootScope", "$modalInstance", "parentCtrl", "dataPackage", "hbContractManagementSvc", e])
}(),
function () {
    "use strict";

    function e(e, t, n, i, o, r) {
        function a() {
            u.deposits = n("filter")(r, {
                treasuryOrderTypeId: 2
            })
        }

        function s() {
            u.drawals = n("filter")(r, {
                treasuryOrderTypeId: 1
            })
        }

        function c(e, t) {
            t ? (e === u.sortingPropDep ? u.sortReverseDep = !u.sortReverseDep : (u.sortingPropDep = e, u.sortReverseDep = !0), u.pagingDep.currentPage = 1) : (e === u.sortingPropDra ? u.sortReverseDra = !u.sortReverseDra : (u.sortingPropDra = e, u.sortReverseDra = !0), u.pagingDra.currentPage = 1)
        }

        function l(e) {
            return e ? u.sortReverseDep ? "fa fa-caret-down" : "fa fa-caret-up" : u.sortReverseDra ? "fa fa-caret-down" : "fa fa-caret-up"
        }
        var u = this;
        e.vm = u, u.deposits = [], u.drawals = [], u.pageSize = 10, u.sortingPropDep = "processDate", u.sortReverseDep = !1, u.sortingPropDra = "processDate", u.sortReverseDra = !1, u.setOrder = c, u.getCaretClass = l, u.pagingDep = {
            currentPage: 1,
            maxPagesToShow: 10,
            pageSize: u.pageSize
        }, u.pagingDra = {
            currentPage: 1,
            maxPagesToShow: 10,
            pageSize: u.pageSize
        }, a(), s(), e.dismiss = function () {
            i.close()
        }
    }
    var t = "hbDepositsWithDrawalsCtrl";
    angular.module("app").controller(t, ["$scope", "$rootScope", "$filter", "$modalInstance", "parentCtrl", "depositsWithDrawalsData", e])
}(),
function () {
    "use strict";

    function e(e, t, n, i) {
        var o = this;
        e.vm = o, e.dismiss = function () {
            i.close()
        }
    }
    var t = "hbTokenNeededCtrl";
    angular.module("app").controller(t, ["$scope", "common", "$rootScope", "$modalInstance", e])
}(),
function () {
    "use strict";

    function e(e, n, i, o, r, a, s, c, l, u) {
        function d() {
            e.setRefreshFunction(S, I);
            var n = [g()];
            o.activateController(n, t).then(function () {
                void 0 !== e.loadConfiguration && e.loadConfiguration(I), f(), e.notifyWidgetReady("Trades")
            })
        }

        function g() {
            var t = [{
                name: "issue",
                value: "vm.issue"
            }];
            void 0 !== e.prepareConfiguration && e.prepareConfiguration(t, I, e)
        }

        function f() {
            m(), P.trades.length = 0, P.filteredTrades.length = 0;
            var e = b(P.issue);
            e && a.mdMarketData(e).then(function (e) {
                e.data && e.data.length > 0 && P.issue === e.data[0].stockSeries && (P.trades.length = 0, P.trades.push.apply(P.trades, e.data), P.filteredTrades.length = 0, P.filteredTrades.push.apply(P.filteredTrades, P.trades.slice(0, O)))
            }, function (e) {
                c.logging(e.data, c.loggingTypes.EXCEPTION)
            })["finally"](function () {
                h()
            })
        }

        function p(e, t) {
            var n = e.name.substring(0, e.name.indexOf("."));
            switch (r[n]) {
                case r.SELECTED_SYMBOL:
                case r.SEARCHED_SYMBOL:
                case r.SELECTED_POSITION_CAPITAL:
                    P.issue = t.symbol, P.mdMarketData();
                    break;
                default:
                    c.logging("unhandled notification type received", c.loggingTypes.EXCEPTION)
            }
        }

        function h() {
            m();
            var e = _.max(P.trades, function (e) {
                    return e.sequence
                }),
                t = e.sequence ? e.sequence : 1;
            C = s.hechosRxSubject.filter(function (e) {
                return e.StockSeries === P.issue
            }).subscribe(function (e) {
                t++;
                var n = {
                    buyer: e.Buyer,
                    seller: e.Seller,
                    operationVolume: e.operationVolume,
                    time: (new Date).getIsoDateFromTime(e.Time),
                    last: e.lastWithOutLot,
                    sequence: t
                };
                this.trades.unshift(n)
            }.bind(P))
        }

        function m() {
            C && C.dispose()
        }

        function v() {
            O += 100, P.filteredTrades.length = 0, P.filteredTrades.push.apply(P.filteredTrades, P.trades.slice(0, O))
        }

        function b(e) {
            return String(e).replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/'/g, "&apos;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
        }

        function S() {
            f()
        }

        function y() {
            var t = e.$parent.widget.size_x * u.colWidth;
            P.scrollViewWidth = t - 25 + "px"
        }

        function T(e) {
            "y" === e.bar && 0 === e.bottom && (M = e.bottom, e.bottom < 40 && v())
        }
        var C, w = [{
                sub: r.SELECTED_SYMBOL,
                unsub: void 0
            }, {
                sub: r.SEARCHED_SYMBOL,
                unsub: void 0
            }, {
                sub: r.SELECTED_POSITION_CAPITAL,
                unsub: void 0
            }],
            I = "trade",
            P = this,
            M = 100,
            O = 100;
        P.issue = "", P.countScroll = 0, P.scrollTrades = [], P.trades = [], P.filteredTrades = [], P.itemsDisplayed = 10, P.loadMore = v, P.mdMarketData = f, P.scrollCallback = T, P.isMobile = o.mobileProperties.isMobile, P.showSearch = !0, P.hideSearch = function () {
            P.showSearch = !1
        }, P.scrollSpeed = "firefox" === l() ? 20 : 1, P.size = $("#" + e.widget.id).height() - 80, P.scrollViewWidth = 0, i.$on("mobile-resize-" + e.widget.id, function (e, t) {
            P.size = t.viewHeight - 170 + "px"
        }), e.$watch(function () {
            return o.mobileProperties.isMobile
        }, function (e, t) {
            P.isMobile = e
        }), e.$watch(function () {
            return $("#" + e.widget.id).height()
        }, function (e, t) {
            e === t || P.isMobile || (P.size = e - 70)
        }), e.$watchCollection("vm.trades", function (e, t) {
            e.length != t.length && (P.filteredTrades.length = 0, P.filteredTrades.push.apply(P.filteredTrades, e.slice(0, O)))
        }), e.subscribreToNotifications && e.subscribreToNotifications(w, p, I), e.$on("$destroy", function () {
            m()
        }), e.$on("mix_" + e.widget.id, function (e, t) {
            P.issue = t
        }), e.$watch(function () {
            return e.$parent.widget.size_x
        }, function (e, t) {
            y()
        }), d()
    }
    var t = "hbTradesCtrl";
    angular.module("app").controller(t, ["$scope", "$filter", "$rootScope", "common", "notificationTypes", "hbMarketSvc", "hbSolaceSvc", "hbLoggingSvc", "hbBrowserSvc", "hbGridsterOptions", e])
}(),
function () {
    "use strict";

    function e(e, n, i, o, r, a, s, c) {
        function l(e, t, n) {
            M.dndHelper.ghostElement && (t.position = {
                left: e.clientX,
                top: e.pageY
            })
        }

        function u(e, t, n) {
            for (var i = 0, o = 0; o < n.sequence; o++) i += "sell" === M.priceType ? M.L2s[o].sellVolume : M.L2s[o].buyVolume;
            var r = {
                symbol: M.issueL2,
                totalVolume: i,
                price: n.buyPrice
            };
            "sell" === M.priceType && (r.price = n.sellPrice), M.dndHelper.setMessage("level2", r)
        }

        function d(e) {
            var t = '<div class="drag-symbol">\n<div class="drag-symbol-container">\n   <div class="drag-icon"></div>\n   <div class="drag-text">' + M.issueL2 + "</div></div>\n</div>\n",
                n = $(t);
            return M.dndHelper.ghostElement = n, n
        }

        function g(e, t, n) {
            n && "monitor" === n.source && (M.issueL2 = n.payload.symbol)
        }

        function f() {
            M.dndHelper.accepts(["monitor"])
        }

        function p() {
            M.dndHelper.out()
        }

        function h() {
            e.setRefreshFunction(C, P);
            var n = [m()];
            i.activateController(n, t).then(function () {
                void 0 !== e.loadConfiguration && e.loadConfiguration(P), b(), e.notifyWidgetReady("Level 2")
            })
        }

        function m() {
            var t = [{
                name: "issueL2",
                value: "vm.issueL2"
            }];
            void 0 !== e.prepareConfiguration && e.prepareConfiguration(t, P, e)
        }

        function v(e, t) {
            var n = e.name.substring(0, e.name.indexOf("."));
            switch (o[n]) {
                case o.SELECTED_SYMBOL:
                case o.SEARCHED_SYMBOL:
                    M.issueL2 = t.symbol, b();
                    break;
                case o.SELECTED_POSITION_CAPITAL:
                    M.issueL2 = t.symbol, b();
                    break;
                default:
                    s.logging("unhandled notification type received", s.loggingTypes.EXCEPTION)
            }
        }

        function b() {
            "" !== M.issueL2 && (y(), r.getL2(M.issueL2).then(function (e) {
                angular.extend(M.L2s, e.data), S()
            }, function (e) {
                M.error = !0, e && e.status && 401 === e.status && s.logging("level2, unauthorized notification received", s.loggingTypes.WARNING)
            }))
        }

        function S() {
            var t = {
                symbol: M.issueL2,
                topic: "posturas"
            };
            M.solaceSymbol.posturas = a.getSymbol(t), M.solaceSymbol.posturas && (w && w(), w = e.$watch("vm.solaceSymbol.posturas.body", function (e, t) {
                if (e && e.length > 4)
                    for (var n = 0; n < M.L2s.length; n++) M.L2s[n].buyNumOrders = e[n].BuyOrdersNum, M.L2s[n].buyPrice = e[n].BuyPrice, M.L2s[n].buyVolume = e[n].BuyVolume, M.L2s[n].sellNumOrders = e[n].SellOrdersNum, M.L2s[n].sellPrice = e[n].SellPrice, M.L2s[n].sellVolume = e[n].SellVolume
            }, !0)), t.topic = "hechos", M.solaceSymbol.hechos = a.getSymbol(t), M.solaceSymbol.hechos && (I && I(), I = e.$watch("vm.solaceSymbol.hechos.body", function (e, t) {
                e && (M.lastPrice = e.Last, M.averageChange = e.changeAvg)
            }, !0))
        }

        function y() {
            M.solaceSymbol.posturas && (M.solaceSymbol.posturas = null, w && w()), M.solaceSymbol.hechos && (M.solaceSymbol.hechos = null, I && I())
        }

        function T(t, n, i, r) {
            M.priceType = n, M.index = i;
            for (var a = 0, s = 0; s < i + 1; s++) a += "sell" === n ? M.L2s[s].sellVolume : M.L2s[s].buyVolume;
            var c = {
                price: t.buyPrice,
                symbol: M.issueL2,
                totalVolume: a,
                colType: r
            };
            "sell" === n && (c.price = t.sellPrice), e.notify(o.SELECTED_LEVEL_2_ROWDATA, c)
        }

        function C() {}
        var w, I, _ = [{
                sub: o.SELECTED_SYMBOL,
                unsub: void 0
            }, {
                sub: o.SEARCHED_SYMBOL,
                unsub: void 0
            }, {
                sub: o.SELECTED_POSITION_CAPITAL,
                unsub: void 0
            }],
            P = "level2",
            M = this;
        M.solaceSymbol = {
            hechos: null,
            posturas: null
        }, M.L2s = [], M.issueL2 = "", M.lastPrice = 0, M.averageChange = 0, M.selectIssue = T, M.dndHelper = c, M.dragCallback = l, M.dropCallback = g, M.dragOverCallback = f, M.dragOutCallback = p, M.dragTableRow = d, M.dragStartCallback = u, M.priceType, M.index = 0, M.isMobile = i.mobileProperties.isMobile, M.showSearch = !0, M.hideSearch = function () {
            M.showSearch = !1
        }, e.$on("mix_" + e.widget.id, function (e, t) {
            M.issueL2 = t
        }), e.subscribreToNotifications && e.subscribreToNotifications(_, v, P), e.$watch(function () {
            return i.mobileProperties.isMobile
        }, function (e, t) {
            M.isMobile = e
        }), h()
    }
    var t = "hbLeveltwoCtrl";
    angular.module("app").controller(t, ["$scope", "$rootScope", "common", "notificationTypes", "hbMarketSvc", "hbSolaceSvc", "hbLoggingSvc", "hbDragNDropHelperSvc", e])
}(),
function () {
    "use strict";

    function e(e, n, i, o, r, a, s, c, l, u, d, g, f, p, h) {
        function m() {
            var e = [v(), C(), u.load("IssueIntraday"), S()];
            o.activateController(e, t).then(function () {
                "undefined" != typeof n.loadConfiguration && n.loadConfiguration(), G.issueIntraday ? w()["finally"](function () {
                    U || (U = !0, o.$broadcast("dashboard.widget_initialized", "Issue Intraday"))
                }) : (U = !0, o.$broadcast("dashboard.widget_initialized", "Issue Intraday")), k = new Date(x.startTime.getTime()), L = new Date(x.endTime.getTime()), k.setMinutes(30), n.setRefreshFunction(w)
            })
        }

        function v() {
            var e = [{
                name: "issueIntraday",
                value: "vm.issueIntraday"
            }, {
                name: "isOnLine",
                value: "vm.isOnLine"
            }];
            "undefined" != typeof n.prepareConfiguration && n.prepareConfiguration(e)
        }

        function b() {
            w(), E(G.issueIntraday)
        }

        function S() {
            return g.getUserConfiguration().then(function (e) {
                V = e, T(V.themeName.toLowerCase())
            })
        }

        function y(e, t) {
            var n = e.name.substring(0, e.name.indexOf("."));
            switch (r[n]) {
                case r.SELECTED_SYMBOL:
                case r.SEARCHED_SYMBOL:
                case r.SELECTED_POSITION_CAPITAL:
                    G.issueIntraday = t.symbol, w();
                    break;
                default:
                    c.logging("unhandled notification type received", c.loggingTypes.EXCEPTION)
            }
        }

        function T(e) {
            var t, n = G.highchartsNgConfig,
                i = "rgb(113, 253, 252)",
                o = "rgb(39,78,135)";
            switch (e) {
                case "light":
                    t = "#54534A";
                    break;
                case "dark":
                default:
                    t = "#ffffff"
            }
            n.title.style.color = t, n.subtitle.style.color = t, n.xAxis.labels.style.color = t, n.title.style.color = t, n.yAxis.title.style.color = t, n.yAxis.lineColor = "light" === e ? "rgba(0,0,0,1)" : "rgba(0,0,0,0)", n.yAxis.labels.style.color = t, n.plotOptions.area.fillColor.stops = [[0, i], [1, o]], n.plotOptions.area.lineColor = t
        }

        function C() {
            return f.getCapitalMarketOperationTime().then(function (e) {
                x = e
            })
        }

        function w(e) {
            return O(), _(), G.highchartsNgConfig.loading = !0, G.highchartsNgConfig.title.text = G.issueIntraday + " " + u.getResource("IssueIntraday_JS_MSG_Intraday", !0), G.highchartsNgConfig.subtitle.text = G.isOnLine ? u.getResource("IssueIntraday_JS_MSG_ValuesOnLine", !0) : u.getResource("IssueIntraday_JS_MSG_Delay", !0), G.highchartsNgConfig.yAxis.title.text = u.getResource("IssueIntraday_JS_MSG_Price", !0), G.highchartsNgConfig.series[0].name = G.issueIntraday, a.getIssueIntraday(G.issueIntraday, G.isOnLine, e).then(function (e) {
                if (e && angular.isArray(e.data)) {
                    var t = e.data.filter(function (e) {
                            var t = new Date(e.date);
                            return t >= k && t <= L
                        }),
                        n = t.map(function (e) {
                            var t = new Date(e.date);
                            return [t.getTime(), e.price]
                        });
                    G.highchartsNgConfig.series[0].data.length = 0, G.highchartsNgConfig.series[0].data.push.apply(G.highchartsNgConfig.series[0].data, n)
                }
            }, function (e) {
                G.error = !0, c.logging(e.data, c.loggingTypes.EXCEPTION)
            })["finally"](function () {
                M(), I(), G.highchartsNgConfig.loading = !1
            })
        }

        function I() {
            D && D();
            var e = {
                symbol: G.issueIntraday,
                topic: "hechos"
            };
            G.solaceSymbol = s.getSymbol(e), G.solaceSymbol && (F = void 0, D = n.$watch("vm.solaceSymbol", function (e, t) {
                var n = G.solaceSymbol.body;
                if ("P" !== n.Odd_lot) {
                    F = n.Last;
                    var i = p.centralHour.indexOf("T"),
                        o = p.centralHour.indexOf("-", i),
                        r = p.centralHour.substring(0, i + 1) + G.solaceSymbol.body.Time + p.centralHour.substring(o),
                        a = new Date(r).getTime(),
                        s = [a, n.Last];
                    if (!isNaN(a))
                        if (G.highchartsNgConfig.series[0].data.length > 0) {
                            var c = G.highchartsNgConfig.series[0].data[G.highchartsNgConfig.series[0].data.length - 1];
                            a > c[0] && G.highchartsNgConfig.series[0].data.push(s)
                        } else G.highchartsNgConfig.series[0].data.push(s)
                }
            }, !0))
        }

        function _() {
            G.solaceSymbol && D && D(), O()
        }

        function P() {
            var e = n.$parent.widget.size_y * d.colWidth,
                t = n.$parent.widget.size_x * d.colWidth;
            if (e)
                if (G.isMobile) {
                    var i = $("#" + n.widget.id).width();
                    G.chartWidth = G.highchartsNgConfig.options.chart.width = i + 35, G.chartHeight = G.highchartsNgConfig.options.chart.height = e
                } else G.chartWidth = G.highchartsNgConfig.options.chart.width = t - 40, G.chartHeight = G.highchartsNgConfig.options.chart.height = e - 90
        }

        function M() {
            O(), A = setInterval(function () {
                w(!0)
            }, N, 0, !1)
        }

        function O() {
            A && clearInterval(A)
        }

        function E(e) {
            var t = {
                emitter: n.widget.name,
                symbol: e
            };
            n.notify(r.SEARCHED_SYMBOL, t)
        }
        var D, A, k, L, x, B = [{
                sub: r.SELECTED_SYMBOL,
                unsub: void 0
            }, {
                sub: r.SEARCHED_SYMBOL,
                unsub: void 0
            }, {
                sub: r.SELECTED_POSITION_CAPITAL,
                unsub: void 0
            }],
            R = d.colWidth - d.margins[0],
            N = h.min5,
            U = !1,
            F = void 0,
            G = this;
        G.getIssueIntraday = w, G.isMobile = o.mobileProperties.isMobile, G.notifyIssue = b, G.issueIntraday = "", G.isOnLine = !0, n.subscribreToNotifications && n.subscribreToNotifications(B, y), i.$on("mobile-resize-" + n.widget.id, function (e, t) {
            G.scrollViewHeight = t.viewHeight - 50 + "px", G.highchartsNgConfig.options.chart.height = t.viewHeight - 100
        }), n.$watch(function () {
            return n.$parent.widget.size_y
        }, function (e, t) {
            P()
        }), n.$watch(function () {
            return n.$parent.widget.size_x
        }, function (e, t) {
            P()
        }), n.$watch(function () {
            return o.mobileProperties.isMobile
        }, function (e, t) {
            G.isMobile = e
        }), n.$on("$destroy", function () {
            O()
        });
        var V;
        n.$watch(function () {
            return V
        }, function (e, t) {
            if (e && e.themeName) {
                var n = e.themeName.toLowerCase();
                T("light" === n ? "light" : "dark")
            }
        }, !0), m();
        G.highchartsNgConfig = {
            options: {
                chart: {
                    type: "area",
                    zoomType: "x",
                    spacingRight: 20,
                    width: parseInt(n.widget.size_x) * R,
                    height: n.widget.size_y * R - 70,
                    backgroundColor: "rgba(0,0,0,0)"
                },
                tooltip: {
                    shared: !0
                }
            },
            xAxis: {
                minTickInterval: 18e5,
                type: "datetime",
                labels: {
                    style: {
                        fontFamily: "Arial",
                        color: "#ffffff"
                    }
                },
                title: {
                    style: {
                        fontFamily: "Arial",
                        color: "#ffffff"
                    }
                }
            },
            yAxis: {
                title: {
                    text: u.getResource("IssueIntraday_JS_MSG_Price", !0),
                    style: {
                        fontFamily: "Arial",
                        color: "#ffffff"
                    }
                },
                gridLineWidth: 0,
                minorGridLineWidth: 0,
                lineColor: "rgba(0,0,0,0)",
                labels: {
                    style: {
                        fontFamily: "Arial",
                        color: "#ffffff"
                    }
                }
            },
            plotOptions: {
                series: {
                    animation: {
                        duration: 2e3
                    }
                },
                area: {
                    fillColor: {
                        linearGradient: {
                            x1: 0,
                            y1: 0,
                            x2: 0,
                            y2: 1
                        },
                        stops: [[0, "rgb(113, 253, 252)"], [1, "rgb(39,78,135)"]]
                    },
                    lineColor: "#ffffff",
                    marker: {
                        enabled: !1
                    },
                    shadow: !1,
                    states: {
                        hover: {
                            lineWidth: 1
                        }
                    },
                    threshold: null
                }
            },
            series: [{
                data: []
            }],
            title: {
                text: "",
                style: {
                    fontFamily: "Arial",
                    color: "#ffffff"
                }
            },
            subtitle: {
                text: "",
                style: {
                    fontFamily: "Arial",
                    color: "#ffffff"
                }
            },
            loading: !1,
            credits: {
                enabled: !1
            },
            useHighStocks: !1
        }
    }
    var t = "hbIssueintradayCtrl";
    angular.module("app").controller(t, ["$interval", "$scope", "$rootScope", "common", "notificationTypes", "hbMarketSvc", "hbSolaceSvc", "hbLoggingSvc", "hbSecuritySvc", "hbGlobalizationSvc", "hbGridsterOptions", "hbUserAppConfigSvc", "hbAppManagementSvc", "hbUtilitiesSvc", "timeoutConfig", e])
}(),
function () {
    "use strict";

    function e(e, n, i, o, r, a, s, c, l) {
        function u() {
            e.setRefreshFunction(v, T);
            var n = [d()];
            o.activateController(n, t).then(function () {
                void 0 !== e.loadConfiguration && e.loadConfiguration(T), p(), e.notifyWidgetReady("Participation")
            })
        }

        function d() {
            var t = [{
                name: "issuePart",
                value: "vm.issuePart"
            }, {
                name: "isOnLine",
                value: "vm.isOnLine"
            }, {
                name: "sortingProp",
                value: "vm.sortingProp"
            }, {
                name: "sortReverse",
                value: "vm.sortReverse"
            }];
            void 0 !== e.prepareConfiguration && e.prepareConfiguration(t, T, e)
        }

        function g() {
            I += 100, C.filteredParts.length = 0, C.filteredParts.push.apply(C.filteredParts, C.Parts.slice(0, I))
        }

        function f(e, t) {
            var n = e.name.substring(0, e.name.indexOf("."));
            switch (r[n]) {
                case r.SELECTED_SYMBOL:
                case r.SEARCHED_SYMBOL:
                case r.SELECTED_POSITION_CAPITAL:
                    C.issuePart = t.symbol, p();
                    break;
                default:
                    s.logging("unhandled notification type received", s.loggingTypes.EXCEPTION)
            }
        }

        function p() {
            C.issuePart && "" !== C.issuePart && a.getParticipation(C.issuePart, C.isOnLine).then(function (e) {
                C.Parts.length = 0, C.Parts.push.apply(C.Parts, e.data), C.filteredParts.length = 0, C.filteredParts.push.apply(C.filteredParts, C.Parts.slice(0, I))
            }, function (e) {
                C.error = !0, s.logging(e.data, s.loggingTypes.EXCEPTION)
            })
        }

        function h(e) {
            e === C.sortingProp ? C.sortReverse = !C.sortReverse : (C.sortingProp = e, C.sortReverse = !1);
            var t = n("orderBy");
            C.Parts = t(C.Parts, C.sortingProp, C.sortReverse), angular.copy(C.Parts.slice(0, I), C.filteredParts)
        }

        function m() {
            return C.sortReverse ? "icon-caret-up" : "icon-caret-down"
        }

        function v() {
            p()
        }

        function b() {
            var t = e.$parent.widget.size_x * l.colWidth;
            C.scrollViewWidth = t - 25 + "px"
        }

        function S(e) {
            "y" === e.bar && (w = e.bottom, e.bottom < 40 && g())
        }
        var y = [{
                sub: r.SELECTED_SYMBOL,
                unsub: void 0
            }, {
                sub: r.SEARCHED_SYMBOL,
                unsub: void 0
            }, {
                sub: r.SELECTED_POSITION_CAPITAL,
                unsub: void 0
            }],
            T = "participation",
            C = this,
            w = 100,
            I = 20;
        C.contract = "", C.Parts = [], C.filteredParts = [], C.GetParticipation = p, C.loadMoreParticipation = g, C.isOnLine = !1, C.itemsDisplayed = 30, C.sortingProp = "casaBolsa", C.sortReverse = !0, C.setOrder = h, C.getCaretClass = m, C.issuePart = "", C.scrollCallback = S, C.isMobile = o.mobileProperties.isMobile, C.showSearch = !0, C.hideSearch = function () {
            C.showSearch = !1
        }, C.scrollSpeed = "firefox" === c() ? 20 : 1, C.size = $("#" + e.widget.id).height() - 80, C.scrollViewWidth = 0, i.$on("mobile-resize-" + e.widget.id, function (e, t) {
            C.size = t.viewHeight - 170 + "px"
        }), e.$watch(function () {
            return o.mobileProperties.isMobile
        }, function (e, t) {
            C.isMobile = e
        }), e.$watch(function () {
            return $("#" + e.widget.id).height()
        }, function (e, t) {
            e === t || C.isMobile || (C.size = e - 70)
        }), e.$watch(function () {
            return e.$parent.widget.size_x
        }, function () {
            b()
        }), e.subscribreToNotifications && e.subscribreToNotifications(y, f, T), e.$on("mix_" + e.widget.id, function (e, t) {
            C.issuePart = t
        }), e.$watchCollection("vm.Parts", function (e, t) {
            w < 50 && g()
        }), u()
    }
    var t = "hbParticipationCtrl";
    angular.module("app").filter("sublist", function () {
        return function (e, t, n) {
            return e.slice(n, n + t)
        }
    }), angular.module("app").controller(t, ["$scope", "$filter", "$rootScope", "common", "notificationTypes", "hbMarketSvc", "hbLoggingSvc", "hbBrowserSvc", "hbGridsterOptions", e])
}(),
function () {
    "use strict";

    function e(e, n, i, o, r, a, s, c, l, u, d, g, f) {
        function p(e) {
            var t, n = D.highchartsNgConfig,
                i = "rgb(113, 253, 252)",
                o = "rgb(39,78,135)";
            switch (e) {
                case "light":
                    t = "#54534A";
                    break;
                case "dark":
                    t = "#ffffff"
            }
            n.title.style.color = t, n.subtitle.style.color = t, n.xAxis.labels.style.color = t, n.title.style.color = t, n.yAxis.title.style.color = t, n.yAxis.lineColor = "light" == e ? "rgba(0,0,0,1)" : "rgba(0,0,0,0)", n.yAxis.labels.style.color = t, n.plotOptions.area.fillColor.stops = [[0, i], [1, o]], n.plotOptions.area.lineColor = t
        }

        function h() {
            var n = [m(), S(), u.load("IndexIntraday"), b()];
            i.activateController(n, t).then(function () {
                "undefined" != typeof e.loadConfiguration && e.loadConfiguration(), M = u.getResource("IndexIntraday_JS_MSG_ValuesOnLine", !0), O = u.getResource("IndexIntraday_JS_MSG_Delay", !0), D.highchartsNgConfig.yAxis.title.text = u.getResource("IndexIntraday_JS_MSG_Price", !0), y().then(function (e) {
                    return w(), e
                }), I = new Date(E.startTime.getTime()), _ = new Date(E.endTime.getTime()), I.setMinutes(30), e.setRefreshFunction(w)
            })
        }

        function m() {
            var t = [{
                name: "index.description",
                value: "vm.index.description"
            }, {
                name: "isOnLine",
                value: "vm.isOnLine"
            }];
            "undefined" != typeof e.prepareConfiguration && e.prepareConfiguration(t)
        }

        function v() {
            var t = e.$parent.widget.size_y * d.colWidth,
                n = e.$parent.widget.size_x * d.colWidth;
            if (t)
                if (D.isMobile) {
                    var i = $("#" + e.widget.id).width();
                    D.highchartsNgConfig.options.chart.width = i + 35, D.highchartsNgConfig.options.chart.height = t
                } else D.highchartsNgConfig.options.chart.width = n - 40, D.highchartsNgConfig.options.chart.height = t - 90
        }

        function b() {
            return g.getUserConfiguration().then(function (e) {
                L = e
            })
        }

        function S() {
            return a.getCapitalMarketOperationTime().then(function (e) {
                E = e
            })
        }

        function y() {
            return s.getCommoditiesForInternet(D.commoditiesOnLine).then(function (e) {
                D.indexes = e.data;
                var t = o("filter")(D.indexes, {
                    description: D.index.description
                }, !0);
                t && (D.index = t[0]), k || (k = !0, i.$broadcast("dashboard.widget_initialized", "Index Intraday"))
            }, function (e) {
                D.error = !0, c.logging(e.data, c.loggingTypes.EXCEPTION), k || (k = !0, i.$broadcast("dashboard.widget_initialized", "Index Intraday"))
            })
        }

        function T() {
            P && P(), D.solaceIndex = l.getSolaceIndex(D.index.description);
            var t = f.centralHour.indexOf("T"),
                n = f.centralHour.indexOf("-", t);
            P = e.$watch("vm.solaceIndex.body.date", function (e, i) {
                if (e) {
                    var o = f.centralHour.substring(0, t + 1) + e.substring(e.indexOf(" ") + 1) + f.centralHour.substring(n);
                    if (o = new Date(o), o >= I && o <= _) {
                        var r = D.solaceIndex.body,
                            a = [o.getTime(), r.price],
                            s = D.highchartsNgConfig.series[0].data[D.highchartsNgConfig.series[0].data.length - 1];
                        void 0 === s ? D.highchartsNgConfig.series[0].data.push(a) : s[0] < o.getTime() && a[0] <= E.endTime.getTime() && D.highchartsNgConfig.series[0].data.push(a)
                    }
                }
            })
        }

        function C() {
            D.indexListener && P && P()
        }

        function w() {
            C(), null != D.index && s.getIndexIntraday(D.index.description, D.isOnLine).then(function (e) {
                D.highchartsNgConfig.title.text = D.index.description + " " + u.getResource("IndexIntraday_JS_MSG_Intraday", !0), D.highchartsNgConfig.subtitle.text = D.isOnLine ? M : O, D.highchartsNgConfig.series[0].name = D.index.description;
                var t = e.data.filter(function (e) {
                    var t = new Date(e.date);
                    return t >= I && t <= _
                });
                D.highchartsNgConfig.series[0].data = t.map(function (e) {
                    var t = new Date(e.date);
                    return [t.getTime(), e.price]
                }), T()
            }, function (e) {
                D.error = !0, c.logging(e.data, c.loggingTypes.EXCEPTION)
            })
        }
        var I, _, P, M, O, E, D = this,
            A = d.colWidth - d.margins[0];
        D.indexes = [], D.commoditiesOnLine = !0, D.index = {
            description: "IPC"
        }, D.isOnLine = !1, D.isMobile = i.mobileProperties.isMobile;
        var k = !1;
        n.$on("mobile-resize-" + e.widget.id, function (e, t) {
            D.scrollViewHeight = t.viewHeight - 50 + "px", D.highchartsNgConfig.options.chart.height = t.viewHeight - 100
        }), e.$watch(function () {
            return e.$parent.widget.size_y
        }, function () {
            v()
        }), e.$watch(function () {
            return e.$parent.widget.size_x
        }, function () {
            v()
        }), e.$watch(function () {
            return i.mobileProperties.isMobile
        }, function (e, t) {
            D.isMobile = e
        });
        var L;
        e.$watch(function () {
            return L
        }, function (e, t) {
            if (e && e.themeName) {
                var n = e.themeName.toLowerCase();
                p("light" === n ? "light" : "dark")
            }
        }, !0);
        D.highchartsNgConfig = {
            options: {
                chart: {
                    type: "area",
                    zoomType: "x",
                    spacingRight: 20,
                    width: parseInt(e.widget.size_x) * A,
                    height: e.widget.size_y * A - 70,
                    backgroundColor: "rgba(0,0,0,0)"
                },
                tooltip: {
                    shared: !0
                }
            },
            series: [{
                data: []
            }],
            title: {
                text: "",
                style: {
                    fontFamily: "Arial",
                    color: "#ffffff"
                }
            },
            subtitle: {
                text: "",
                style: {
                    fontFamily: "Arial",
                    color: "#ffffff"
                }
            },
            loading: !1,
            credits: {
                enabled: !1
            },
            xAxis: {
                minTickInterval: 18e5,
                type: "datetime",
                labels: {
                    style: {
                        fontFamily: "Arial",
                        color: "#ffffff"
                    }
                },
                title: {
                    style: {
                        fontFamily: "Arial",
                        color: "#ffffff"
                    }
                }
            },
            yAxis: {
                title: {
                    text: u.getResource("IndexIntraday_JS_MSG_Price", !0),
                    style: {
                        fontFamily: "Arial",
                        color: "#ffffff"
                    }
                },
                gridLineWidth: 0,
                minorGridLineWidth: 0,
                lineColor: "rgba(0,0,0,0)",
                labels: {
                    style: {
                        fontFamily: "Arial",
                        color: "#ffffff"
                    }
                }
            },
            plotOptions: {
                area: {
                    fillColor: {
                        linearGradient: {
                            x1: 0,
                            y1: 0,
                            x2: 0,
                            y2: 1
                        },
                        stops: [[0, "rgb(113, 253, 252)"], [1, "rgb(39,78,135)"]]
                    },
                    lineColor: "#ffffff",
                    marker: {
                        enabled: !1
                    },
                    shadow: !1,
                    states: {
                        hover: {
                            lineWidth: 1
                        }
                    },
                    threshold: null
                }
            },
            useHighStocks: !1
        }, h(), e.$watch("vm.index", function (e, t) {
            e !== t && (D.isOnLine = !0, w())
        })
    }
    var t = "hbIndexintradayCtrl";
    angular.module("app").controller(t, ["$scope", "$rootScope", "common", "$filter", "notificationTypes", "hbAppManagementSvc", "hbMarketSvc", "hbLoggingSvc", "hbSolaceSvc", "hbGlobalizationSvc", "hbGridsterOptions", "hbUserAppConfigSvc", "hbUtilitiesSvc", e])
}(),
function () {
    "use strict";

    function e(e, t, n, i, o, a, s, c, l, u, d, g, f, p) {
        function h() {
            var e = [b()];
            o.activateController(e, r).then(function () {
                "undefined" != typeof n.loadConfiguration && n.loadConfiguration(), c.getResource("Commodities_JS_MSG_Indices").then(function (e) {
                    _.tabs[0].name = e
                }), c.getResource("Commodities_JS_MSG_Commodities").then(function (e) {
                    _.tabs[1].name = e
                }), c.getResource("Commodities_JS_MSG_Currencies").then(function (e) {
                    _.tabs[2].name = e
                }), v(), S(), n.$emit("hb-gridster-item-size-request"), n.setRefreshFunction(T), o.$broadcast("dashboard.widget_initialized", "Commodities")
            })
        }

        function m() {
            var e = n.$parent.widget.size_y * g.colWidth,
                t = n.$parent.widget.size_x * g.colWidth;
            e && (_.scrollViewHeight = e - 100 + "px", _.scrollViewWidth = t - 25 + "px")
        }

        function v() {
            switch (_.selectedTabId) {
                case 0:
                    _.commoditiesType = P;
                    break;
                case 1:
                    _.commoditiesType = M;
                    break;
                case 2:
                    _.commoditiesType = O
            }
            S()
        }

        function b() {
            var e = [{
                name: "selectedTabId",
                value: "vm.selectedTabId"
            }];
            "undefined" != typeof n.prepareConfiguration && n.prepareConfiguration(e), S()
        }

        function S() {
            y()
        }

        function y(e) {
            w(), l.getCommoditiesByType({
                commodityType: 18
            }, e).then(function (e) {
                _.currenciesData = e.data
            })["finally"](function () {
                C()
            })
        }

        function T() {
            y(), d.refresh()
        }

        function C() {
            w(), I = setInterval(function () {
                y(!0)
            }, E)
        }

        function w() {
            I && clearInterval(I)
        }
        var I, _ = this,
            P = [11, 12, 13, 14, 15],
            M = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
            O = [16],
            E = p.seg30;
        _.currenciesData = [], _.lastUpdate = "", _.commodities = d.indicesCommodities, _.commoditiesType = P, _.tabs = [{
            id: 0,
            name: ""
        }, {
            id: 1,
            name: ""
        }, {
            id: 2,
            name: ""
        }], _.selectedTabId = _.tabs[0].id, _.scrollViewHeight = 0, _.scrollViewWidth = 0, _.scrollSpeed = "firefox" === f() ? 20 : 1, _.isMobile = o.mobileProperties.isMobile, i.$on("mobile-resize-" + n.widget.id, function (e, t) {
            _.scrollViewHeight = t.viewHeight - 140 + "px"
        }), n.$watch(function () {
            return o.mobileProperties.isMobile
        }, function (e, t) {
            _.isMobile = e
        }), n.$watch("vm.selectedTabId", function (e, t) {
            e !== t && v()
        }), n.$watch(function () {
            return n.$parent.widget.size_y
        }, function () {
            _.isMobile || m()
        }), n.$watch(function () {
            return n.$parent.widget.size_x
        }, function () {
            _.isMobile || m()
        }), n.$on("$destroy", function () {
            w()
        }), h()
    }

    function t() {
        return function (e, t, n) {
            if (!t || 0 === t.length) return e;
            var i = e.filter(function (e) {
                    return this.indices.indexOf(e.body.type) >= 0
                }, {
                    indices: t
                }),
                o = [];
            if (0 == n) {
                var r = i.filter(function (e) {
                        return "IPC" == e.index
                    }),
                    a = i.filter(function (e) {
                        return "DJI" == e.index
                    }),
                    s = i.filter(function (e) {
                        return "S&P 500" == e.index
                    }),
                    c = i.filter(function (e) {
                        return "NASDAQ" == e.index
                    }),
                    l = i.filter(function (e) {
                        return "BOVESPA" == e.index
                    });
                o.unshift(r[0], a[0], s[0], c[0], l[0])
            }
            if (1 == n) {
                var u = i.filter(function (e) {
                        return "Oro" == e.index
                    }),
                    d = i.filter(function (e) {
                        return "Plata" == e.index
                    }),
                    g = i.filter(function (e) {
                        return "Cobre" == e.index
                    });
                o.unshift(u[0], d[0], g[0])
            }
            return 2 == n && (i = []), o.length > 0 && (i = o), i
        }
    }

    function n() {
        return function (e, t, n) {
            if (!t || 0 === t.length) return e;
            var i = e.filter(function (e) {
                    return this.indices.indexOf(e.body.type) >= 0
                }, {
                    indices: t
                }),
                o = [];
            return 0 == n && (o = i.filter(function (e) {
                return "IPC" != e.index && "DJI" != e.index && "S&P 500" != e.index && "NASDAQ" != e.index && "BOVESPA" != e.index
            })), 1 == n && (o = i.filter(function (e) {
                return "Oro" != e.index && "Plata" != e.index && "Cobre" != e.index
            })), 2 == n && (o = i.filter(function (e) {
                return "Peso MXN" != e.index
            })), o.length > 0 && (i = o), i
        }
    }

    function i() {
        return function (e, t, n) {
            if (!t || 0 === t.length) return e;
            var i = e.filter(function (e) {
                    return e.currencyType == t.value
                }),
                o = [];
            if (2 == n) {
                var r = i.filter(function (e) {
                    return "Dolar USD" == e.name
                });
                o.unshift(r[0])
            }
            return o.length > 0 && (i = o), i
        }
    }

    function o() {
        return function (e, t, n) {
            if (!t || 0 === t.length) return e;
            var i = e.filter(function (e) {
                    return e.currencyType == t.value
                }),
                o = [];
            return 2 == n && (o = i.filter(function (e) {
                return "Dolar USD" != e.name
            })), o.length > 0 && (i = o), i
        }
    }
    var r = "hbCommoditiesCtrl";
    angular.module("app").controller(r, ["$filter", "$interval", "$scope", "$rootScope", "common", "notificationTypes", "hbLoggingSvc", "hbGlobalizationSvc", "hbMarketSvc", "hbSecuritySvc", "hbSolaceSvc", "hbGridsterOptions", "hbBrowserSvc", "timeoutConfig", e]), angular.module("app").filter("topFilterCommodities", t), angular.module("app").filter("filterCommodities", n), angular.module("app").filter("topFilterCurrencies", i), angular.module("app").filter("filterCurrencies", o)
}(),
function () {
    "use strict";

    function e(e, n, i, o, r, a, s, c, l, u, d, g, f) {
        function p() {
            var e = [S(), h(), m()];
            r.activateController(e, t).then(function () {
                D || (r.$broadcast("dashboard.widget_initialized", "Position"), D = !0), void 0 !== o.loadConfiguration && o.loadConfiguration(), v(), o.setRefreshFunction(y)
            }), o.subscribreToNotifications && o.subscribreToNotifications()
        }

        function h() {
            var e = [{
                key: "Position_PlusMinus",
                replaceWith: "Position_PlusMinus_Mobile"
            }, {
                key: "Position_MarketValue",
                replaceWith: "Position_MarketValue_Mobile"
            }];
            return E = [{
                key: "Position_Issue",
                label: ""
            }, {
                key: "Position_Shares",
                label: ""
            }, {
                key: "Position_AvgPrice",
                label: ""
            }, {
                key: "Position_MarketPrice",
                label: ""
            }, {
                key: "Position_CostAmount",
                label: ""
            }, {
                key: "Position_MarketValue",
                label: ""
            }, {
                key: "Position_PlusMinus",
                label: ""
            }, {
                key: "Position_Var",
                label: ""
            }, {
                key: "Position_Portfolio",
                label: ""
            }], c.load("Position").then(function (t) {
                for (var n in E) {
                    var i = E[n];
                    if (t[i.key])
                        if (k.isMobile) {
                            var o = e.filter(function (e) {
                                return e.key === i.key
                            });
                            i.label = o.length > 0 ? t[o[0].replaceWith] : t[i.key]
                        } else i.label = t[i.key]
                }
            })
        }

        function m() {
            var e = [];
            k.isMobile || (e = [{
                name: "columns",
                value: "vm.columnsSetup",
                isArray: !0
            }, {
                name: "sortingProp",
                value: "vm.sortingProp"
            }]), "undefined" != typeof o.prepareConfiguration && o.prepareConfiguration(e)
        }

        function v() {
            var e = k.columnsSetup.map(function (e) {
                return {
                    key: e.key,
                    label: b(e.key),
                    enabled: e.enabled
                }
            });
            e = e.filter(function (e) {
                return e.enabled === !0
            }), k.columns = e
        }

        function b(e) {
            var t, n = E.filter(function (t) {
                return t.key === e
            });
            return n.length > 0 && (t = n[0].label), t
        }

        function S() {
            function e(e) {
                for (var t = [], n = [1, 0, 8, 9], i = 0, o = e.aggPositionDetail.length; i < o; r ? i++ : i) {
                    var r = !1,
                        a = n.length > 0 ? n.shift() : function () {
                            var i = t.map(function (e) {
                                return e.posValueType
                            });
                            return n = e.aggPositionDetail.reduce(function (e, t) {
                                return i.indexOf(t.posValueType) < 0 && e.push(t.posValueType), e
                            }, []), n.shift()
                        }();
                    for (var s in e.aggPositionDetail) {
                        var c = e.aggPositionDetail[s];
                        if (c.posValueType == a) {
                            t.push(c), r = !0;
                            break
                        }
                    }
                }
                return t
            }
            return l.getAggPositions(k.defaultContract.contractId).then(function (t) {
                var n = e(t);
                k.posValueTypes = n, I();
                var i = k.posValueTypes.filter(function (e) {
                    return e.posValueType === k.virtualValueType
                });
                if (i.length > 0) {
                    var o = k.virtualPosition.isOpen;
                    k.virtualPosition = i[0], k.virtualPosition.isOpen = o
                }
                k.refresh = new Date
            })
        }

        function y(e) {
            l.refreshPosition(e).then(function (e) {
                return S(), e
            })
        }

        function T() {
            for (var e = [], t = 1, i = k.columnsSetup.length; t < i; t++) e.push({
                key: k.columnsSetup[t].key,
                label: b(k.columnsSetup[t].key),
                showIcon: !1,
                enabled: k.columnsSetup[t].enabled
            });
            var r = this,
                a = n.open({
                    scope: o,
                    templateUrl: "loadPartial/Position/ColumnsSetup",
                    windowClass: "position-configure-columns",
                    controller: "hbColumnsSetupCtrl",
                    resolve: {
                        parentCtrl: function () {
                            return r
                        },
                        columns: function () {
                            return e
                        }
                    }
                });
            a.result.then(function (t) {
                var n, i = [];
                n = {
                    key: k.columnsSetup[0].key,
                    enabled: k.columnsSetup[0].enabled
                }, i.push(n);
                for (var o = 0, r = e.length; o < r; o++) n = {
                    key: e[o].key,
                    enabled: e[o].enabled
                }, i.push(n);
                k.columnsSetup = i, v(), k.refresh = new Date
            })
        }

        function C(e) {
            e && "" != e && (e === k.sortingProp ? k.sortReverse = !k.sortReverse : (k.sortingProp = e, k.sortReverse = !0), I(), k.refresh = new Date)
        }

        function w() {
            return k.sortReverse ? "fa fa-caret-down" : "fa fa-caret-up"
        }

        function I() {
            for (var e in k.posValueTypes) {
                var t = k.posValueTypes[e];
                t.setSorting(k.sortingProp, k.sortReverse)
            }
        }

        function _(e) {
            var t, n, i = k.isMobile ? "small-font" : "";
            for (var o in k.columnsSetup) {
                var r = k.columnsSetup[o];
                if (r.enabled) switch (r.key) {
                    case "Position_Issue":
                        t += '<td class="' + i + '" data-ng-click="vm.notifyIssueSelected(p)" style="cursor:pointer;" title="' + e.position.instrument.issueID + '">' + e.position.instrument.issueID + "</td>\n";
                        break;
                    case "Position_Shares":
                        t += '<td class="' + i + '">' + A(e.position.shares, 0) + "</td>\n";
                        break;
                    case "Position_AvgPrice":
                        switch (e.position.instrument.instrumentType) {
                            case 27:
                            case 28:
                                n = A(e.position.averageCost, 6);
                                break;
                            default:
                                n = e.position.averageCost >= 1 || e.position.averageCost <= -1 ? A(e.position.averageCost, 2) : A(e.position.averageCost, 3)
                        }
                        t += '<td class="' + i + '">' + n + "</td>\n";
                        break;
                    case "Position_MarketPrice":
                        switch (e.position.instrument.instrumentType) {
                            case 27:
                            case 28:
                                n = A(e.marketPrice, 6);
                                break;
                            default:
                                n = e.marketPrice >= 1 || e.marketPrice <= -1 ? A(e.marketPrice, 2) : A(e.marketPrice, 3)
                        }
                        t += '<td class="' + i + '">' + n + "</td>\n";
                        break;
                    case "Position_CostAmount":
                        n = e.costAmount >= 1 || e.costAmount <= -1 ? A(e.costAmount, 2) : A(e.costAmount, 3), t += '<td class="' + i + '">' + n + "</td>\n";
                        break;
                    case "Position_MarketValue":
                        n = e.marketValue >= 1 || e.marketValue <= -1 ? A(e.marketValue, 2) : A(e.marketValue, 3), t += '<td class="' + i + '">' + n + "</td>\n";
                        break;
                    case "Position_PlusMinus":
                        var a = e.plusMinus > 0 ? "positive" : e.plusMinus < 0 ? "negative" : "zero";
                        n = e.plusMinus >= 1 || e.plusMinus <= -1 ? A(e.plusMinus, 2) : A(e.plusMinus, 3), t += '<td class="' + a + " " + i + '">' + n + "</td>\n";
                        break;
                    case "Position_Var":
                        var a = e["var"] > 0 ? "positive" : e["var"] < 0 ? "negative" : "zero";
                        t += '<td class="' + a + " " + i + '">' + A(e["var"], 2) + "</td>\n";
                        break;
                    case "Position_Portfolio":
                        t += '<td class="' + i + '">' + A(e.portfolio, 2) + "</td>\n"
                }
            }
            return t
        }

        function P(e) {
            var t, n, i = !0;
            for (var o in k.columns) {
                var r = k.columns[o],
                    a = i ? "openSub" : parseInt(o) !== k.columns.length - 1 ? "contSub" : "closeSub",
                    s = k.isMobile ? "small-font" : "";
                switch (i && (i = !1), r.key) {
                    case "Position_Issue":
                        t += k.isMobile ? '<td style="width:50%;" class="' + a + " " + s + '">SubTotal</td>\n' : '<td class="' + a + '">SubTotal</td>\n';
                        break;
                    case "Position_Shares":
                        t += '<td class="' + a + " " + s + '"></td>\n';
                        break;
                    case "Position_AvgPrice":
                        t += '<td class="' + a + " " + s + '"></td>\n';
                        break;
                    case "Position_MarketPrice":
                        t += '<td class="' + a + " " + s + '"></td>\n';
                        break;
                    case "Position_CostAmount":
                        t += '<td class="' + a + " " + s + '"></td>\n';
                        break;
                    case "Position_MarketValue":
                        n = e.marketValueSubTot > 1 || e.marketValueSubTot < -1 ? A(e.marketValueSubTot, 2) : A(e.marketValueSubTot, 3), t += '<td class="' + a + " " + s + '">' + n + "</td>\n";
                        break;
                    case "Position_PlusMinus":
                        n = e.plusMinusSubTot > 1 || e.plusMinusSubTot < -1 ? A(e.plusMinusSubTot, 2) : A(e.plusMinusSubTot, 3), t += '<td class="' + a + " " + s + '">' + n + "</td>\n";
                        break;
                    case "Position_Var":
                        t += '<td class="' + a + " " + s + '">' + A(e.varSubTot, 2) + "</td>\n";
                        break;
                    case "Position_Portfolio":
                        t += '<td class="' + a + " " + s + '">' + A(e.portfolioSubTot, 2) + "</td>\n"
                }
            }
            return t
        }

        function M(e) {
            if (e && (0 === e.position.positionValueType || 1 === e.position.positionValueType || 2 === e.position.positionValueType || 5 === e.position.positionValueType || "efec.  mismo dia" === e.position.instrument.issueID.toLowerCase())) {
                var t = {
                        emitter: o.widget.name,
                        symbol: e.position.instrument.issueID,
                        issue: e
                    },
                    n = a.SELECTED_POSITION_CASH;
                switch (e.position.positionValueType) {
                    case 0:
                    case 1:
                        n = a.SELECTED_POSITION_CAPITAL;
                        break;
                    case 2:
                    case 5:
                        n = a.SELECTED_POSITION_FUNDS
                }
                o.notify(n, t)
            }
        }

        function O() {
            var e = o.$parent.widget.size_y * g.colWidth,
                t = o.$parent.widget.size_x * g.colWidth;
            e && (k.scrollViewHeight = e - 130 + "px", k.scrollViewWidth = t - 25 + "px")
        }
        var E, D = !1,
            A = e("number"),
            k = this;
        k.posValueTypes = [], k.ticker = l.ticker, k.cash = {
            isOpen: !1
        }, k.virtualValueType = l.virtualValueType, k.defaultContract = s.defaultContract, k.virtualPosition = {
            isOpen: !1
        }, k.refresh, k.showColumnsSetup = T, k.columns, k.getPositionRow = _, k.getPositionTotalsRow = P, k.notifyIssueSelected = M, k.scrollViewHeight = 0, k.scrollViewWidth = 0, k.scrollSpeed = "firefox" === f() ? 20 : 1, k.isMobile = r.mobileProperties.isMobile, k.sortReverse = !1, k.sortingProp = "Position_Issue", k.setSorting = C, k.getCaretClass = w, k.columnsSetup = [{
            key: "Position_Issue",
            enabled: !0
        }, {
            key: "Position_Shares",
            enabled: !0
        }, {
            key: "Position_AvgPrice",
            enabled: !0
        }, {
            key: "Position_MarketPrice",
            enabled: !0
        }, {
            key: "Position_CostAmount",
            enabled: !0
        }, {
            key: "Position_MarketValue",
            enabled: !0
        }, {
            key: "Position_PlusMinus",
            enabled: !0
        }, {
            key: "Position_Var",
            enabled: !0
        }, {
            key: "Position_Portfolio",
            enabled: !0
        }], p(), o.$watch(function () {
            return r.mobileProperties.isMobile
        }, function (e, t) {
            k.isMobile = e, e ? (k.columnsSetup[1].enabled = !1, k.columnsSetup[2].enabled = !1, k.columnsSetup[3].enabled = !1, k.columnsSetup[4].enabled = !1, k.columnsSetup[8].enabled = !1) : (k.columnsSetup[1].enabled = !0, k.columnsSetup[2].enabled = !0, k.columnsSetup[3].enabled = !0, k.columnsSetup[4].enabled = !0, k.columnsSetup[8].enabled = !0), v(), S(), h()
        }), i.$on("mobile-resize-" + o.widget.id, function (e, t) {
            k.scrollViewHeight = t.viewHeight - 150 + "px"
        }), o.$watch("vm.defaultContract.contractId", function (e, t) {
            e && e !== t && S()
        }), o.$watch("vm.ticker.lastTick", function (e, t) {
            e !== t && S()
        }), o.$on(d.OrdersChangedEvent, function (e, t) {
            y(t.isTimer)
        }), o.$watch(function () {
            return o.$parent.widget.size_y
        }, function () {
            k.isMobile || O()
        }), o.$watch(function () {
            return o.$parent.widget.size_x
        }, function () {
            k.isMobile || O()
        }), o.$watch("vm.sortingProp", function (e, t) {
            e !== t && I()
        })
    }
    var t = "hbPositionCtrl";
    angular.module("app").controller(t, ["$filter", "$modal", "$rootScope", "$scope", "common", "notificationTypes", "hbContractManagementSvc", "hbGlobalizationSvc", "hbPositionSvc", "hbSolaceSvc", "hbOrderSvc", "hbGridsterOptions", "hbBrowserSvc", e])
}(), angular.module("template/accordion/accordion-group.html", []).run(["$templateCache", function (e) {
        e.put("template/accordion/accordion-group.html", '<div class="panel panel-default">\n  <div class="panel-heading" ng-class=" {\'collapsed\':!isOpen} ">\n    <h4 class="panel-title" ng-click="toggleOpen()">\n      <a class="accordion-toggle" accordion-transclude="heading"><span ng-class="{\'text-muted\': isDisabled}">{{heading}}</span></a>\n    </h4>\n  </div>\n  <div class="panel-collapse" collapse="!isOpen">\n\t  <div class="panel-body" ng-transclude></div>\n  </div>\n</div>')
    }]),
    function () {
        "use strict";

        function e(e, t, n, i, o) {
            e.columnsToConfigure = o, e.dismiss = function () {
                n.dismiss("cancel")
            }, e.accept = function () {
                n.close()
            }, e.sortableOptions = {
                axie: "y"
            }
        }
        var t = "hbColumnsSetupCtrl";
        angular.module("app").controller(t, ["$scope", "$rootScope", "$modalInstance", "parentCtrl", "columns", e])
    }(),
    function () {
        "use strict";

        function e(e, n, i, o, r, a, s, c, l, u, d) {
            function g() {
                R && B && setTimeout(w, 3e3)
            }

            function f() {
                var e = [b(), T()];
                a.activateController(e, t).then(function () {
                    if ("undefined" != typeof o.loadConfiguration && o.loadConfiguration(), A.hasPermission) {
                        if ("" !== A.searchedIssue) {
                            var e = h(A.searchedIssue);
                            a.$q.all([e]).then(function () {
                                P(k, o.widget.id, A.symbolIssue)
                            }), C()
                        } else A.done = !0, B = !0, a.$broadcast("dashboard.widget_initialized", "Advance Chart");
                        o.setRefreshFunction(y), A.hasJava = deployJava.getJREs().length > 0
                    } else a.$broadcast("dashboard.widget_initialized", "Advance Chart")
                })
            }

            function p() {
                A.percentage = A.percentage + 10, A.message = "Getting symbol", b();
                var e = h(A.searchedIssue);
                a.$q.all([e]).then(function () {
                    o.safeApply(function () {
                        L || (A.showProgressBar = !0, P(k, o.widget.id, A.symbolIssue))
                    })
                }), A.percentage = A.percentage + 9, A.message = "Showing...", g()
            }

            function h(e) {
                return u.getStock2Graphics(e).then(function (e) {
                    A.symbolIssue = e.data.response
                }, function (e) {
                    c.logging(e.data, c.loggingTypes.EXCEPTION)
                })
            }

            function m() {
                if (r.appletsWorking.length > 0)
                    for (var e = 0; e < r.appletsWorking.length; e++) r.appletsWorking[e] === o.widget.id && r.appletsWorking.splice(e, 1)
            }

            function v() {
                if (r.appletsWorking.length > 0)
                    for (var e = 0; e < r.appletsWorking.length; e++)
                        if (r.appletsWorking[e] === o.widget.id) return;
                r.appletsWorking.push(o.widget.id)
            }

            function b() {
                return u.getTokenGraphics().then(function (e) {
                    k = e.data.response
                }, function (e) {
                    e.data.IsBussinessError && (A.hasPermission = !1, A.businessMessage = e.data.ErrorMessage)
                })
            }

            function S(e, t) {
                var n = e.name.substring(0, e.name.indexOf("."));
                switch (s[n]) {
                    case s.SELECTED_SYMBOL:
                        A.searchedIssue = t.symbol;
                        break;
                    default:
                        c.logging("Unhandled Notification", c.loggingTypes.EXCEPTION)
                }
            }

            function y() {
                A.hasError = !1, U = null, b().then(function () {
                    A.showProgressBar = !0, A.percentage = 0, A.message = "Getting data...", P(k, o.widget.id, A.symbolIssue)
                })
            }

            function T() {
                var e = [{
                    name: "searchedIssue",
                    value: "vm.searchedIssue"
                }];
                "undefined" != typeof o.prepareConfiguration && o.prepareConfiguration(e)
            }

            function C() {
                $("#Chart" + o.widget.id).height(0)
            }

            function w() {
                A.hasError || ($("#Chart" + o.widget.id).height("80%"), $("#Chart" + o.widget.id).width("93%"), A.showProgressBar = !1)
            }

            function I() {
                _(), x = setInterval(function () {
                    A.saveWorkSpaceTime = new Date
                }, F, 0, !1)
            }

            function _() {
                x && clearInterval(x)
            }

            function P(e, t, n) {
                v(), A.done = !1, A.showProgressBar = !0;
                var i = '<div id="divChart' + t + '" style="height: 92%;width: 100%;">    <object id="Chart' + t + '" classid="java:com.futuresource.imaf.IMAFApplet.class" type="application/x-java-applet" archive="AllApplets" style="height: 0;width: 95%; display: block;  position:absolute;">        <param name="code" value="com.futuresource.imaf.IMAFApplet.class">         <param name="codebase" value="http://download.esignal.com/GBM/widgets/">         <param name="cache_option" value="Plugin">         <param name="cache_archive" value="AllApplets.jar">         <param name="scriptable" value="true">         <param name="mayscript" value="true">         <param name="java_arguments" value="-Djnlp.packEnabled=true -Dsun.java2d.d3d=false -Xmx128m">         <param name="type" value="chart">         <param name="url" value="http://gbm.widget.market-q.com">         <param name="u" value=' + e + '>        <param name="id" value="P' + t + '">         <param name="onload" value="appletDone(' + t + ');">        <param name="properties" value="symbol=' + n + '">         <param name="wmode" value="transparent">         <param name="onstatuschange" value="onStatusChange(' + t + ')">    </object>     </div>';
                $("#divChart" + t).remove(), $("#div" + t).append(i), L = !0
            }

            function M() {
                deployJava.returnPage = location.href, deployJava.installLatestJRE()
            }

            function O(e, t, n) {
                A.percentage = A.percentage + 20, A.message = t, null === U ? (N = new Date, U = o.$watch(function () {
                    var e = (new Date - N) / 1e3;
                    return e > 20
                }, function (e, t) {
                    e && (A.hasError = !0, $("#Chart" + o.widget.id).remove(), B || a.$broadcast("dashboard.widget_initialized", "Advance Chart"), U())
                })) : N = new Date, n ? (U(), B || (B = !0, a.$broadcast("dashboard.widget_initialized", "Advance Chart")), A.hasError = !0, $("#Chart" + o.widget.id).remove(), c.logging(e + " - " + t, c.loggingTypes.EXCEPTION)) : "READY" === e && (U(), B || a.$broadcast("dashboard.widget_initialized", "Advance Chart"), B = !0, A.showProgressBar = !1, w(), I())
            }
            var E, D = [{
                    sub: s.SELECTED_SYMBOL,
                    unsub: void 0
                }],
                A = this,
                k = "",
                L = !1;
            A.issue = "", A.issueName = "", A.searchedIssue = "", A.symbolIssue = "", A.tokenChart = "", A.done = !1, A.hasJava = !0, A.businessMessage = "", A.hasPermission = !0, A.showProgressBar = !1, A.percentage = 0, A.message = "Getting data...", A.hasError = !1, A.saveWorkSpaceTime = new Date;
            var x, B = !1,
                R = !1,
                N = null,
                U = null,
                F = 6e4;
            A.installJRE = M, A.statusChangeApplet = O, A.refresh = y, o.hideApplet = C, o.showApplet = w, o.subscribreToNotifications && o.subscribreToNotifications(D, S), r.$on("hide_Applets", function (e) {
                C()
            }), r.$on("show_Applets", function (e) {
                w()
            }), o.$on("hide_Applet" + o.widget.id, function (e) {
                C()
            }), o.$on("show_Applet" + o.widget.id, function (e) {
                w()
            }), r.$on("loading.tasks_completed", function (e) {
                R = !0, g()
            }), o.safeApply = function (e) {
                var t = this.$root.$$phase;
                "$apply" == t || "$digest" == t ? e && "function" == typeof e && e() : this.$apply(e)
            }, o.$watch("vm.done", function (e, t) {
                e !== t && (e ? (E = o.$watch("vm.searchedIssue", function (e, t) {
                    "" !== e && (L ? h(e) : p())
                }), B || (B = !0, a.$broadcast("dashboard.widget_initialized", "Advance Chart"), g())) : L || E())
            }), o.$on("$destroy", function () {
                C(), _(), m()
            }), f()
        }
        var t = "hbAdvancedChartsCtrl";
        angular.module("app").controller(t, ["$filter", "$timeout", "$interval", "$scope", "$rootScope", "common", "notificationTypes", "hbLoggingSvc", "hbGlobalizationSvc", "hbUtilitiesSvc", "$sce", e])
    }(),
    function () {
        "use strict";

        function e() {
            var e = this;
            e.Message = "Empty Widget"
        }
        var t = "hbEmptyCtrl";
        angular.module("app").controller(t, [e])
    }(),
    function () {
        "use strict";

        function e() {
            return function (e, t) {
                return e ? (t = +t, e.slice(t)) : e
            }
        }
        var t = "startFrom";
        angular.module("app").filter(t, [e])
    }(),
    function (e) {
        "use strict";

        function t(e, t, n, i, o, r) {
            function a() {
                S(y.presenceChannelName) && (n.createPresenceChannel(y.presenceChannelName), y.presenceChannelName = "", m(1), y.controlView = 1)
            }

            function s(e) {
                y.privateView = 2, y.searchUser = "", y.privateUserToSend = e
            }

            function c() {
                l()
            }

            function l() {
                y.privateView = 1, y.privateChannelName = "", y.privateMessage = "", y.privateUserToSend = void 0
            }

            function u(e, t, i) {
                y.controlView = 1, n.subscribeChannel(e.name, e.friendlyChannelName, t), d(e.name, t), t && h(i)
            }

            function d(e, t) {
                t ? n.setCurrentPrivateChannel(e) : n.setCurrentPresenceChannel(e), y.controlView = 1, m(3)
            }

            function g() {
                0 !== y.message.length && n.sendMessage({
                    channelName: 0 === y.selectedTabId ? y.channelsInfo.currentPresenceChannel.name : y.channelsInfo.currentPrivateChannel.name,
                    message: y.message
                }).then(function () {
                    $("#chat-input-" + e.$parent.widget.id).focus(), y.message = ""
                })
            }

            function f(e) {
                if (!e) {
                    if (!S(y.privateChannelName)) return;
                    n.createPrivateChannel(y.privateChannelName)
                }
                n.sendInvitation({
                    userName: y.privateUserToSend.id,
                    channelName: e ? y.channelsInfo.currentPrivateChannel.name : y.privateChannelName,
                    friendlyChannelName: e ? y.channelsInfo.currentPrivateChannel.friendlyChannelName : y.privateChannelName,
                    message: e ? "" : y.privateMessage,
                    chatAlreadyExists: e
                }).then(function () {
                    l(), e || m(1), y.showAddUserToPrivateChat = !1
                }, function (e) {
                    console.error(e)
                })
            }

            function p(e) {
                return y.searchUser = "", y.privateUserToSend = e, y.channelsInfo.currentPrivateChannel.members.members[e.id] ? void o.logging(e.name + " ya se encuentra conectado al chat privado.", o.loggingTypes.WARNING) : void f(!0)
            }

            function h(e) {
                n.rejectInvitation(e)
            }

            function m(t) {
                switch (t) {
                    case 1:
                    case 2:
                        y.privateView = 1, n.resetCurrentChannels();
                        break;
                    case 3:
                        $("#chat-input-" + e.$parent.widget.id).focus()
                }
                y.roomView = t
            }

            function v() {
                n.unsubscribeCurrentChannel(1 === y.selectedTabId);
                m(1)
            }

            function b() {
                var t = e.$parent.widget.size_y * r.colWidth,
                    n = e.$parent.widget.size_x * r.colWidth;
                if (t)
                    if (y.isMobile) {
                        var i = $("#" + e.widget.id).width();
                        y.chatWidth = i + 35, y.chatHeight = t
                    } else y.chatWidth = n - 10, y.chatHeight = t - 170
            }

            function S(e) {
                var t = /^[a-zA-Z0-9]+$/,
                    n = !1;
                if (0 === e.length) return n;
                if (e.length > 25) return o.logging("El nombre de la sala no debe exceder de 25 caracteres.", o.loggingTypes.WARNING), n;
                if (n = t.test(e), !n) return o.logging("Nombre de sala invÃ¡lido. Solo se admiten caracteres alfanumÃ©ricos.", o.loggingTypes.WARNING),
                    n;
                var i = [];
                return i = 0 === y.selectedTabId ? y.channelsInfo.myPrecenseChannels.filter(function (t) {
                    return t.friendlyChannelName === e
                }) : y.channelsInfo.myPrivateChannels.filter(function (t) {
                    return t.friendlyChannelName === e
                }), i.length > 0 ? (o.logging("Nombre de sala existente.", o.loggingTypes.WARNING), !1) : n
            }
            var y = this;
            y.tabs = [{
                id: 0,
                name: "PÃºblicos"
            }, {
                id: 1,
                name: "Privados"
            }], y.filtered = [], y.filteredUser = [], y.searchData = "", y.searchUser = "", y.selectedTabId = y.tabs[0].id, y.roomView = 1, y.controlView = 1, y.privateView = 1, y.pusherInfo = n.pusherInfo, y.channelsInfo = n.channelsInfo, y.selectedChannel = y.channelsInfo.channels.length > 0 ? y.channelsInfo.channels[0] : void 0, y.presenceChannelName = "", y.addChannel = a, y.subscribeChannel = u, y.changeRoomView = m, y.setCurrentChannel = d, y.unsubscribeCurrentChannel = v, y.privateChannelName = "", y.privateMessage = "", y.goToViewSendPrivateMessage = s, y.cancelSendPrivateMessage = c, y.sendInvitation = f, y.rejectInvitation = h, y.addUserToPrivateChat = p, y.isMobile = t.mobileProperties.isMobile, y.privateUserToSend = void 0, y.showAddUserToPrivateChat = !1, y.message = "", y.sendMessage = g, y.data = y.channelsInfo.channels;
            var T = e.$watch("vm.selectedTabId", function (e, t) {
                    e !== t && (m(1), 0 === e ? y.data = y.channelsInfo.channels : y.data = y.channelsInfo.myPrivateChannels)
                }),
                C = e.$watch(function () {
                    if (0 === y.selectedTabId) {
                        if (y.channelsInfo.currentPresenceChannel) return y.channelsInfo.currentPresenceChannel.messages.length
                    } else if (y.channelsInfo.currentPrivateChannel) return y.channelsInfo.currentPrivateChannel.messages.length;
                    return 0
                }, function (t, n) {
                    if (t !== n) {
                        var i = document.getElementById("chat-" + e.$parent.widget.id);
                        i && $("#chat-" + e.$parent.widget.id).animate({
                            scrollTop: i.scrollHeight
                        }, "slow")
                    }
                }),
                w = e.$watch(function () {
                    return e.$parent.widget.size_y
                }, function (e, t) {
                    b()
                }),
                I = e.$watch(function () {
                    return e.$parent.widget.size_x
                }, function (e, t) {
                    b()
                }),
                _ = e.$on("$destroy", function () {
                    n.unsubscribePushers(), C && C(), T && T(), w && w(), I && I(), _ && _()
                });
            n.getChannelList().then(function () {
                t.$broadcast("dashboard.widget_initialized", "Chat")
            })
        }
        var n = "hbChatterCtrl";
        e.controller(n, ["$scope", "common", "hbChatsSvc", "hbSecuritySvc", "hbLoggingSvc", "hbGridsterOptions", t])
    }(angular.module("app")),
    function (e) {
        "use strict";

        function t(e, t, n) {}
        var n = "hbRosterCtrl";
        e.controller(n, ["$scope", "hbChatsSvc", "hbSecuritySvc", t])
    }(angular.module("app")),
    function (e) {
        "use strict";

        function t(e, t, n, i, o, r, a, s, c, l) {
            function u() {
                d(), "undefined" != typeof n.loadConfiguration && setTimeout(function () {
                    n.loadConfiguration()
                }, 1), g(), setTimeout(function () {
                    i.$broadcast("dashboard.widget_initialized", "Advanced Chart")
                }, 6e3)
            }

            function d() {
                var e = [{
                    name: "symbol",
                    value: "vm.symbol"
                }, {
                    name: "interval",
                    value: "vm.interval"
                }];
                "undefined" != typeof n.prepareConfiguration && n.prepareConfiguration(e)
            }

            function g() {
                setTimeout(function () {
                    T = new TradingView.widget({
                        fullscreen: !1,
                        symbol: D.symbol.length > 0 ? D.symbol : "AMX L",
                        interval: D.interval ? D.interval : "2",
                        container_id: O,
                        datafeed: E,
                        library_path: "Scripts/tradingview/charting_library/",
                        locale: "es",
                        drawings_access: {
                            type: "black",
                            tools: [{
                                name: "Regression Trend"
                            }]
                        },
                        disabled_features: ["use_localstorage_for_settings", "link_to_tradingview"],
                        client_id: "gbmhomebroker.com",
                        user_id: "public_user_id",
                        width: n.widget.size_x * M - 40,
                        height: n.widget.size_y * M - 60,
                        timezone: "America/Chicago",
                        time_frames: [{
                            text: "1d",
                            resolution: "15"
                        }, {
                            text: "1m",
                            resolution: "1D"
                        }, {
                            text: "3m",
                            resolution: "1D"
                        }, {
                            text: "6m",
                            resolution: "1D"
                        }, {
                            text: "1y",
                            resolution: "1D"
                        }, {
                            text: "3y",
                            resolution: "1W"
                        }, {
                            text: "5y",
                            resolution: "1M"
                        }],
                        overrides: {},
                        widgetbar: {
                            datawindow: !0,
                            details: !0
                        }
                    }), T.onChartReady(function () {
                        function e(e, t) {
                            return b(e, t).then(function (t) {
                                t && t.data && t.data.response && (D.loadedChart = {
                                    chartId: t.data.response,
                                    description: t.data.name,
                                    configuration: e,
                                    processDate: new Date
                                }, I.text(D.loadedChart.description).show(), C.addClass("titled"), _.css("display", "inline-block"))
                            })
                        }
                        var t = T.createButton({
                            align: "left"
                        });
                        w = $('<span class="button load first">Cargar</span>'), w.on("click", function (e) {
                            w.addClass("process"), S().then(function (e) {
                                e && (D.loadedChart = e, I.text(e.description).show(), C.addClass("titled"), _.css("display", "inline-block"), T.load(e.configuration))
                            })["finally"](function () {
                                w.removeClass("process")
                            })
                        }.bind(this)), C = $('<span class="save button apply-common-tooltip last">Guardar<i class="separator"></span>'), C.on("click", function (t) {
                            T.save(function (t) {
                                D.loadedChart ? (C.addClass("process"), v({
                                    chartId: D.loadedChart.chartId,
                                    description: D.loadedChart.description,
                                    configuration: t
                                })["finally"](function () {
                                    C.removeClass("process"), D.loadedChart = angular.extend({}, D.loadedChart, {
                                        configuration: t
                                    })
                                })) : e(t)
                            })
                        }.bind(this)), I = $('<span class="title apply-common-tooltip" style="display: none;">'), I.append('<span type="text" maxlength="80" style="width: 50px;"></span><span class="sizer"></span>');
                        var n = '<div class="block-inline"  style="position:relative; display: none;"><span class="button with-arrow options last expand-options" aria-haspopup="true" aria-expanded="true"><span class="arrow-icon"></span></span></div>';
                        _ = $(n);
                        var i = _.find(".expand-options");
                        i.on("click", function (e) {
                            r.css("top", i.offset().top + 30), r.css("left", i.closest(".save-load-buttons").offset().left), r.toggle()
                        });
                        var o = '<div class="charts-popup-list" style="top: 37px; left: 446px; right: auto; display: none; max-height: 441px;"> <a class="item popup-list-rename first" href="#"><span class="title-expanded">Renombre...</span></a> <a class="item popup-list-saveas" href="#"><span class="title-expanded">Guardar como...</span></a> </div>',
                            r = $(o);
                        t.removeAttr("class").addClass("save-load-buttons in-header").append(w).append(C).append(I).append(_), r.find(".popup-list-saveas").on("click", function (t) {
                            t.preventDefault(), t.stopPropagation(), T.save(function (t) {
                                e(t)
                            }), r.toggle()
                        }), r.find(".popup-list-rename").on("click", function (t) {
                            t.preventDefault(), t.stopPropagation(), T.save(function (t) {
                                e(t, !0)
                            }), r.toggle()
                        }), t.closest("body").append(r), T.onSymbolChange(function (e) {
                            D.symbol = e.name, m(e.name)
                        }), T.onIntervalChange(function (e) {
                            D.interval = e
                        }), D.loadedChart && (I.text(D.loadedChart.description).show(), C.addClass("titled"), _.css("display", "inline-block"), T.load(D.loadedChart.configuration))
                    })
                }, 1)
            }

            function f() {
                T && T.setSymbol(D.symbol, D.interval)
            }

            function p(e, t) {
                if (t.emitter !== n.widget.name + "_" + n.widget.id) {
                    var i = e.name.substring(0, e.name.indexOf("."));
                    switch (o[i]) {
                        case o.SELECTED_SYMBOL:
                        case o.SEARCHED_SYMBOL:
                        case o.SELECTED_POSITION_CAPITAL:
                            D.symbol = t.symbol, f();
                            break;
                        default:
                            a.logging("unhandled notification type received", a.loggingTypes.EXCEPTION)
                    }
                }
            }

            function h() {
                if (T) {
                    var e = $("#" + T.id);
                    e.width(n.widget.size_x * M - 40), e.height(n.widget.size_y * M - 60)
                }
            }

            function m(e) {
                var t = {
                    emitter: n.widget.name + "_" + n.widget.id,
                    symbol: e
                };
                n.notify(o.SEARCHED_SYMBOL, t)
            }

            function v(e) {
                return c.updateMarketChartConfiguration(e)
            }

            function b(t, i) {
                var o = e.defer(),
                    r = l.open({
                        scope: n,
                        templateUrl: "loadPartial/AdvancedCharts/SaveChartsWindow",
                        windowClass: "load-chart-config",
                        controller: "hbSaveChartConfigCtrl",
                        controllerAs: "saveChartVM",
                        resolve: {
                            updateInfo: ["$q", function (e) {
                                return i && D.loadedChart && D.loadedChart.description ? e.when({
                                    isUpdate: i,
                                    name: D.loadedChart.description
                                }) : e.when({
                                    isUpdate: i,
                                    name: ""
                                })
                            }]
                        }
                    });
                return r.result.then(function (e) {
                    e && !i ? c.addMarketChartConfiguration(e, t).then(function (t) {
                        t.data && (t.data.name = e), o.resolve(t)
                    }, function (e) {
                        o.reject(e)
                    }) : e && v({
                        chartId: D.loadedChart.chartId,
                        description: e,
                        configuration: t
                    }).then(function (t) {
                        t.data = {}, t.data.name = e, t.data.response = D.loadedChart.chartId, o.resolve(t)
                    }, function (e) {
                        o.reject(e)
                    })
                }), o.promise
            }

            function S() {
                return l.open({
                    scope: n,
                    templateUrl: "loadPartial/AdvancedCharts/LoadChartsWindow",
                    windowClass: "load-chart-config",
                    controller: "hbLoadChartConfigCtrl",
                    controllerAs: "selectChartVM",
                    resolve: {
                        configList: function () {
                            return c.getMarketChartConfiguration().then(function (e) {
                                var t = [];
                                return e && e.data && e.data.length > 0 && (t = e.data.map(function (e) {
                                    return e.processDate = new Date(e.processDate), e.configuration = JSON.parse(e.configuration), e
                                })), t
                            })
                        }
                    }
                }).result
            }

            function y() {
                D.loadedChart = void 0, I.text("").hide(), C.removeClass("titled"), _.css("display", "none")
            }
            var T, C, w, I, _, P = [{
                    sub: o.SELECTED_SYMBOL,
                    unsub: void 0
                }, {
                    sub: o.SEARCHED_SYMBOL,
                    unsub: void 0
                }, {
                    sub: o.SELECTED_POSITION_CAPITAL,
                    unsub: void 0
                }],
                M = r.colWidth,
                O = "tv_chart_container-" + n.widget.id,
                E = new s.UDFCompatibleDatafeed("http://demo_feed.tradingview.com"),
                D = this;
            D.chartId = n.widget.id, D.symbol = "", D.interval = "1", D.loadedChart, n.subscribreToNotifications && n.subscribreToNotifications(P, p), n.$watch(function () {
                return n.$parent.widget.size_y
            }, function () {
                h()
            }), n.$watch(function () {
                return n.$parent.widget.size_x
            }, function () {
                h()
            }), n.$on("$destroy", function () {
                E.close(), T && T.remove()
            }), t.$on("ChartConfigurationDeleted", function (e, t) {
                D.loadedChart && D.loadedChart.chartId === t && y()
            }), u()
        }
        e.controller("hbTVChartsCtrl", ["$q", "$rootScope", "$scope", "common", "notificationTypes", "hbGridsterOptions", "hbLoggingSvc", "hbTVDatafeedsSvc", "hbAppManagementSvc", "$modal", t])
    }(angular.module("app")),
    function (e) {
        "use strict";

        function t(e, t) {
            var n = {},
                i = "SIC",
                o = "BMV";
            return n.UDFCompatibleDatafeed = function (e, t) {
                this._datafeedURL = e, this._configuration = void 0, this._symbolSearch = null, this._symbolsStorage = null, this._barsPulseUpdater = new n.DataPulseUpdater(this, t || 6e4), this._quotesPulseUpdater = new n.QuotesPulseUpdater(this), this._enableLogging = !1, this._initializationFinished = !1, this._callbacks = {}, this._initialize()
            }, n.UDFCompatibleDatafeed.prototype.defaultConfiguration = function () {
                return {
                    exchanges: [{
                        desc: "",
                        name: "All Exchanges",
                        value: ""
                    }, {
                        desc: o,
                        name: o,
                        value: o
                    }, {
                        desc: i,
                        name: i,
                        value: i
                    }],
                    supports_search: !0,
                    supports_group_request: !1,
                    supported_resolutions: ["1", "2", "3", "5", "10", "15", "30", "1D", "1W", "1M", "3M"],
                    supports_marks: !1,
                    symbolsTypes: [{
                        name: "Stock",
                        value: "stock"
                    }]
                }
            }, n.UDFCompatibleDatafeed.prototype.on = function (e, t) {
                return this._callbacks.hasOwnProperty(e) || (this._callbacks[e] = []), this._callbacks[e].push(t), this
            }, n.UDFCompatibleDatafeed.prototype._fireEvent = function (e, t) {
                if (this._callbacks.hasOwnProperty(e)) {
                    for (var n = this._callbacks[e], i = 0; i < n.length; ++i) n[i](t);
                    this._callbacks[e] = []
                }
            }, n.UDFCompatibleDatafeed.prototype.onInitialized = function () {
                this._initializationFinished = !0, this._fireEvent("initialized")
            }, n.UDFCompatibleDatafeed.prototype._logMessage = function (e) {
                if (this._enableLogging) {
                    var t = new Date;
                    console.log(t.toLocaleTimeString() + "." + t.getMilliseconds() + "> " + e)
                }
            }, n.UDFCompatibleDatafeed.prototype._send = function (e, t) {
                var n = e;
                if (t)
                    for (var i = 0; i < Object.keys(t).length; ++i) {
                        var o = Object.keys(t)[i],
                            r = encodeURIComponent(t[o]);
                        n += (0 === i ? "?" : "&") + o + "=" + r
                    }
                return this._logMessage("New request: " + n), $.ajax({
                    type: "GET",
                    url: n,
                    contentType: "text/plain"
                })
            }, n.UDFCompatibleDatafeed.prototype._initialize = function () {
                var e = this;
                e._setupWithConfiguration(e.defaultConfiguration())
            }, n.UDFCompatibleDatafeed.prototype.onReady = function (e) {
                if (this._configuration) e(this._configuration);
                else {
                    var t = this;
                    this.on("configuration_ready", function () {
                        e(t._configuration)
                    })
                }
            }, n.UDFCompatibleDatafeed.prototype._setupWithConfiguration = function (e) {
                this._configuration = e, e.exchanges || (e.exchanges = []);
                var t = e.supported_resolutions || e.supportedResolutions;
                e.supported_resolutions = t;
                var i = e.symbols_types || e.symbolsTypes;
                if (e.symbols_types = i, !e.supports_search && !e.supports_group_request) throw "Unsupported datafeed configuration. Must either support search, or support group request";
                e.supports_search || (this._symbolSearch = new n.SymbolSearchComponent(this)), e.supports_group_request ? this._symbolsStorage = new n.SymbolsStorage(this) : this.onInitialized(), this._fireEvent("configuration_ready"), this._logMessage("Initialized with " + JSON.stringify(e))
            }, n.UDFCompatibleDatafeed.prototype.getMarks = function (e, t, n, i, o) {
                this._configuration.supports_marks && this._send(this._datafeedURL + "/marks", {
                    symbol: e.ticker.toUpperCase(),
                    from: t,
                    to: n,
                    resolution: o
                }).done(function (e) {
                    i(JSON.parse(e))
                }).fail(function () {
                    i([])
                })
            }, n.UDFCompatibleDatafeed.prototype.searchSymbolsByName = function (t, n, r, a) {
                var s = 30;
                if (!this._configuration) return void a([]);
                if (this._configuration.supports_search) t && t.length > 2 && e.searchIssue(t).then(function (e) {
                    if (e && e.data) {
                        var t = e.data.map(function (e) {
                                return {
                                    description: e.issueName,
                                    exchange: 2 === e.instrumentType ? i : o,
                                    full_name: e.issueID,
                                    symbol: e.issueID,
                                    type: "stock",
                                    params: []
                                }
                            }),
                            s = t.filter(function (e) {
                                var t = !r || e.type === r,
                                    i = !n || e.exchange === n;
                                return t && i
                            });
                        a(s)
                    }
                });
                else {
                    if (!this._symbolSearch) throw "Datafeed error: inconsistent configuration (symbol search)";
                    var c = {
                        ticker: t,
                        exchange: n,
                        type: r,
                        onResultReadyCallback: a
                    };
                    if (this._initializationFinished) this._symbolSearch.searchSymbolsByName(c, s);
                    else {
                        var l = this;
                        this.on("initialized", function () {
                            l._symbolSearch.searchSymbolsByName(c, s)
                        })
                    }
                }
            }, n.UDFCompatibleDatafeed.prototype._symbolResolveURL = "/symbols", n.UDFCompatibleDatafeed.prototype.resolveSymbol = function (e, n, r) {
                function a(e) {
                    var t = e;
                    s.postProcessSymbolInfo && (t = s.postProcessSymbolInfo(t)), n(t)
                }
                var s = this;
                if (!this._initializationFinished) return void this.on("initialized", function () {
                    s.resolveSymbol(e, n, r)
                });
                if (this._configuration.supports_group_request) this._initializationFinished ? this._symbolsStorage.resolveSymbol(e, a, r) : this.on("initialized", function () {
                    s._symbolsStorage.resolveSymbol(e, a, r)
                });
                else {
                    var c = t.getSymbol({
                        symbol: e
                    });
                    if (c) {
                        var l = 2 === c.instrumentType ? i : o,
                            u = {
                                s: "ok",
                                name: c.symbol,
                                ticker: c.symbol,
                                description: c.symbol,
                                session: "0830-1500",
                                "exchange-trade": l,
                                "exchange-listed": l,
                                timezone: "America/Chicago",
                                pricescale: 100,
                                pointvalue: 1,
                                minmov: 1,
                                minmov2: 0,
                                has_no_volume: !1,
                                type: "stock",
                                supported_resolutions: this.defaultConfiguration().supported_resolutions,
                                has_daily: !0,
                                has_fractional_volume: !1,
                                has_weekly_and_monthly: !1,
                                has_empty_bars: !1,
                                full_name: c.symbol,
                                has_intraday: !0,
                                listed_exchange: l,
                                exchange: l
                            };
                        a(u)
                    }
                }
            }, n.UDFCompatibleDatafeed.prototype._historyURL = "/history", n.UDFCompatibleDatafeed.prototype.getBars = function (t, n, i, o, r, a) {
                function s(t, n, i, o) {
                    var r = "BMV" === t.listed_exchange ? 0 : 2;
                    return e.getCapitalMarketHistoricPrice(t.ticker, r, n, i, !0, o).then(function (e) {
                        var t = [];
                        return e.data && e.data.length > 0 ? (e.data.sort(function (e, t) {
                            var n = new Date(e.date),
                                i = new Date(t.date);
                            return n - i
                        }), t = e.data.reduce(function (e, t) {
                            var n = new Date(t.date),
                                i = {
                                    time: n.getTime(),
                                    close: t.closePrice,
                                    open: t.openPrice,
                                    high: t.maxPrice,
                                    low: t.minPrice,
                                    volume: t.volume
                                };
                            return e.push(i), e
                        }, [])) : e.data && 0 === e.data.length, t
                    })
                }

                function c(t, n, i) {
                    return n = 60 * n, e.getInstrumentPricesIntradayComplete(t.ticker, n, i).then(function (e) {
                        var t = [];
                        return e.data && e.data.length > 0 && (e.data.sort(function (e, t) {
                            var n = new Date(e.date),
                                i = new Date(t.date);
                            return n > i ? 1 : n < i ? -1 : 0
                        }), t = e.data.reduce(function (e, t) {
                            var n = new Date(t.date),
                                i = {
                                    time: n.getTime(),
                                    close: t.closePrice,
                                    open: t.openPrice,
                                    high: t.maxPrice,
                                    low: t.minPrice,
                                    volume: t.volume
                                };
                            return e.push(i), e
                        }, [])), t
                    })
                }
                if (i > 0 && (i + "").length > 10) throw "Got a JS time instead of Unix one.";
                var l = new Date(1e3 * i),
                    u = new Date(1e3 * o);
                n.indexOf("D") >= 0 || n.indexOf("W") >= 0 || n.indexOf("M") >= 0 ? s(t, l, u, !0).then(r)["catch"](a) : c(t, n, !0).then(r)["catch"](a)
            }, n.UDFCompatibleDatafeed.prototype.subscribeBars = function (e, t, n, i) {
                this._barsPulseUpdater.subscribeDataListener(e, t, n, i)
            }, n.UDFCompatibleDatafeed.prototype.unsubscribeBars = function (e) {
                this._barsPulseUpdater.unsubscribeDataListener(e)
            }, n.UDFCompatibleDatafeed.prototype.calculateHistoryDepth = function (e, t, n) {}, n.UDFCompatibleDatafeed.prototype.getQuotes = function (e, t, n) {
                this._send(this._datafeedURL + "/quotes", {
                    symbols: e
                }).done(function (e) {
                    var i = JSON.parse(e);
                    "ok" == i.s ? t && t(i.d) : n && n(i.errmsg)
                }).fail(function (e) {
                    n && n("network error: " + e)
                })
            }, n.UDFCompatibleDatafeed.prototype.subscribeQuotes = function (e, t, n, i) {
                this._quotesPulseUpdater.subscribeDataListener(e, t, n, i)
            }, n.UDFCompatibleDatafeed.prototype.unsubscribeQuotes = function (e) {
                this._quotesPulseUpdater.unsubscribeDataListener(e)
            }, n.UDFCompatibleDatafeed.prototype.close = function () {
                this._barsPulseUpdater.close(), this._quotesPulseUpdater.close()
            }, n.SymbolsStorage = function (e) {
                this._datafeed = e, this._exchangesList = ["NYSE", "FOREX", "AMEX"], this._exchangesWaitingForData = {}, this._exchangesDataCache = {}, this._symbolsInfo = {}, this._symbolsList = [], this._requestFullSymbolsList()
            }, n.SymbolsStorage.prototype._requestFullSymbolsList = function () {
                for (var e = this, t = (this._datafeed, 0); t < this._exchangesList.length; ++t) {
                    var n = this._exchangesList[t];
                    this._exchangesDataCache.hasOwnProperty(n) || (this._exchangesDataCache[n] = !0, this._exchangesWaitingForData[n] = "waiting_for_data", this._datafeed._send(this._datafeed._datafeedURL + "/symbol_info", {
                        group: n
                    }).done(function (t) {
                        return function (n) {
                            e._onExchangeDataReceived(t, JSON.parse(n)), e._onAnyExchangeResponseReceived(t)
                        }
                    }(n)).fail(function (t) {
                        return function (n) {
                            e._onAnyExchangeResponseReceived(t)
                        }
                    }(n)))
                }
            }, n.SymbolsStorage.prototype._onExchangeDataReceived = function (e, t) {
                function n(e, t, n) {
                    return e[t] instanceof Array ? e[t][n] : e[t]
                }
                try {
                    for (var i = 0; i < t.symbol.length; ++i) {
                        var o = t.symbol[i],
                            r = n(t, "exchange-listed", i),
                            a = n(t, "exchange-traded", i),
                            s = a + ":" + o,
                            c = n(t, "has-intraday", i),
                            l = "undefined" != typeof t.ticker,
                            u = {
                                name: o,
                                base_name: [r + ":" + o],
                                description: n(t, "description", i),
                                full_name: s,
                                legs: [s],
                                has_intraday: c,
                                has_no_volume: n(t, "has-no-volume", i),
                                listed_exchange: r,
                                exchange: a,
                                minmov: n(t, "minmovement", i) || n(t, "minmov", i),
                                minmove2: n(t, "minmove2", i) || n(t, "minmov2", i),
                                fractional: n(t, "fractional", i),
                                pointvalue: n(t, "pointvalue", i),
                                pricescale: n(t, "pricescale", i),
                                type: n(t, "type", i),
                                session: n(t, "session-regular", i),
                                ticker: l ? n(t, "ticker", i) : o,
                                timezone: n(t, "timezone", i),
                                supported_resolutions: n(t, "supported-resolutions", i) || this._datafeed.defaultConfiguration().supported_resolutions,
                                force_session_rebuild: n(t, "force-session-rebuild", i) || !1,
                                has_daily: n(t, "has-daily", i) || !0,
                                intraday_multipliers: n(t, "intraday-multipliers", i) || ["1", "5", "15", "30", "60"],
                                has_fractional_volume: n(t, "has-fractional-volume", i) || !1,
                                has_weekly_and_monthly: n(t, "has-weekly-and-monthly", i) || !1,
                                has_empty_bars: n(t, "has-empty-bars", i) || !1,
                                volume_precision: n(t, "volume-precision", i) || 0
                            };
                        this._symbolsInfo[u.ticker] = this._symbolsInfo[o] = this._symbolsInfo[s] = u, this._symbolsList.push(o)
                    }
                } catch (d) {
                    throw "API error when processing exchange `" + e + "` symbol #" + i + ": " + d
                }
            }, n.SymbolsStorage.prototype._onAnyExchangeResponseReceived = function (e) {
                delete this._exchangesWaitingForData[e];
                var t = 0 === Object.keys(this._exchangesWaitingForData).length;
                t && (this._symbolsList.sort(), this._datafeed._logMessage("All exchanges data ready"), this._datafeed.onInitialized())
            }, n.SymbolsStorage.prototype.resolveSymbol = function (e, t, n) {
                this._symbolsInfo.hasOwnProperty(e) ? t(this._symbolsInfo[e]) : n("invalid symbol")
            }, n.SymbolSearchComponent = function (e) {
                this._datafeed = e
            }, n.SymbolSearchComponent.prototype.searchSymbolsByName = function (e, t) {
                if (!this._datafeed._symbolsStorage) throw "Cannot use local symbol search when no groups information is available";
                for (var n = this._datafeed._symbolsStorage, i = [], o = !e.ticker || 0 === e.ticker.length, r = 0; r < n._symbolsList.length; ++r) {
                    var a = n._symbolsList[r],
                        s = n._symbolsInfo[a];
                    if (!(e.type && e.type.length > 0 && s.type != e.type) && !(e.exchange && e.exchange.length > 0 && s.exchange != e.exchange) && ((o || 0 === s.name.indexOf(e.ticker)) && i.push({
                            symbol: s.name,
                            full_name: s.full_name,
                            description: s.description,
                            exchange: s.exchange,
                            params: [],
                            type: s.type,
                            ticker: s.name
                        }), i.length >= t)) break
                }
                e.onResultReadyCallback(i)
            }, n.DataPulseUpdater = function (e, t) {
                this._datafeed = e, this._subscribers = {}, this._requestsPending = 0;
                var n = this,
                    i = function () {
                        if (!(n._requestsPending > 0))
                            for (var e in n._subscribers) {
                                var t = n._subscribers[e],
                                    i = t.resolution,
                                    o = new Date,
                                    r = Math.round((o.valueOf() - 60 * o.getTimezoneOffset() * 1e3) / 1e3),
                                    a = r - n.periodLengthSeconds(i, 10);
                                n._requestsPending++,
                                    function (t) {
                                        n._datafeed.getBars(t.symbolInfo, i, a, r, function (i) {
                                            if (n._requestsPending--, n._subscribers.hasOwnProperty(e) && i && 0 !== i.length) {
                                                var o = i[i.length - 1];
                                                if (isNaN(t.lastBarTime) || !(o.time < t.lastBarTime)) {
                                                    var r = t.listeners,
                                                        a = !isNaN(t.lastBarTime) && o.time > t.lastBarTime;
                                                    if (a) {
                                                        if (i.length < 2) throw "Not enough bars in history for proper pulse update. Need at least 2.";
                                                        for (var s = i[i.length - 2], c = 0; c < r.length; ++c) r[c](s)
                                                    }
                                                    t.lastBarTime = o.time;
                                                    for (var c = 0; c < r.length; ++c) r[c](o)
                                                }
                                            }
                                        }, function () {
                                            n._requestsPending--
                                        })
                                    }(t)
                            }
                    };
                "undefined" != typeof t && t > 0 && (this._interval = setInterval(i, t))
            }, n.DataPulseUpdater.prototype.unsubscribeDataListener = function (e) {
                this._datafeed._logMessage("Unsubscribing " + e), delete this._subscribers[e]
            }, n.DataPulseUpdater.prototype.subscribeDataListener = function (e, t, n, i) {
                this._datafeed._logMessage("Subscribing " + i);
                e.name + ", " + t;
                this._subscribers.hasOwnProperty(i) || (this._subscribers[i] = {
                    symbolInfo: e,
                    resolution: t,
                    lastBarTime: NaN,
                    listeners: []
                }), this._subscribers[i].listeners.push(n)
            }, n.DataPulseUpdater.prototype.periodLengthSeconds = function (e, t) {
                var n = 0;
                return n = "D" == e ? t : "M" == e ? 31 * t : "W" == e ? 7 * t : t * e / 1440, 24 * n * 60 * 60
            }, n.DataPulseUpdater.prototype.close = function () {
                this._interval && clearInterval(this._interval)
            }, n.QuotesPulseUpdater = function (e) {
                this._datafeed = e, this._subscribers = {}, this._updateInterval = 6e4, this._fastUpdateInterval = 1e4, this._requestsPending = 0;
                var t = this;
                this._intervalRef = setInterval(function () {
                    t._updateQuotes(function (e) {
                        return e.symbols
                    })
                }, this._updateInterval), this._fastRef = setInterval(function () {
                    t._updateQuotes(function (e) {
                        return e.fastSymbols.length > 0 ? e.fastSymbols : e.symbols
                    })
                }, this._fastUpdateInterval)
            }, n.QuotesPulseUpdater.prototype.subscribeDataListener = function (e, t, n, i) {
                this._subscribers.hasOwnProperty(i) || (this._subscribers[i] = {
                    symbols: e,
                    fastSymbols: t,
                    listeners: []
                }), this._subscribers[i].listeners.push(n)
            }, n.QuotesPulseUpdater.prototype.unsubscribeDataListener = function (e) {
                delete this._subscribers[e]
            }, n.QuotesPulseUpdater.prototype._updateQuotes = function (e) {
                if (!(this._requestsPending > 0)) {
                    var t = this;
                    for (var n in this._subscribers) {
                        this._requestsPending++;
                        var i = this._subscribers[n];
                        this._datafeed.getQuotes(e(i), function (e, n) {
                            return function (i) {
                                if (t._requestsPending--, t._subscribers.hasOwnProperty(n))
                                    for (var o = 0; o < e.length; ++o) e[o](i)
                            }
                        }(i.listeners, n), function (e) {
                            t._requestsPending--
                        })
                    }
                }
            }, n.QuotesPulseUpdater.prototype.close = function () {
                this._intervalRef && clearInterval(this._intervalRef), this._fastRef && clearInterval(this._fastRef)
            }, n
        }
        e.factory("hbTVDatafeedsSvc", ["hbMarketSvc", "hbSolaceSvc", t])
    }(angular.module("app")),
    function (e) {
        "use strict";

        function t(e, t, n) {
            function i() {
                e.dismiss("cancel")
            }

            function o() {
                e.close()
            }

            function r(t) {
                e.close(t)
            }

            function a(e, t) {
                e.preventDefault(), e.stopPropagation(), n.deleteMarketChartConfiguration(t).then(function () {
                    s.configList = s.configList.filter(function (e) {
                        return e.chartId !== t
                    })
                })
            }
            var s = this;
            s.accept = o, s.dismiss = i, s.configList = t, s.selectConfig = r, s.deleteConfig = a
        }
        e.controller("hbLoadChartConfigCtrl", ["$modalInstance", "configList", "hbAppManagementSvc", t])
    }(angular.module("app")),
    function (e) {
        "use strict";

        function t(e, t) {
            function n() {
                e.dismiss("cancel")
            }

            function i() {
                e.close(o.name)
            }
            var o = this;
            o.accept = i, o.dismiss = n, o.name = t.name
        }
        e.controller("hbSaveChartConfigCtrl", ["$modalInstance", "updateInfo", t])
    }(angular.module("app")),
    function () {
        "use strict";

        function e(e, t, n, i) {}
        var t = "hbFiscalSimulatorCtrl";
        angular.module("app").controller(t, ["$scope", "common", "hbLoggingSvc", "hbGlobalizationSvc", e])
    }(),
    function () {
        "use strict";

        function e(e, t, n, i, o) {
            function r() {
                d.selected && d.selected.length > 0 && (f || n.logging(o.getResource("SearchInput_JS_MSG_NoCriteriaFound", !0), n.loggingTypes.EXCEPTION))
            }

            function a() {
                return d.validateOnBlur()
            }

            function s(t) {
                e.issueSymbol = t, g = !0
            }

            function c(e) {
                return t.searchIssue(e).then(function (e) {
                    return f = e.data.length > 0, e.data
                })
            }

            function l(e) {
                return null != e ? e.issueID : ""
            }

            function u(e) {
                return null != e ? e.issueID + " - " + e.issueName : ""
            }
            var d = this,
                g = !1;
            e.notify = s, d.selected = null, d.searchIssue = c, d.labelSelected = l, d.label = u;
            var f = !1;
            o.load("SearchInput"), e.$watch("issueSymbol", function (t, n) {
                t && (d.selected = {
                    issueID: e.issueSymbol
                }, g && (g = !1, e.methodNotifyChange()))
            }), e.onblur = a, d.validateOnBlur = r
        }
        var t = "hbSearchInputCtrl";
        angular.module("app").controller(t, ["$scope", "hbMarketSvc", "hbLoggingSvc", "common", "hbGlobalizationSvc", e])
    }(),
    function () {
        "use strict";

        function e(e, t, n, i, o, r) {
            var a = this;
            e.vm = a, a.options = r, e.$watch(function () {
                return n.loggedIn()
            }, function (e, t) {
                e || dismiss()
            }), e.dismiss = function () {
                i.close(!0)
            }, e.accept = function () {
                a.options.isPromise ? a.options.action().then(function () {
                    i.close()
                }) : (a.options.action(), i.close())
            }
        }
        var t = "hbConfirmationCtrl";
        angular.module("app").controller(t, ["$scope", "$rootScope", "hbSecuritySvc", "$modalInstance", "parentCtrl", "options", e])
    }(),
    function () {
        "use strict";

        function e(e, t, n, i, o, r, a, s) {
            function c() {
                f.noRows = null, h.processDate = new Date, f.paging.currentPage = 1, l(), p || (p = !0, n.$broadcast("dashboard.widget_initialized", "Transactions"))
            }

            function l() {
                f.beginDate.setHours(0, 0, 0, 0), f.endDate.setHours(23, 59, 59, 0), h.isSettlement = !f.isByOperation, h.pageIndex = f.paging.currentPage - 1, h.pageSize = f.pageSize, h.sortTransaction = f.sortingProp, h.startDate = f.beginDate, h.endDate = f.endDate, h.contractId = f.defaultContract.contractId, h.ascendent = !f.sortReverse, h.rowNumber = f.noRows, f.loading = !0;
                var e = Math.abs(f.endDate.getTime() - f.beginDate.getTime());
                return Math.ceil(e / 864e5) > 180 ? (o.logging("El rango de bÃºsqueda es solo de 6 meses.", o.loggingTypes.WARNING), void(f.loading = !1)) : void a.getTransactions(h).then(function (e) {
                    f.noRows = e.data.transactionsRowNumber, f.noRows > 0 && (f.transactions = e.data.transactions, f.isSearchOperation = f.isByOperation), f.loading = !1
                }, function (e) {
                    o.logging("" === e.data ? e.statusText : e.data, o.loggingTypes.EXCEPTION), f.loading = !1
                })
            }

            function u(e) {}

            function d(e) {
                e === f.sortingProp ? f.sortReverse = !f.sortReverse : (f.sortingProp = e, f.sortReverse = !0), f.paging.currentPage = 1, l()
            }

            function g() {
                return f.sortReverse ? "fa fa-caret-down" : "fa fa-caret-up"
            }
            var f = this,
                p = !1,
                h = {};
            f.loading = !1, f.transactions = [], f.contracts = s.contracts, f.defaultContract = s.defaultContract, f.maxDate = new Date, f.minDate = new Date, f.minDate.setDate(f.minDate.getDate() - 180), f.beginDate = new Date, f.endDate = new Date, f.opened = !1, f.openedEnd = !1, f.isByOperation = !0, f.isSearchOperation = !0, t.$watch("vm.paging.currentPage", function (e, t) {
                e !== t && f.noRows > 0 && l()
            }), f.pageSize = 10, f.noRows = null, f.open = function (e, t) {
                e.preventDefault(), e.stopPropagation(), 1 === t ? f.opened = !0 : f.openedEnd = !0
            }, f.paging = {
                currentPage: 1,
                maxPagesToShow: 10,
                pageSize: f.pageSize
            }, f.sortingProp = 23, f.sortReverse = !1, f.setOrder = d, f.getCaretClass = g, f.pageChanged = u, f.disabled = function (e, t) {
                return "day" === t && (0 === e.getDay() || 6 === e.getDay())
            }, f.search = c, t.setRefreshFunction(c), c()
        }
        var t = "hbTransactionsCtrl";
        angular.module("app").controller(t, ["$filter", "$scope", "common", "notificationTypes", "hbLoggingSvc", "hbGlobalizationSvc", "hbPortfolioSvc", "hbContractManagementSvc", e])
    }(),
    function () {
        "use strict";

        function e(e, t, n, i, o) {
            e.columnsToConfigure = o, e.dismiss = function () {
                n.close()
            }
        }
        var t = "configureColumnsCtrl";
        angular.module("app").controller(t, ["$scope", "$rootScope", "$modalInstance", "parentCtrl", "columns", e])
    }(),
    function () {
        "use strict";

        function e(e, t, n, i) {
            e.dismiss = function () {
                n.close()
            }, e.accept = function () {
                i(), this.dismiss()
            }
        }
        var t = "cancelAllCtrl";
        angular.module("app").controller(t, ["$scope", "$rootScope", "$modalInstance", "cancelAction", e])
    }(),
    function () {
        function e(e, t, n, i) {
            var o = this;
            o.message = i, o.dismiss = function () {
                n.close()
            }
        }
        var t = "hbErrorCtrl";
        angular.module("app").controller(t, ["$scope", "$rootScope", "$modalInstance", "message", e])
    }(),
    function () {
        "use strict";

        function e(e, t, n, i) {
            var o = this;
            e.vm = o, e.dismiss = function () {
                i.location.reload(), n.close()
            }
        }
        var t = "hbRefreshApplicationCtrl";
        angular.module("app").controller(t, ["$scope", "$rootScope", "$modalInstance", "$window", e])
    }(),
    function () {
        "use strict";

        function e(e, n, i, o, r, a, s, c, l) {
            function u() {
                var e = v[S.selectedTabMId];
                y[e]()
            }

            function d(e, t) {
                t = t || "default", y[t] = e
            }

            function g() {
                var e = [f()];
                o.activateController(e, t).then(function () {
                    n.loadConfiguration && n.loadConfiguration(), S.hasLevel2 && b.push({
                        id: 1,
                        name: "Level 2"
                    })
                })
            }

            function f() {
                var e = [{
                    name: "issueMix",
                    value: "issueMix"
                }, {
                    name: "selectedTabMId",
                    value: "selectedTabMId"
                }];
                n.prepareConfiguration && n.prepareConfiguration(e)
            }

            function p(e, t) {
                var n = e.name.substring(0, e.name.indexOf("."));
                switch (r[n]) {
                    case r.SELECTED_SYMBOL:
                    case r.SEARCHED_SYMBOL:
                    case r.SELECTED_POSITION_CAPITAL:
                        S.issueMix = t.symbol;
                        break;
                    default:
                        a.logging("unhandled notification type received", a.loggingTypes.EXCEPTION)
                }
            }

            function h(e) {
                ++C === w && T && T("Trade-Level2-Participation")
            }
            var m = [{
                    sub: r.SELECTED_SYMBOL,
                    unsub: void 0
                }, {
                    sub: r.SEARCHED_SYMBOL,
                    unsub: void 0
                }, {
                    sub: r.SELECTED_POSITION_CAPITAL,
                    unsub: void 0
                }],
                v = ["trade", "level2", "participation", "blotter"],
                b = [{
                    id: 0,
                    name: "Trade"
                }, {
                    id: 2,
                    name: "Participation"
                }, {
                    id: 3,
                    name: "Blotter"
                }],
                S = n;
            S.tabsM = b, S.selectedTabMId = b[0].id, S.issueMix = "", S.hasLevel2 = c.user.hasLevel2, S.isMobile = o.mobileProperties.isMobile, n.notifyIssue = function () {
                var e = {
                    emitter: n.widget.name,
                    symbol: S.issueMix
                };
                n.notify(r.SEARCHED_SYMBOL, e)
            };
            var y = {};
            n.setRefreshFunction(u), n.setRefreshFunction = d, n.subscribreToNotifications && n.subscribreToNotifications(m, p);
            var T, C = 0,
                w = 4;
            n.notifyWidgetReady && (T = n.notifyWidgetReady, n.notifyWidgetReady = h), n.$watch(function () {
                return o.mobileProperties.isMobile
            }, function (e, t) {
                S.isMobile = e
            }), g()
        }
        var t = "hbTradeLevel2ParticipationCtrl";
        angular.module("app").controller(t, ["$filter", "$scope", "$rootScope", "common", "notificationTypes", "hbLoggingSvc", "hbGlobalizationSvc", "hbSecuritySvc", "hbBrowserSvc", e])
    }(),
    function () {
        "use strict";

        function e(e, t, n, i, o, r, a) {
            var s = this;
            s.tweets = [{
                text: "Texto 1",
                user: "@User1"
            }, {
                text: "Texto 2",
                user: "@User2"
            }, {
                text: "Texto 3",
                user: "@User3"
            }, {
                text: "Texto 4",
                user: "@User4"
            }, {
                text: "Texto 5",
                user: "@User5"
            }, {
                text: "Texto 6",
                user: "@User6"
            }, {
                text: "Texto 7",
                user: "@User7"
            }]
        }
        var t = "hbSocialNetworkCtrl";
        angular.module("app").controller(t, ["$filter", "$scope", "$rootScope", "common", "notificationTypes", "hbLoggingSvc", "hbGlobalizationSvc", e])
    }(),
    function () {
        "use strict";

        function e(e, n, i, o, r, a, s, c, l, u, d) {
            function g() {
                y.ipc = y.nac.filter(function (e) {
                    var t = !1;
                    return e.hechos.body.ipcParticipationRate > 0 && (t = !0), t
                }, {
                    benchmarkId: 1
                })
            }

            function f() {
                p(), g();
                var e = u.isUserSicEnabled().then(function (e) {
                    if (e) {
                        var t = {
                            id: "SIC",
                            name: "SIC"
                        };
                        y.marketTabs.push(t)
                    }
                });
                o.activateController([s.load("TopTen"), e], t).then(function () {
                    if ("undefined" != typeof n.loadConfiguration) {
                        var e = n.loadConfiguration();
                        o.$q.all([e]).then(function () {
                            h(), o.$broadcast("dashboard.widget_initialized", "Top 10")
                        })
                    }
                    s.getResource("TopTen_JS_MSG_Ganadores").then(function (e) {
                        y.topicsTabs[0].name = e
                    }), s.getResource("TopTen_JS_MSG_Perdedores").then(function (e) {
                        y.topicsTabs[1].name = e
                    }), s.getResource("TopTen_JS_MSG_Volumen").then(function (e) {
                        y.topicsTabs[2].name = e
                    }), n.$emit("hb-gridster-item-size-request"), n.setRefreshFunction(c.refresh), n.subscribreToNotifications && n.subscribreToNotifications()
                })
            }

            function p() {
                var e = [{
                    name: "marketSelectedTabId",
                    value: "vm.marketSelectedTabId"
                }, {
                    name: "topicSelectedTabId",
                    value: "vm.topicSelectedTabId"
                }];
                "undefined" != typeof n.prepareConfiguration && n.prepareConfiguration(e)
            }

            function h() {
                switch (y.marketSelectedTabId) {
                    case "BMV":
                        y.displayList = y.nac;
                        break;
                    case "IPC":
                        y.displayList = y.ipc;
                        break;
                    case "SIC":
                        y.displayList = y.sic
                }
            }

            function m(e) {
                var t = "";
                if (e > 0 && e < 999999) {
                    var n = e / 1e3;
                    t = n.toFixed(2) + "K"
                } else {
                    var i = e / 1e6;
                    t = i.toFixed(2) + "M"
                }
                return t
            }

            function v(e, t) {
                var n = t.hechos.body.changeAvg.toFixed(2);
                return n > 0 ? "#96EB50" : n < 0 ? "#E84C3D" : "#FFFFFF"
            }

            function b() {
                var e = n.$parent.widget.size_y * l.colWidth,
                    t = n.$parent.widget.size_x * l.colWidth;
                e && (y.scrollViewHeight = e - 130 + "px", y.scrollViewWidth = t - 25 + "px")
            }

            function S(e) {
                if (e) {
                    var t = {
                        emitter: n.widget.name,
                        symbol: e
                    };
                    n.notify(r.SELECTED_SYMBOL, t)
                }
            }
            var y = this,
                T = [],
                C = !1;
            y.sic = c.getSic(), y.nac = c.getNac(), y.ipc = [], y.marketTabs = [{
                    id: "BMV",
                    name: "BMV"
                }, {
                    id: "IPC",
                    name: "IPC"
                }], y.marketSelectedTabId = y.marketTabs[0].id, y.topicsTabs = [{
                    id: 0,
                    name: "",
                    orderBy: "hechos.body.changeAvg",
                    reverse: !0
                }, {
                    id: 1,
                    name: "",
                    orderBy: "hechos.body.changeAvg",
                    reverse: !1
                }, {
                    id: 2,
                    name: "",
                    orderBy: "hechos.body.aggVolume",
                    reverse: !0
                }], y.topicSelectedTab = y.topicsTabs[0], y.topicSelectedTabId = y.topicsTabs[0].id, y.displayList = [], y.validateColor = v, y.formatMK = m, y.scrollViewHeight = 0, y.scrollViewWidth = 0, y.scrollSpeed = "firefox" === d() ? 20 : 1, y.notifyIssueSelected = S, y.isMobile = o.mobileProperties.isMobile, i.$on("mobile-resize-" + n.widget.id, function (e, t) {
                    y.scrollViewHeight = t.viewHeight - 180 + "px"
                }), n.$watch(function () {
                    return o.mobileProperties.isMobile
                }, function (e, t) {
                    y.isMobile = e
                }),
                n.$watch(function () {
                    return n.$parent.widget.size_y
                }, function () {
                    y.isMobile || b()
                }), n.$watch(function () {
                    return n.$parent.widget.size_x
                }, function () {
                    y.isMobile || b()
                }), n.$watch("vm.marketSelectedTabId", function (e, t) {
                    e !== t && (C = !0), h()
                }), n.$watch("vm.topicSelectedTabId", function (e, t) {
                    e !== t && (C = !0), void 0 !== e && null !== e && (y.topicSelectedTab = y.topicsTabs[e])
                }), n.$watch("vm.filtered", function (e, t) {
                    C ? (T = e, C = !1) : T = "undefined" != typeof t ? t : e
                }, !0), f()
        }
        var t = "hbToptenCtrl";
        angular.module("app").controller(t, ["$filter", "$scope", "$rootScope", "common", "notificationTypes", "hbLoggingSvc", "hbGlobalizationSvc", "hbSolaceSvc", "hbGridsterOptions", "hbContractManagementSvc", "hbBrowserSvc", e])
    }(),
    function () {
        "use strict";

        function e(e, n, i, o, r, a, s, c, l, u, d) {
            function g(e, t) {
                var n = e.name.substring(0, e.name.indexOf("."));
                switch (a[n]) {
                    case a.SELECTED_POSITION_CASH:
                        t.issue.marketValue > 0 && (w.importToPay = t.issue.marketValue.toFixed(2));
                        break;
                    case a.SELECTED_SYMBOL_CASH:
                        t.symbol.price > 0 && (w.importToPay = t.symbol.price.toFixed(2));
                        break;
                    default:
                        s.logging(c.getResource("Operation_JS_MSG_UnhandledNotification", !0), s.loggingTypes.EXCEPTION)
                }
            }

            function f() {
                var e = [p(), c.load("Operation")];
                o.activateController(e, t).then(function () {
                    if ("undefined" != typeof n.loadConfiguration) {
                        var e = n.loadConfiguration(I);
                        o.$q.all([e]).then(function () {
                            v(), m(), n.notifyWidgetReady()
                        })
                    }
                })
            }

            function p() {
                var e = [];
                "undefined" != typeof n.prepareConfiguration && n.prepareConfiguration(e, I, n)
            }

            function h(e) {
                for (var t = 0; t < P.length; t++)
                    if (P[t].id === e) return P[t].value;
                return !1
            }

            function m() {
                l.getDepositAccountInformation().then(function (e) {
                    w.clabeData = e.data.response
                }, function (e) {
                    s.logging(e.data, s.loggingTypes.EXCEPTION)
                })
            }

            function v() {
                w.importToPay = 0, w.accountSelected = {}, w.dataAccount = [], w.accountsFiltered = [], l.getAllBankAccountInformation().then(function (e) {
                    w.dataAccount = e.data, w.banks = [];
                    for (var t = 0; t < w.dataAccount.length; t++)
                        if (!C(w.banks, "bankName", w.dataAccount[t].bankName)) {
                            var n = {
                                bankId: w.dataAccount[t].bankId,
                                bankName: w.dataAccount[t].bankName
                            };
                            w.banks.push(n)
                        }
                }, function (e) {
                    s.logging(e.data, s.loggingTypes.EXCEPTION)
                })
            }

            function b() {
                var e = o.$q.defer(),
                    t = !i.getUser().isReadAndWrite;
                if (t) r.open({
                    scope: n,
                    templateUrl: "loadPartial/Operation/TokenNeeded",
                    windowClass: "cancel-all",
                    controller: "hbTokenNeededCtrl",
                    resolve: {}
                });
                else {
                    var a = {
                        contractId: u.defaultContract.contractId,
                        amount: w.importToPay,
                        bankId: w.bankSelected.bankId,
                        checkingAccountId: w.accountSelected.bankAccountId
                    };
                    T("REGISTERWITHDRAWAL", !0), d.registerWithdrawal(a).then(function (t) {
                        T("REGISTERWITHDRAWAL", !1), s.logging(c.getResource("Operation_JS_MSG_WithdrawalCompleted", !0), s.loggingTypes.SUCCESS), w.importToPay = 0, e.resolve(t.data)
                    }, function (t) {
                        T("REGISTERWITHDRAWAL", !1), s.logging(t.data, s.loggingTypes.EXCEPTION), e.reject("Error" + t.ErrorMessage)
                    })
                }
                return e.promise
            }

            function S() {
                w.depositsWithDrawalsLoading = !0;
                var e = l.getDepositsWithDrawals(30).then(function (e) {
                    return e.data
                }, function (e) {
                    return null
                });
                w.depositsWithDrawalsLoading = !1, r.open({
                    scope: n,
                    templateUrl: "loadPartial/Operation/DepositsWithDrawals",
                    windowClass: "deposits-drawals",
                    controller: "hbDepositsWithDrawalsCtrl",
                    resolve: {
                        parentCtrl: function () {
                            return w
                        },
                        depositsWithDrawalsData: function () {
                            return e
                        }
                    }
                })
            }

            function y(e) {
                w.accountsFiltered = w.dataAccount.filter(function (e) {
                    return this.bankId === e.bankId
                }, {
                    bankId: parseInt(e)
                })
            }

            function T(e, t) {
                for (var n = 0; n < P.length; n++) P[n].id === e && (P[n].value = t)
            }

            function C(e, t, n) {
                for (var i = 0; i < e.length; i++) {
                    var o = e[i][t];
                    return o === n
                }
            }
            var w = this,
                I = "operationcash";
            w.dataAccount = [], w.banks = [], w.bankSelected = {}, w.accountSelected = {}, w.accountsFiltered = [], w.importToPay = 0, w.clabeData = "", w.depositsWithDrawalsLoading = !1, w.isRegisterWithdrawalDisabled = !0, w.getLoadingFlagValue = h, w.loadAccounts = y, w.registerWithdrawal = b, w.depositsWithDrawals = S;
            var _ = {
                    REGISTERWITHDRAWAL: "REGISTERWITHDRAWAL"
                },
                P = [{
                    id: _.REGISTERWITHDRAWAL,
                    value: !1
                }];
            w.scrollViewHeight = "", w.isMobile = o.mobileProperties.isMobile, n.$watch(function () {
                return o.mobileProperties.isMobile
            }, function (e, t) {
                w.isMobile = e
            }), i.$on("mobile-resize-" + n.widget.id, function (e, t) {
                t.viewHeight <= 500 && (w.scrollViewHeight = t.viewHeight - 130 + "px"), t.viewHeight > 500 && (w.scrollViewHeight = t.viewHeight - 100 + "px")
            });
            var M = [{
                sub: a.SELECTED_POSITION_CASH,
                unsub: void 0
            }, {
                sub: a.SELECTED_SYMBOL_CASH,
                unsub: void 0
            }];
            n.subscribreToNotifications && n.subscribreToNotifications(M, g, I), n.$watch(function () {
                return u.defaultContract.contractId
            }, function (e, t) {
                "undefined" != typeof e && e != t && (v(), m())
            }), n.$watch(function () {
                return w.accountSelected.bankAccountId
            }, function (e, t) {
                "undefined" != typeof e ? w.isRegisterWithdrawalDisabled = !(w.importToPay > 0) : w.isRegisterWithdrawalDisabled = !0
            }), n.$watch("vm.importToPay", function (e, t) {
                e > 0 ? w.isRegisterWithdrawalDisabled = !w.accountSelected.bankAccountId : w.isRegisterWithdrawalDisabled = !0
            }), f()
        }
        var t = "hbOperationCashCtrl";
        angular.module("app").controller(t, ["$filter", "$scope", "$rootScope", "common", "$modal", "notificationTypes", "hbLoggingSvc", "hbGlobalizationSvc", "hbCashSvc", "hbContractManagementSvc", "hbOrderSvc", e])
    }(),
    function () {
        "use strict";

        function e(e, n, i, o, r, a, s, c, l, u, d, g, f, p) {
            function h(e, t) {
                var n = e.name.substring(0, e.name.indexOf("."));
                switch (a[n]) {
                    case a.SELECTED_POSITION_FUNDS:
                        switch (t.issue.position.positionValueType) {
                            case 5:
                                W = !0, R.isNotificationId = {
                                    id: t.issue.position.instrument.issueID
                                }, R.selectedTabId = R.tabs[0].id, R.fundTypeSelected = {
                                    id: "27"
                                };
                                break;
                            case 2:
                                W = !0, R.isNotificationId = {
                                    id: t.issue.position.instrument.issueID
                                }, R.selectedTabId = R.tabs[0].id, R.fundTypeSelected = {
                                    id: "28"
                                }
                        }
                        break;
                    case a.SELECTED_SYMBOL_FUNDS:
                        t.symbol.bitBuy ? (W = !0, R.isNotificationId = {
                            id: t.symbol.issueId
                        }, R.selectedTabId = R.tabs[0].id, R.fundTypeSelected = {
                            id: String(t.symbol.instrumentType)
                        }) : (W = !0, R.isNotificationId = {
                            id: t.symbol.issueId
                        }, R.selectedTabId = R.tabs[1].id, R.fundTypeSelected = {
                            id: String(t.symbol.instrumentType)
                        });
                        break;
                    default:
                        s.logging(c.getResource("Operation_JS_MSG_UnhandledNotification", !0), s.loggingTypes.EXCEPTION)
                }
            }

            function m() {
                var e = [v(), c.load("Operation")];
                o.activateController(e, t).then(function () {
                    if ("undefined" != typeof n.loadConfiguration) {
                        var e = n.loadConfiguration(N);
                        o.$q.all([e]).then(function () {
                            var e = ["Operation_JS_MSG_FundsBuy", "Operation_JS_MSG_FundsSell"];
                            k(R.tabs, e, "name"), R.selectedTabId ? R.fundActionText = c.getResource("Operation_JS_MSG_FundsBuy", !0) : R.fundActionText = c.getResource("Operation_JS_MSG_FundsSell", !0), n.notifyWidgetReady()
                        })
                    }
                })
            }

            function v() {
                var e = [{
                    name: "selectedTabId",
                    value: "vm.selectedTabId"
                }, {
                    name: "customButtonFund1",
                    value: "vm.customButtonFund1"
                }, {
                    name: "customButtonFund2",
                    value: "vm.customButtonFund2"
                }, {
                    name: "customButtonFund3",
                    value: "vm.customButtonFund3"
                }];
                "undefined" != typeof n.prepareConfiguration && n.prepareConfiguration(e, N, n)
            }

            function b(e) {
                for (var t = 0; t < V.length; t++)
                    if (V[t].id === e) return V[t].value;
                return !1
            }

            function S() {
                if (R.fundIssuerSelected.issueId) {
                    R.isQuantityOrImportDisabled = !1;
                    var e = R.fundIssuers.filter(function (e) {
                        return this.issueID === e.issueID
                    }, {
                        issueID: R.fundIssuerSelected.issueId.issueID
                    });
                    R.displayResumeInfo = {
                        price: e[0].lastPrice,
                        issue: e[0].issueID
                    }
                }
            }

            function y() {
                "undefined" != typeof R.fundQuantity && (R.fundImport = (R.displayResumeInfo.price * R.fundQuantity).toFixed(6))
            }

            function T() {
                if ("undefined" != typeof R.fundImport)
                    if (0 !== R.fundImport) {
                        var e = (R.fundImport / R.displayResumeInfo.price).toFixed(6);
                        e % 1 != 0 ? (R.fundQuantity = Math.ceil(e), R.fundImport = (R.displayResumeInfo.price * R.fundQuantity).toFixed(6)) : R.fundQuantity = e
                    } else R.fundQuantity = 0
            }

            function C() {
                R.isQuantityOrImportDisabled || (R.fundQuantity = R.fundQuantity + 1, y())
            }

            function w() {
                R.isQuantityOrImportDisabled || (R.fundQuantity = R.fundQuantity - 1, y())
            }

            function I(e) {
                var t = "M";
                if (e.indexOf(t) > -1) {
                    var n = e.replace(t, "");
                    n = 1e3 * parseFloat(n), R.fundQuantity = R.fundQuantity + n
                } else R.fundQuantity = parseFloat(R.fundQuantity) + parseFloat(e);
                y()
            }

            function _() {
                var e = o.$q.defer(),
                    t = !i.getUser().isReadAndWrite;
                if (t) r.open({
                    scope: n,
                    templateUrl: "loadPartial/Operation/TokenNeeded",
                    windowClass: "cancel-all",
                    controller: "hbTokenNeededCtrl",
                    resolve: {}
                });
                else {
                    var a = {
                        accountId: u.defaultContract.contractId,
                        issueId: R.displayResumeInfo.issue,
                        amount: R.fundImport,
                        bitBuy: R.selectedTabId,
                        instrumentType: R.fundTypeSelected.id
                    };
                    A("REGISTERFUND", !0), d.registerFundsOrder(a).then(function (t) {
                        A("REGISTERFUND", !1), s.logging(c.getResource("Operation_JS_MSG_RegisterFundsOrderCompleted", !0) + " con el nÃºmero " + t.data.response, s.loggingTypes.SUCCESS), e.resolve(t.data)
                    }, function (t) {
                        A("REGISTERFUND", !1), s.logging(t.data, s.loggingTypes.EXCEPTION), e.reject("Error" + t.ErrorMessage)
                    })
                }
                return e.promise
            }

            function P(e) {
                $();
                var t = o.$q.defer();
                return g.getAvailableFundsForTrade(R.selectedTabId, e).then(function (e) {
                    var n = e.data.filter(function (e) {
                        return e.legalPersonalityType === u.defaultContractDetail.legalPersonalityType
                    });
                    R.availableFunds = n, M(0 === +R.fundTypeSelected.id ? 27 : R.fundTypeSelected.id), t.resolve(n), W || (R.fundTypeSelected = {
                        id: "27"
                    })
                }, function (e) {
                    s.logging(e.data, s.loggingTypes.EXCEPTION), t.reject("Error" + e.ErrorMessage)
                })["finally"](function () {
                    x()
                }), t.promise
            }

            function M(e) {
                R.fundTypeSelected = {
                    id: e
                }, R.displayResumeInfo = {}, R.fundQuantity = 0, R.fundImport = 0, R.isQuantityOrImportDisabled = !0, R.selectedTabId ? R.fundIssuers = R.availableFunds.filter(function (e) {
                    return this.instrumentType === e.instrumentType
                }, {
                    instrumentType: parseInt(R.fundTypeSelected.id)
                }) : p.initialized().then(function () {
                    var e = R.availableFunds.filter(function (e) {
                        return this.instrumentType === e.instrumentType
                    }, {
                        instrumentType: parseInt(R.fundTypeSelected.id)
                    });
                    if (27 === +R.fundTypeSelected.id)
                        if (p.foundsToSell.debt.length > 0) {
                            var t = e.filter(function (e) {
                                for (var t = !1, n = 0; n < p.foundsToSell.debt.length; n++) {
                                    var i = p.foundsToSell.debt[n];
                                    if (t = e.issueID === i) break
                                }
                                return t
                            });
                            R.fundIssuers = t
                        } else R.fundIssuers = [];
                    if (28 === +R.fundTypeSelected.id)
                        if (p.foundsToSell.equity.length > 0) {
                            var t = e.filter(function (e) {
                                for (var t = !1, n = 0; n < p.foundsToSell.equity.length; n++) {
                                    var i = p.foundsToSell.equity[n];
                                    if (t = e.issueID === i) break
                                }
                                return t
                            });
                            R.fundIssuers = t
                        } else R.fundIssuers = []
                }, function (e) {
                    console.error(e)
                }), O()
            }

            function O() {
                if (W) {
                    var t = e("filter")(R.fundIssuers, {
                        issueID: R.isNotificationId.id
                    })[0];
                    t ? (R.fundIssuerSelected.issueId = t, R.displayIssuerInformation()) : s.logging(c.getResource("Operation_JS_MSG_NoFundAvailable", !0), s.loggingTypes.WARNING), W = !1, R.isNotificationId = {
                        id: ""
                    }
                } else R.fundIssuerSelected.issueId || (R.fundIssuerSelected.issueId = R.fundIssuers[1], R.displayIssuerInformation())
            }

            function E(e, t) {
                switch (e) {
                    case "vm.amount":
                        R.amount = t;
                        break;
                    case "vm.tradeMode":
                        R.tradeMode = t;
                        break;
                    case "vm.customButton1":
                        R.customButton1 = t;
                        break;
                    case "vm.customButton2":
                        R.customButton2 = t;
                        break;
                    case "vm.customButton3":
                        R.customButton3 = t;
                        break;
                    case "vm.fundQuantity":
                        R.fundQuantity = t;
                        break;
                    case "vm.customButtonFund1":
                        R.customButtonFund1 = t;
                        break;
                    case "vm.customButtonFund2":
                        R.customButtonFund2 = t;
                        break;
                    case "vm.customButtonFund3":
                        R.customButtonFund3 = t
                }
            }

            function D(e) {
                switch (e) {
                    case "vm.amount":
                        return R.amount;
                    case "vm.tradeMode":
                        return R.tradeMode;
                    case "vm.customButton1":
                        return R.customButton1;
                    case "vm.customButton2":
                        return R.customButton2;
                    case "vm.customButton3":
                        return R.customButton3;
                    case "vm.fundQuantity":
                        return R.fundQuantity;
                    case "vm.customButtonFund1":
                        return R.customButtonFund1;
                    case "vm.customButtonFund2":
                        return R.customButtonFund2;
                    case "vm.customButtonFund3":
                        return R.customButtonFund3
                }
            }

            function A(e, t) {
                for (var n = 0; n < V.length; n++) V[n].id === e && (V[n].value = t)
            }

            function k(e, t, n) {
                for (var i = 0, o = t.length; i < o; i++) e[i][n] = c.getResource(t[i], !0)
            }

            function L(e) {
                R.fundTypeSelected = {
                    id: e
                }
            }

            function x() {
                $(), B = setInterval(function () {
                    P(!0)
                }, U)
            }

            function $() {
                B && clearInterval(B)
            }
            var B, R = this,
                N = "operationfund",
                U = f.min5,
                F = !1;
            R.tabs = [{
                id: !0
            }, {
                id: !1
            }], R.selectedTabId = R.tabs[0].id, R.fundType = [], R.fundIssuers = [], R.fundIssuerSelected = {}, R.fundTypeSelected = {
                id: 0
            }, R.fundActionText = "", R.fundFilteredIssues = [], R.fundFilteredIssuesSelected = {}, R.fundQuantity = 0, R.fundImport = 0, R.availableFunds = [], R.isQuantityOrImportDisabled = !0, R.displayResumeInfo = {}, R.disableFundsAction = !0, R.isNotificationId = "", R.customButtonFund1 = "1M", R.customButtonFund2 = "5M", R.customButtonFund3 = "10M", R.getLoadingFlagValue = b, R.getAvailableFunds = P, R.filterAvailableFunds = M, R.displayIssuerInformation = S, R.onblurQuantity = y, R.onblurImport = T, R.incrementAmount = C, R.decrementAmount = w, R.validateAmount = I, R.changeTypeSelected = L, R.registerFundsOrder = _, R.isMobile = o.mobileProperties.isMobile, n.setPropertyValue = E, n.getPropertyValue = D;
            var G = {
                    REGISTERFUND: "REGISTERFUND"
                },
                V = [{
                    id: G.REGISTERFUND,
                    value: !1
                }],
                W = !1;
            R.scrollViewHeight = "", R.isMobile = o.mobileProperties.isMobile, R.personType = 1, n.$on("$destroy", function () {
                $()
            }), n.$watch(function () {
                return o.mobileProperties.isMobile
            }, function (e, t) {
                R.isMobile = e
            }), i.$on("mobile-resize-" + n.widget.id, function (e, t) {
                t.viewHeight <= 500 && (R.scrollViewHeight = t.viewHeight - 130 + "px"), t.viewHeight > 500 && (R.scrollViewHeight = t.viewHeight - 100 + "px")
            });
            var z = [{
                sub: a.SELECTED_POSITION_FUNDS,
                unsub: void 0
            }, {
                sub: a.SELECTED_SYMBOL_FUNDS,
                unsub: void 0
            }];
            n.subscribreToNotifications && n.subscribreToNotifications(z, h, N), n.$watch(function () {
                return R.selectedTabId
            }, function (e, t) {
                if ("undefined" != typeof e) {
                    if (e === t) return;
                    R.getAvailableFunds(), e ? R.fundActionText = c.getResource("Operation_JS_MSG_FundsBuy", !0) : R.fundActionText = c.getResource("Operation_JS_MSG_FundsSell", !0)
                }
            }), n.$watch(function () {
                return R.fundTypeSelected.id
            }, function (e, t) {
                e && R.filterAvailableFunds(e)
            }), n.$watch(function () {
                return R.isNotificationId.id
            }, function (e, t) {
                e && R.filterAvailableFunds(R.fundTypeSelected.id)
            }), n.$watch(function () {
                return R.displayResumeInfo.issue
            }, function (e, t) {
                "undefined" != typeof e ? R.disableFundsAction = !1 : R.disableFundsAction = !0
            }), n.$watch(function () {
                return u.defaultContractDetail.updatedTimeStamp
            }, function (e, t) {
                e === t && F || (F = !0, P())
            }), m(), n.combined = function (e) {
                return e.issueID + " - " + e.issueName
            }
        }
        var t = "hbOperationFundCtrl";
        angular.module("app").controller(t, ["$filter", "$scope", "$rootScope", "common", "$modal", "notificationTypes", "hbLoggingSvc", "hbGlobalizationSvc", "hbCashSvc", "hbContractManagementSvc", "hbOrderSvc", "hbOperationSvc", "timeoutConfig", "hbPositionSvc", e])
    }(),
    function () {
        "use strict";

        function e(e, n, i, o, r, a, s, c, l, u, d, g, f, p, h, m, v, b) {
            function S() {
                var e = [T(), l.load("Operation")];
                o.activateController(e, t).then(function () {
                    if ("undefined" != typeof n.loadConfiguration) {
                        var e = n.loadConfiguration(ye);
                        o.$q.all([e]).then(function () {
                            C(), n.setRefreshFunction(y), n.notifyWidgetReady()
                        })
                    }
                })
            }

            function y() {
                h.refresh(), g.refresh()
            }

            function T() {
                var e = [{
                    name: "issue",
                    value: "vm.issue"
                }, {
                    name: "selectedTabId",
                    value: "vm.selectedTabId"
                }, {
                    name: "tradeMode",
                    value: "vm.tradeMode"
                }, {
                    name: "amount",
                    value: "vm.amount"
                }, {
                    name: "customButton1",
                    value: "vm.customButton1"
                }, {
                    name: "customButton2",
                    value: "vm.customButton2"
                }, {
                    name: "customButton3",
                    value: "vm.customButton3"
                }, {
                    name: "toggleDisplayL2Value",
                    value: "vm.toggleDisplayL2Value"
                }];
                "undefined" != typeof n.prepareConfiguration && n.prepareConfiguration(e, ye, n)
            }

            function C() {
                var e = ["Operation_JS_MSG_FastTrade", "Operation_JS_MSG_PutOrder"];
                fe(Se.tabs, e, "name"), n.getInformation(), Se.toggleDisplayL2Text = Se.toggleDisplayL2Value ? l.getResource("Operation_JS_MSG_CloseL2", !0) : l.getResource("Operation_JS_MSG_ShowL2", !0)
            }

            function w(e) {
                var t = "";
                switch (e) {
                    case "45":
                        t = "44";
                        break;
                    case "47":
                        t = "46";
                        break;
                    case "63":
                        t = "62";
                        break;
                    default:
                        t = e
                }
                return t
            }

            function I(e, t) {
                var n = e.name.substring(0, e.name.indexOf("."));
                switch (a[n]) {
                    case a.SEARCHED_SYMBOL:
                        Se.issue = t.symbol, C();
                        break;
                    case a.SELECTED_SYMBOL:
                        Se.issue = t.symbol, C();
                        break;
                    case a.SELECTED_BLOTTER_ORDER:
                        Se.issue = t.issue, Se.amount = t.quantity, Se.orderType = w(String(t.orderType)), C();
                        break;
                    case a.SELECTED_LEVEL_2_ROWDATA:
                        "prc" == t.colType ? Se.price = t.price : (Se.amount = t.totalVolume, Se.price = t.price);
                        break;
                    case a.SELECTED_POSITION_CAPITAL:
                        Se.issue = t.symbol, Se.amount = t.issue.position.shares, C();
                        break;
                    default:
                        c.logging(l.getResource("Operation_JS_MSG_UnhandledNotification", !0), c.loggingTypes.EXCEPTION)
                }
            }

            function P() {
                h.getPositionValue(Se.issue).then(function (e) {
                    Se.positionDetail = e
                }, function (e) {
                    c.logging(e.data, c.loggingTypes.EXCEPTION)
                })
            }

            function M() {
                return h.getAggPositionRowByInstrument(1, p.defaultContract.contractId, Se.issue).then(function (e) {
                    Se.posAggRowData = e
                })
            }

            function O() {
                Se.disableInputAmount || (parseFloat(Se.symbolDetail.hechos.body.Last) < 200 ? Se.amount = Se.amount + 100 : Se.amount = Se.amount + 5)
            }

            function E() {
                Se.disableInputAmount || (parseFloat(Se.symbolDetail.hechos.body.Last) < 200 ? Se.amount = Se.amount - 100 : Se.amount = Se.amount - 5)
            }

            function D(e, t, n, o) {
                var r = !1;
                "undefined" != typeof i.getUser && (r = !i.getUser().isReadAndWrite, r ? "" !== n ? m.updateSession(n).then(function (n) {
                    A(e), t.close()
                }, function (e) {
                    c.logging(l.getResource("Operation_JS_MSG_ConfirmTransactionProblemUpdating", !0), c.loggingTypes.EXCEPTION)
                }) : c.logging(l.getResource("Operation_JS_MSG_ConfirmTransactionTokenRequired", !0), c.loggingTypes.EXCEPTION) : (A(e, o), t.close()))
            }

            function A(e, t) {
                ge(t, !0), v.registerCapitalMarketOrder(e).then(function (i) {
                    i.data.electronicOrderId > 0 ? (c.logging(l.getResource("Operation_JS_MSG_OrdenRegistro", !0) + i.data.electronicOrderId, c.loggingTypes.SUCCESS), n.notify(a.CAPITAL_ORDER_ENTER, e)) : i.data.predespachadorId > 0 ? (c.logging(l.getResource("Operation_JS_MSG_OrdenRegistroDespachador", !0) + i.data.predespachadorId, c.loggingTypes.SUCCESS), n.notify(a.CAPITAL_ORDER_ENTER, e, !0)) : i.data.EventId && c.logging(i.data, c.loggingTypes.EXCEPTION), ge(t, !1)
                }, function (e) {
                    c.logging(e.data, c.loggingTypes.EXCEPTION), ge(t, !1)
                })
            }

            function k(e, t, n, i) {
                var o = parseFloat(e.orders[0].quantity) * parseFloat(t),
                    r = 0,
                    a = "";
                switch (L(e.orders[0].capitalOrderTypeId)) {
                    case "*isbuy":
                        a = l.getResource("Operation_JS_MSG_ConfirmTransactionCompra", !0), r = o * p.defaultContractDetail.commissionBuy / 100;
                        break;
                    case "*issell":
                        a = l.getResource("Operation_JS_MSG_ConfirmTransactionVenta", !0), r = o * p.defaultContractDetail.commissionSell / 100
                }
                var c = r * s.IVA,
                    u = n,
                    d = [];
                oe() && (se() ? "16" !== Se.orderType && ("BUY" === i ? (e.orders[1].price < e.orders[0].price && (d[0] = l.getResource("Operation_JS_MSG_OTAWarningOne", !0)), e.orders[1].SOStop > e.orders[0].price && (d[1] = l.getResource("Operation_JS_MSG_OTAWarningTwo", !0))) : (e.orders[1].price > e.orders[0].price && (d[0] = l.getResource("Operation_JS_MSG_OTAWarningThree", !0)), e.orders[1].SOStop < e.orders[0].price && (d[1] = l.getResource("Operation_JS_MSG_OTAWarningTwo", !0)))) : re() ? "16" !== Se.orderType && ("BUY" === i ? e.orders[1].price < e.orders[0].price && (d[0] = l.getResource("Operation_JS_MSG_OTAWarningOne", !0)) : e.orders[1].price > e.orders[0].price && (d[0] = l.getResource("Operation_JS_MSG_OTAWarningThree", !0))) : ae() && ("BUY" === i ? "6" !== e.orders[1].algoTradingTypeId && "7" !== e.orders[1].algoTradingTypeId || e.orders[1].stop > e.orders[0].price && (d[0] = l.getResource("Operation_JS_MSG_OTAWarningTwo", !0)) : "6" !== e.orders[1].algoTradingTypeId && "7" !== e.orders[1].algoTradingTypeId || e.orders[1].stop < e.orders[0].price && (d[0] = l.getResource("Operation_JS_MSG_OTAWarningFour", !0))));
                var g = "undefined";
                g = "BUY" == i ? (Se.symbolDetail.hechos.body.Last - e.orders[0].price) / Se.symbolDetail.hechos.body.Last * 100 : (e.orders[0].price - Se.symbolDetail.hechos.body.Last) / Se.symbolDetail.hechos.body.Last * 100;
                var f = {
                        operationTypeText: a,
                        last: Se.symbolDetail.hechos.body.Last,
                        variation: g,
                        amount: o,
                        commission: r,
                        tax: c,
                        percentage: u,
                        warnings: d
                    },
                    h = {
                        dataToBeProcessed: e,
                        dataConfirmation: f,
                        operationType: i
                    };
                H(h)
            }

            function L(e) {
                var t = [1, 16, 44, 46, 60, 62],
                    n = [8, 13, 18, 45, 47, 61, 63],
                    i = _.contains(t, e),
                    o = _.contains(n, e);
                return i ? "*isbuy" : o ? "*issell" : void 0
            }

            function x() {
                var e = {
                    contractId: p.defaultContract.contractId,
                    duration: 1,
                    orders: [{
                        issueId: Se.issue,
                        quantity: Se.symbolDetail.posturas.body[0].BuyVolume,
                        price: Se.symbolDetail.posturas.body[0].BuyPrice,
                        capitalOrderTypeId: 8,
                        instrumentType: Se.symbolDetail.instrumentType
                    }]
                };
                k(e, e.orders[0].price, void 0, Ce.SELLLIMIT)
            }

            function $() {
                var e = {
                    contractId: p.defaultContract.contractId,
                    duration: 1,
                    orders: [{
                        issueId: Se.issue,
                        quantity: Se.symbolDetail.posturas.body[0].SellVolume,
                        price: Se.symbolDetail.posturas.body[0].SellPrice,
                        capitalOrderTypeId: 1,
                        instrumentType: Se.symbolDetail.instrumentType
                    }]
                };
                k(e, e.orders[0].price, void 0, Ce.BUYLIMIT)
            }

            function B(e, t, n) {
                var i = {
                    contractId: p.defaultContract.contractId,
                    duration: 1,
                    orders: [{
                        issueId: Se.issue,
                        quantity: e,
                        price: t,
                        capitalOrderTypeId: n,
                        instrumentType: Se.symbolDetail.instrumentType
                    }]
                };
                k(i, i.orders[0].price, void 0, Ce.SELLLIMIT)
            }

            function R() {
                if (Se.amount <= 0) return void c.logging(l.getResource("Operation_JS_MSG_TitulosMayorCero", !0), c.loggingTypes.WARNING);
                var e = {
                    contractId: p.defaultContract.contractId,
                    duration: 1,
                    algoTradingTypeId: 5,
                    orders: [{
                        issueId: Se.issue,
                        quantity: Se.amount,
                        capitalOrderTypeId: 8,
                        algoTradingTypeId: 5,
                        instrumentType: Se.symbolDetail.instrumentType
                    }]
                };
                k(e, Se.symbolDetail.hechos.body.Last, void 0, Ce.SELLMKT)
            }

            function N() {
                if (Se.amount <= 0) return void c.logging(l.getResource("Operation_JS_MSG_TitulosMayorCero", !0), c.loggingTypes.WARNING);
                var e = {
                    contractId: p.defaultContract.contractId,
                    duration: 1,
                    algoTradingTypeId: 5,
                    orders: [{
                        issueId: Se.issue,
                        quantity: Se.amount,
                        capitalOrderTypeId: 1,
                        algoTradingTypeId: 5,
                        instrumentType: Se.symbolDetail.instrumentType
                    }]
                };
                k(e, Se.symbolDetail.hechos.body.Last, void 0, Ce.BUYMKT)
            }

            function U() {
                var e = j(Se.symbolDetail.posturas.body[0].BuyPrice),
                    t = {
                        contractId: p.defaultContract.contractId,
                        duration: 1,
                        orders: [{
                            issueId: Se.issue,
                            quantity: Se.amount,
                            price: e,
                            capitalOrderTypeId: 1,
                            instrumentType: Se.symbolDetail.instrumentType
                        }]
                    };
                k(t, t.orders[0].price, void 0, Ce.ADD1)
            }

            function F() {
                var e = Q(Se.symbolDetail.posturas.body[0].SellPrice),
                    t = {
                        contractId: p.defaultContract.contractId,
                        duration: 1,
                        orders: [{
                            issueId: Se.issue,
                            quantity: Se.symbolDetail.posturas.body[0].SellVolume,
                            price: e,
                            capitalOrderTypeId: 8,
                            instrumentType: Se.symbolDetail.instrumentType
                        }]
                    };
                k(t, t.orders[0].price, void 0, Ce.SUSTRACT1)
            }

            function G() {
                var e = o.$q.defer();
                return "15" === Se.OTAAlgoTradingTypeId ? (Se.OTAAlgorithmPercentageStop = !0, e.reject()) : e.resolve(), e.promise
            }

            function V() {
                var e = {
                    contractId: p.defaultContract.contractId,
                    duration: 1,
                    algoTradingTypeId: 5,
                    orders: [{
                        issueId: Se.issue,
                        quantity: Se.positionDetail.shares,
                        capitalOrderTypeId: 8,
                        algoTradingTypeId: 5,
                        instrumentType: Se.symbolDetail.instrumentType
                    }]
                };
                k(e, Se.symbolDetail.hechos.body.Last, void 0, Ce.CLOSEPOSITION)
            }

            function W() {
                var e = this;
                r.open({
                    scope: n,
                    templateUrl: "loadPartial/Blotter/CancelAll",
                    windowClass: "cancel-all",
                    controller: "cancelAllCtrl",
                    resolve: {
                        cancelAction: function () {
                            return z.bind(e)
                        }
                    }
                })
            }

            function z() {
                ge("CANCELALL", !0);
                var e = o.$q.defer();
                return v.cancelAllCapitalMarketOrders().then(function (t) {
                    ge("CANCELALL", !1), c.logging(l.getResource("Operation_JS_MSG_CancelAllOrdersCompleted", !0), c.loggingTypes.SUCCESS), e.resolve(t.data)
                }, function (t) {
                    ge("CANCELALL", !1), c.logging(t.data, c.loggingTypes.EXCEPTION), e.reject("Error" + t.ErrorMessage)
                }), e.promise
            }

            function H(e) {
                var t = "confirm-transaction";
                o.mobileProperties.isMobile && (t = "confirm-transaction-mobile"), r.open({
                    scope: n,
                    templateUrl: "loadPartial/Operation/ConfirmTransaction",
                    windowClass: t,
                    controller: "hbConfirmationTransactionCtrl",
                    resolve: {
                        parentCtrl: function () {
                            return Se
                        },
                        dataPackage: function () {
                            return e
                        }
                    }
                })
            }

            function J(e, t) {
                switch (e) {
                    case "vm.amount":
                        Se.amount = t;
                        break;
                    case "vm.tradeMode":
                        Se.tradeMode = t;
                        break;
                    case "vm.customButton1":
                        Se.customButton1 = t;
                        break;
                    case "vm.customButton2":
                        Se.customButton2 = t;
                        break;
                    case "vm.customButton3":
                        Se.customButton3 = t;
                        break;
                    case "vm.fundQuantity":
                        Se.fundQuantity = t;
                        break;
                    case "vm.customButtonFund1":
                        Se.customButtonFund1 = t;
                        break;
                    case "vm.customButtonFund2":
                        Se.customButtonFund2 = t;
                        break;
                    case "vm.customButtonFund3":
                        Se.customButtonFund3 = t
                }
            }

            function q(e) {
                switch (e) {
                    case "vm.amount":
                        return Se.amount;
                    case "vm.tradeMode":
                        return Se.tradeMode;
                    case "vm.customButton1":
                        return Se.customButton1;
                    case "vm.customButton2":
                        return Se.customButton2;
                    case "vm.customButton3":
                        return Se.customButton3;
                    case "vm.fundQuantity":
                        return Se.fundQuantity;
                    case "vm.customButtonFund1":
                        return Se.customButtonFund1;
                    case "vm.customButtonFund2":
                        return Se.customButtonFund2;
                    case "vm.customButtonFund3":
                        return Se.customButtonFund3
                }
            }

            function Y(e) {
                var t = "M";
                if (e.indexOf(t) > -1) {
                    var n = e.replace(t, "");
                    n = 1e3 * parseFloat(n), Se.amount = Se.amount + n
                } else Se.amount = parseFloat(Se.amount) + parseFloat(e)
            }

            function X(e) {
                for (var t = 0; t < we.length; t++)
                    if (we[t].id === e) return we[t].value;
                return !1
            }

            function j(e) {
                var t = parseFloat(e);
                return t = t < 1 ? (t + .001).toFixed(3) : (t + .01).toFixed(2)
            }

            function Q(e) {
                var t = parseFloat(e);
                return t <= 1 ? (t = (t - .001).toFixed(3), t < 0 && (t = 0)) : t = (t - .01).toFixed(2), t
            }

            function K(e) {
                var t = parseFloat(e);
                return t = (t + .01).toFixed(2)
            }

            function Z(e) {
                var t = parseFloat(e);
                return t = (t - .01).toFixed(2)
            }

            function ee() {
                var e = 1;
                switch (Se.orderType) {
                    case "44":
                        e = 44;
                        break;
                    case "46":
                        e = 46;
                        break;
                    case "62":
                        e = 62
                }
                ie(e, Ce.BUY)
            }

            function te() {
                var e = 8;
                switch (Se.orderType) {
                    case "44":
                        e = 45;
                        break;
                    case "46":
                        e = 47;
                        break;
                    case "62":
                        e = 63
                }
                ie(e, Ce.SELL)
            }

            function ne() {
                ie(13, Ce.SHORTSELLING)
            }

            function ie(e, t) {
                if (de()) return !1;
                var n = {
                    contractId: p.defaultContract.contractId,
                    duration: Se.duration,
                    algoTradingTypeId: void 0,
                    orders: [{
                        issueId: Se.issue,
                        quantity: Se.amount,
                        price: void 0,
                        capitalOrderTypeId: e,
                        instrumentType: Se.symbolDetail.instrumentType,
                        algoTradingTypeId: void 0,
                        triggerPrice: void 0,
                        pegOffsetValue: void 0,
                        maxFloor: void 0,
                        stop: void 0,
                        stopPercentage: void 0
                    }]
                };
                switch (Se.orderType) {
                    case "1":
                        n.orders[0].price = Se.price, oe() && (n.algoTradingTypeId = 20, n.orders[1] = le(e));
                        break;
                    case "2":
                        n.algoTradingTypeId = 5, n.orders[0].algoTradingTypeId = 5;
                        break;
                    case "3":
                        n.orders[0].stop = Se.stopPrice, n.algoTradingTypeId = 6, n.orders[0].algoTradingTypeId = 6;
                        break;
                    case "4":
                        n.orders[0].stop = Se.stopPrice, n.orders[0].price = Se.price, n.algoTradingTypeId = 7, n.orders[0].algoTradingTypeId = 7;
                        break;
                    case "5":
                        n.orders[0].stopPercentage = Se.percentage, n.algoTradingTypeId = 15, n.orders[0].algoTradingTypeId = 15;
                        break;
                    case "16":
                        var i = Se.orderType;
                        ce(e, n, i);
                        break;
                    case "46":
                    case "44":
                        n.orders[0].triggerPrice = Se.price, n.orders[0].pegOffsetValue = Se.pegOffsetValue;
                        break;
                    case "62":
                        n.orders[0].triggerPrice = Se.price, n.orders[0].pegOffsetValue = Se.pegOffsetValue, n.orders[0].maxFloor = Se.partiality
                }
                return k(n, n.orders[0].price, void 0, t), !0
            }

            function oe() {
                return !(!Se.OTALimitOrder && !Se.OTAAlgorithmOrder)
            }

            function re() {
                return Se.OTALimitOrder === !0
            }

            function ae() {
                return !!Se.OTAAlgorithmOrder
            }

            function se() {
                return !(!Se.OTALimitOrder || !Se.OTAAlgorithmOrder)
            }

            function ce(e, t, n) {
                if (8 === e) {
                    var i = void 0,
                        o = Se.limitPercentage ? Math.round(Se.symbolDetail.hechos.body.Last * (1 + Se.OTALimitprice / 100) * 100) / 100 : Se.OTALimitprice,
                        r = Se.OTAAlgoTradingTypeId;
                    if ("6" === r) var a = Se.OTAAlgorithmPercentageStop ? Math.round(Se.symbolDetail.hechos.body.Last * (1 + Se.OTAAlgorithmPriceStop / 100) * 100) / 100 : Se.OTAAlgorithmPriceStop,
                        s = void 0,
                        c = void 0;
                    else if ("7" === r) var s = Se.OTAAlgorithmPercentageLimit ? Math.round(Se.symbolDetail.hechos.body.Last * (1 + Se.OTAAlgorithPriceLimit / 100) * 100) / 100 : Se.OTAAlgorithPriceLimit,
                        a = Se.OTAAlgorithmPercentageStop ? Math.round(Se.symbolDetail.hechos.body.Last * (1 + Se.OTAAlgorithmPriceStop / 100) * 100) / 100 : Se.OTAAlgorithmPriceStop,
                        c = void 0;
                    else if ("15" === r) var c = Se.OTAAlgorithmPercentageStop ? Se.OTAAlgorithmPriceStop : Math.round(Se.symbolDetail.hechos.body.Last * (1 + Se.OTAAlgorithmPriceStop / 100) * 100) / 100,
                        a = void 0,
                        s = void 0
                } else {
                    var r = void 0,
                        s = Se.limitPercentage ? Math.round(Se.symbolDetail.hechos.body.Last * (1 + Se.OTALimitprice / 100) * 100) / 100 : Se.OTALimitprice,
                        i = Se.OTAAlgoTradingTypeId;
                    if ("6" === i) var l = Se.OTAAlgorithmPercentageStop ? Math.round(Se.symbolDetail.hechos.body.Last * (1 + Se.OTAAlgorithmPriceStop / 100) * 100) / 100 : Se.OTAAlgorithmPriceStop,
                        o = void 0,
                        u = void 0;
                    else if ("7" === i) var o = Se.OTAAlgorithmPercentageLimit ? Math.round(Se.symbolDetail.hechos.body.Last * (1 + Se.OTAAlgorithPriceLimit / 100) * 100) / 100 : Se.OTAAlgorithPriceLimit,
                        l = Se.OTAAlgorithmPercentageStop ? Math.round(Se.symbolDetail.hechos.body.Last * (1 + Se.OTAAlgorithmPriceStop / 100) * 100) / 100 : Se.OTAAlgorithmPriceStop,
                        u = void 0;
                    else if ("15" === i) var u = Se.OTAAlgorithmPercentageStop ? Se.OTAAlgorithmPriceStop : Math.round(Se.symbolDetail.hechos.body.Last * (1 + Se.OTAAlgorithmPriceStop / 100) * 100) / 100,
                        l = void 0,
                        o = void 0
                }
                t.algoTradingTypeId = Se.orderType, t.orders[0].instrumentType = Se.symbolDetail.instrumentType, t.orders[0].algoTradingTypeId = n, t.orders[0].stop = l, t.orders[0].price = o, t.orders[0].stopPercentage = u, t.orders[0].FOAlgoTradingTypeId = i, t.orders[0].SOAlgoTradingTypeId = r, t.orders[0].SOPrice = s, t.orders[0].SOStop = a, t.orders[0].SOStopPercentage = c
            }

            function le(e) {
                var t = void 0,
                    n = void 0,
                    i = void 0,
                    o = void 0,
                    r = void 0,
                    a = void 0,
                    s = void 0,
                    c = void 0,
                    l = void 0,
                    a = void 0;
                if (se()) i = 16, o = 1 === e ? 8 : 1, 1 === e ? (t = Se.limitPercentage ? Math.round(Se.price * (1 + Se.OTALimitprice / 100) * 100) / 100 : Se.OTALimitprice, a = Se.OTAAlgoTradingTypeId, "6" === a ? (s = Se.OTAAlgorithmPercentageStop ? Math.round(t * (1 - Se.OTAAlgorithmPriceStop / 100) * 100) / 100 : Se.OTAAlgorithmPriceStop, c = void 0, l = void 0) : "7" === a ? (s = Se.OTAAlgorithmPercentageStop ? Math.round(t * (1 - Se.OTAAlgorithmPriceStop / 100) * 100) / 100 : Se.OTAAlgorithmPriceStop, c = Se.OTAAlgorithmPercentageLimit ? Math.round(s * (1 - Se.OTAAlgorithPriceLimit / 100) * 100) / 100 : Se.OTAAlgorithPriceLimit, l = void 0) : "15" === a && (l = Se.OTAAlgorithmPriceStop, s = void 0, c = void 0)) : (c = Se.limitPercentage ? Math.round(Se.price * (1 - Se.OTALimitprice / 100) * 100) / 100 : Se.OTALimitprice, r = Se.OTAAlgoTradingTypeId, "6" === r ? (n = Se.OTAAlgorithmPercentageStop ? Math.round(c * (1 + Se.OTAAlgorithmPriceStop / 100) * 100) / 100 : Se.OTAAlgorithmPriceStop, t = void 0, u = void 0) : "7" === r ? (t = Se.OTAAlgorithmPercentageLimit ? Math.round(Se.price * (1 + Se.OTAAlgorithPriceLimit / 100) * 100) / 100 : Se.OTAAlgorithPriceLimit, n = Se.OTAAlgorithmPercentageStop ? Math.round(t * (1 + Se.OTAAlgorithmPriceStop / 100) * 100) / 100 : Se.OTAAlgorithmPriceStop, u = void 0) : "15" === r && (u = Se.OTAAlgorithmPriceStop, n = void 0, t = void 0));
                else if (ae()) {
                    if (i = Se.OTAAlgoTradingTypeId, o = 1 === e ? 8 : 1, "6" === i) n = 1 === e ? Se.OTAAlgorithmPercentageStop ? Math.round(Se.price * (1 + Se.OTAAlgorithmPriceStop / 100) * 100) / 100 : Se.OTAAlgorithmPriceStop : Se.OTAAlgorithmPercentageStop ? Math.round(Se.price * (1 - Se.OTAAlgorithmPriceStop / 100) * 100) / 100 : Se.OTAAlgorithmPriceStop;
                    else if ("7" === i) t = 1 === e ? Se.OTAAlgorithmPercentageLimit ? Math.round(Se.price * (1 + Se.OTAAlgorithPriceLimit / 100) * 100) / 100 : Se.OTAAlgorithPriceLimit : Se.OTAAlgorithmPercentageLimit ? Math.round(Se.price * (1 - Se.OTAAlgorithPriceLimit / 100) * 100) / 100 : Se.OTAAlgorithPriceLimit, n = 1 === e ? Se.OTAAlgorithmPercentageStop ? Math.round(t * (1 - Se.OTAAlgorithmPriceStop / 100) * 100) / 100 : Se.OTAAlgorithmPriceStop : Se.OTAAlgorithmPercentageStop ? Math.round(t * (1 + Se.OTAAlgorithmPriceStop / 100) * 100) / 100 : Se.OTAAlgorithmPriceStop;
                    else if ("15" === i) var u = Se.OTAAlgorithmPriceStop
                } else if (re()) {
                    t = 1 === e ? Se.limitPercentage ? Math.round(Se.price * (1 + Se.OTALimitprice / 100) * 100) / 100 : Se.OTALimitprice : Se.limitPercentage ? Math.round(Se.price * (1 - Se.OTALimitprice / 100) * 100) / 100 : Se.OTALimitprice;
                    var o = 1 === e ? 8 : 1
                }
                var d = {
                    issueId: Se.issue,
                    quantity: Se.amount,
                    price: t,
                    capitalOrderTypeId: o,
                    instrumentType: Se.symbolDetail.instrumentType,
                    algoTradingTypeId: i,
                    triggerPrice: void 0,
                    pegOffsetValue: void 0,
                    maxFloor: void 0,
                    stop: n,
                    stopPercentage: u,
                    FOAlgoTradingTypeId: r,
                    SOAlgoTradingTypeId: a,
                    SOPrice: c,
                    SOStop: s,
                    SOStopPercentage: l
                };
                return d
            }

            function ue() {
                if ("1" === Se.orderType || "44" === Se.orderType || "46" === Se.orderType || "62" === Se.orderType || "4" === Se.orderType) switch (Se.buySellButtonType) {
                    case 0:
                        Se.price = void 0 === Se.symbolDetail.posturas ? 0 : Se.symbolDetail.posturas.body[0].BuyPrice;
                        break;
                    case 1:
                        Se.price = void 0 === Se.symbolDetail.posturas ? 0 : Se.symbolDetail.posturas.body[0].BuyPrice + .01;
                        break;
                    case 2:
                        Se.price = void 0 === Se.symbolDetail.posturas ? 0 : Se.symbolDetail.posturas.body[0].SellPrice;
                        break;
                    case 3:
                        Se.price = void 0 === Se.symbolDetail.posturas ? 0 : Se.symbolDetail.posturas.body[0].SellPrice - .01;
                        break;
                    case 4:
                        Se.price = void 0 === Se.symbolDetail.posturas ? 0 : Se.symbolDetail.hechos.body.Last
                } else Se.price = void 0 === Se.symbolDetail.posturas ? 0 : Se.symbolDetail.hechos.body.Last;
                "4" === Se.orderType ? Se.stopPrice = Se.price : Se.stopPrice = void 0 === Se.symbolDetail.posturas ? 0 : Se.symbolDetail.hechos.body.Last, Se.partiality = 0, Se.percentage = 0, Se.pegOffsetValue = 1
            }

            function de() {
                var e = !1,
                    t = "";
                switch (Se.amount <= 0 && (t += l.getResource("Operation_JS_MSG_TitulosMayorCero", !0), e = !0), Se.orderType) {
                    case "1":
                    case "46":
                    case "44":
                    case "62":
                        Se.price <= 0 && (t += l.getResource("Operation_JS_MSG_PrecioMayorCero", !0), e = !0);
                        break;
                    case "3":
                        Se.stopPrice <= 0 && (t += l.getResource("Operation_JS_MSG_PrecioTopMayorCero", !0), e = !0);
                        break;
                    case "4":
                        (Se.stopPrice <= 0 || Se.price <= 0) && (t += l.getResource("Operation_JS_MSG_PrecioTopLimitMayorCero", !0), e = !0);
                        break;
                    case "5":
                        Se.percentage <= 0 && (t += l.getResource("Operation_JS_MSG_PorcentajeMayorCero", !0), e = !0)
                }
                return e && c.logging(t, c.loggingTypes.WARNING),
                    e
            }

            function ge(e, t) {
                for (var n = 0; n < we.length; n++) we[n].id === e && (we[n].value = t)
            }

            function fe(e, t, n) {
                for (var i = 0, o = t.length; i < o; i++) e[i][n] = l.getResource(t[i], !0)
            }

            function pe() {
                Se.toggleDisplayL2Value = !Se.toggleDisplayL2Value, Se.toggleDisplayL2Text = Se.toggleDisplayL2Value ? l.getResource("Operation_JS_MSG_CloseL2", !0) : l.getResource("Operation_JS_MSG_ShowL2", !0)
            }

            function he() {
                Se.issue && (ve(), u.getL2(Se.issue).then(function (e) {
                    angular.extend(Se.L2s, e.data), me(), Se.isProfundityAvailable = !0
                }, function (e) {
                    Se.isProfundityAvailable = !1
                }))
            }

            function me() {
                var e = {
                    symbol: Se.issue,
                    topic: "posturas"
                };
                Se.solaceSymbol.posturas = g.getSymbol(e), Se.solaceSymbol.posturas && (Te && Te(), Te = n.$watch("vm.solaceSymbol.posturas.lastTick", function (e, t) {
                    if (e !== t)
                        for (var n = Se.solaceSymbol.posturas.body, i = 0, o = Se.L2s.length; i < o; i++) {
                            var r = Se.L2s[i],
                                a = n[i];
                            r.buyNumOrders = a.BuyOrdersNum, r.buyPrice = a.BuyPrice, r.buyVolume = a.BuyVolume, r.sellNumOrders = a.SellOrdersNum, r.sellPrice = a.SellPrice, r.sellVolume = a.SellVolume
                        }
                }))
            }

            function ve() {
                Se.solaceSymbol.posturas && (Se.solaceSymbol.posturas = null, Te && Te())
            }

            function be(e, t, n) {
                Se.priceType = t, Se.index = n;
                for (var i = 0, o = 0; o < n + 1; o++) i += "sell" === t ? Se.L2s[o].sellVolume : Se.L2s[o].buyVolume;
                var r = {
                    price: e.buyPrice,
                    symbol: Se.issueL2,
                    totalVolume: i
                };
                "sell" === t && (r.price = e.sellPrice), r.orderTypeId = "sell" == t ? 8 : 1, B(r.totalVolume, r.price, r.orderTypeId)
            }
            var Se = this,
                ye = "operationcapital";
            Se.issue = "", Se.price = 0, Se.maxPrice = 0, Se.orderType = "1", Se.duration = "1", Se.amount = 0, Se.customButton1 = "1M", Se.customButton2 = "5M", Se.customButton3 = "10M", Se.tradeMode = 0, Se.symbolDetail = "", Se.positionDetail = [], Se.dataPackage = {}, Se.ivaData = "", Se.disableButtonBuy = !0, Se.disableButtonSell = !0, Se.disableButtonBuyMkt = !0, Se.disableButtonSellMkt = !0, Se.disableButtonAdd1 = !0, Se.disableButtonSustract1 = !0, Se.disableButtonClose = !0, Se.disableButtonCloseAll = !0, Se.disableInputAmount = !0, Se.disableButtonCustom1 = !0, Se.disableButtonCustom2 = !0, Se.disableButtonCustom3 = !0, Se.sellLimitLoading = !1, Se.buyLimitLoading = !1, Se.buyMktLoading = !1, Se.sellMktLoading = !1, Se.add1Loading = !1, Se.sustract1Loading = !1, Se.closePositionLoading = !1, Se.buySellButtonType = 0, Se.selectedPercent = !0, Se.stopPrice = 0, Se.partiality = 0, Se.percentage = 0, Se.tradeShortSell = p.defaultContractDetail.tradeShortSell, Se.toggleDisplayL2Value = !1, Se.toggleDisplayL2Text = "", Se.pegOffsetValue = 1, Se.incrementAmount = O, Se.decrementAmount = E, Se.sellLimit = x, Se.buyLimit = $, Se.buyMkt = N, Se.sellMkt = R, Se.add1 = U, Se.sustract1 = F, n.setPropertyValue = J, n.getPropertyValue = q, Se.validateAmount = Y, Se.registerCapitalOrder = D, Se.closePosition = V, Se.cancelAll = z, Se.displayCancelAll = W, Se.getLoadingFlagValue = X, Se.shortSelling = ne, Se.buy = ee, Se.sell = te, Se.toggleDisplayL2 = pe, Se.selectIssue = be, Se.tabs = [{
                id: 0
            }, {
                id: 1
            }], Se.selectedTabId = Se.tabs[0].id;
            var Te;
            Se.solaceSymbol = {
                posturas: null
            }, Se.L2s = [], Se.isProfundityAvailable = !1, Se.posAggRowData = [], Se.scrollViewHeight = "", Se.isMobile = o.mobileProperties.isMobile, n.$watch(function () {
                return o.mobileProperties.isMobile
            }, function (e, t) {
                Se.isMobile = e
            }), i.$on("mobile-resize-" + n.widget.id, function (e, t) {
                t.viewHeight <= 500 && (Se.scrollViewHeight = t.viewHeight - 130 + "px"), t.viewHeight > 500 && (Se.scrollViewHeight = t.viewHeight - 50 + "px")
            }), n.notifyIssue = function () {
                var e = {
                    emitter: n.widget.name,
                    symbol: Se.issue
                };
                n.notify(a.SEARCHED_SYMBOL, e)
            }, Se.limitPercentage = !0, Se.OTALimitOrder = !1, Se.OTALimitprice = 0, Se.OTAAlgorithmOrder = !1, Se.OTAAlgorithmPercentageStop = !0, Se.OTAAlgoTradingTypeId = "6", Se.OTAAlgorithmPriceStop = 0, Se.OTAAlgorithmPercentageLimit = !0, Se.OTAAlgorithPriceLimit = 0, Se.blockToggleSwitch = G;
            var Ce = {
                    BUY: "BUY",
                    SELL: "SELL",
                    SHORTSELLING: "SHORTSELLING",
                    SELLLIMIT: "SELLLIMIT",
                    BUYLIMIT: "BUYLIMIT",
                    BUYMKT: "BUYMKT",
                    SELLMKT: "SELLMKT",
                    ADD1: "ADD1",
                    SUSTRACT1: "SUSTRACT1",
                    CLOSEPOSITION: "CLOSEPOSITION",
                    CANCELALL: "CANCELALL"
                },
                we = [{
                    id: Ce.BUY,
                    value: !1
                }, {
                    id: Ce.SELL,
                    value: !1
                }, {
                    id: Ce.SHORTSELLING,
                    value: !1
                }, {
                    id: Ce.SELLLIMIT,
                    value: !1
                }, {
                    id: Ce.BUYLIMIT,
                    value: !1
                }, {
                    id: Ce.BUYMKT,
                    value: !1
                }, {
                    id: Ce.SELLMKT,
                    value: !1
                }, {
                    id: Ce.ADD1,
                    value: !1
                }, {
                    id: Ce.SUSTRACT1,
                    value: !1
                }, {
                    id: Ce.CLOSEPOSITION,
                    value: !1
                }, {
                    id: Ce.CANCELALL,
                    value: !1
                }],
                Ie = [{
                    sub: a.SELECTED_SYMBOL,
                    unsub: void 0
                }, {
                    sub: a.SELECTED_BLOTTER_ORDER,
                    unsub: void 0
                }, {
                    sub: a.SELECTED_LEVEL_2_SYMBOL,
                    unsub: void 0
                }, {
                    sub: a.SELECTED_LEVEL_2_ROWDATA,
                    unsub: void 0
                }, {
                    sub: a.SELECTED_POSITION_CAPITAL,
                    unsub: void 0
                }, {
                    sub: a.SEARCHED_SYMBOL,
                    unsub: void 0
                }];
            n.subscribreToNotifications && n.subscribreToNotifications(Ie, I, ye), n.$watch("vm.OTAAlgoTradingTypeId", function (e, t) {
                "" !== e && e !== t && "15" === Se.OTAAlgoTradingTypeId && (Se.OTAAlgorithmPercentageStop = !0)
            }), n.$watch("vm.symbolDetail.symbol", function (e, t) {
                "undefined" == typeof e || "" == e ? (Se.disableButtonSell = !0, Se.disableButtonBuyMkt = !0, Se.disableButtonAdd1 = !0, Se.disableButtonCloseAll = !0, Se.disableButtonCustom1 = !0, Se.disableButtonCustom2 = !0, Se.disableButtonCustom3 = !0, Se.disableInputAmount = !0, Se.disableButtonBuy = !0, Se.disableButtonSellMkt = !0, Se.disableButtonSustract1 = !0, Se.disableButtonClose = !0) : (Se.disableButtonSell = !1, Se.disableButtonBuyMkt = !1, Se.disableButtonAdd1 = !1, Se.disableButtonCloseAll = !1, Se.disableButtonCustom1 = !1, Se.disableButtonCustom2 = !1, Se.disableButtonCustom3 = !1, Se.disableInputAmount = !1, Se.disableButtonBuy = !1, Se.disableButtonSellMkt = !1, Se.disableButtonSustract1 = !1, Se.disableButtonClose = !1, ue())
            }), n.$watch("vm.positionDetail", function (e, t) {
                "undefined" == typeof Se.positionDetail.shares || 0 === Se.positionDetail.shares ? Se.disableButtonClose = !0 : Se.disableButtonClose = !1
            }), n.$watch("vm.symbolDetail", function (e, t) {
                Se.symbolDetail && "" !== Se.symbolDetail && ("undefined" == typeof Se.symbolDetail.posturas.body[0].BuyPrice || 0 === Se.symbolDetail.posturas.body[0].BuyPrice ? Se.disableButtonBuy = !0 : Se.disableButtonBuy = !1, "undefined" == typeof Se.symbolDetail.posturas.body[0].SellPrice || 0 === Se.symbolDetail.posturas.body[0].SellPrice ? Se.disableButtonSell = !0 : Se.disableButtonSell = !1)
            }, !0), n.$watch("vm.orderType", function (e, t) {
                e !== t && ("44" !== Se.orderType && "46" !== Se.orderType && "62" !== Se.orderType || (Se.duration = "1"), Se.OTALimitOrder = !1, Se.OTAAlgorithmOrder = !1, ue())
            }), n.$on("monitordrop", function (e, t) {
                Se.selectedTabId = Se.tabs[1].id, Se.issue = t.symbol, C()
            }), n.$on("level2drop", function (e, t) {
                Se.selectedTabId = Se.tabs[1].id, Se.issue = t.symbol, C()
            }), S(), n.getInformation = function () {
                if (Se.symbolDetail = "", Se.positionDetail = "", Se.ivaData = "", Se.issue) {
                    var e = g.serviceInitialized();
                    return P(), M(), he(), o.$q.all([e]).then(function (e) {
                        return Se.symbolDetail = g.getSymbol({
                            symbol: Se.issue
                        }), e
                    })
                }
            }, Se.incrementPrice = function () {
                Se.price = j(Se.price)
            }, Se.decrementPrice = function () {
                Se.price = Q(Se.price)
            }, Se.incrementStopPrice = function () {
                Se.stopPrice = j(Se.stopPrice)
            }, Se.decrementStopPrice = function () {
                Se.stopPrice = Q(Se.stopPrice)
            }, Se.incrementBid = function () {
                Se.pegOffsetValue++
            }, Se.incrementOTALimitprice = function () {
                Se.OTALimitprice = K(Se.OTALimitprice)
            }, Se.decrementOTALimitprice = function () {
                Se.OTALimitprice = Z(Se.OTALimitprice)
            }, Se.incrementAlgorithmPriceStop = function () {
                Se.OTAAlgorithmPriceStop = K(Se.OTAAlgorithmPriceStop)
            }, Se.decrementAlgorithmPriceStop = function () {
                Se.OTAAlgorithmPriceStop = Z(Se.OTAAlgorithmPriceStop)
            }, Se.incrementOTAAlgorithPriceLimit = function () {
                Se.OTAAlgorithPriceLimit = K(Se.OTAAlgorithPriceLimit)
            }, Se.decrementOTAAlgorithPriceLimit = function () {
                Se.OTAAlgorithPriceLimit = Z(Se.OTAAlgorithPriceLimit)
            }, Se.decrementBid = function () {
                Se.pegOffsetValue > 1 && Se.pegOffsetValue--
            }, Se.incrementPartiality = function () {
                var e = parseFloat(Se.price),
                    t = parseFloat(Se.partiality);
                e < 200 ? (t += 100, Se.partiality = t.toFixed()) : (t += 5, Se.partiality = t.toFixed())
            }, Se.decrementPartiality = function () {
                var e = parseFloat(Se.price),
                    t = parseFloat(Se.partiality);
                e <= 200 ? (t -= 100, Se.partiality = t.toFixed(), t < 0 && (Se.partiality = 0)) : (t -= 5, Se.partiality = t.toFixed(2))
            }
        }
        var t = "hbOperationCapitalCtrl";
        angular.module("app").controller(t, ["$filter", "$scope", "$rootScope", "common", "$modal", "notificationTypes", "hbOperationSvc", "hbLoggingSvc", "hbGlobalizationSvc", "hbMarketSvc", "hbDragNDropHelperSvc", "hbSolaceSvc", "hbPortfolioSvc", "hbContractManagementSvc", "hbPositionSvc", "hbSecuritySvc", "hbOrderSvc", "hbCashSvc", e])
    }(),
    function () {
        "use strict";

        function e(e, t, n, i) {
            function o() {
                i.slideSession()
            }
            var r = this;
            r.timeLeftToExpire = "";
            var a = null;
            r.slideSession = o, r.isWriteSession = i.getSessionStatus() === i.SessionStatus.ExpiringWrite, t.$on("$destroy", function () {
                clearInterval(a)
            }), e.$on("log-Out", function () {
                t.$dismiss("logging out")
            }), a = setInterval(function () {
                var e = i.getSecondsToExpire();
                e < 0 && (e = 0);
                var t = ~~(e / 60),
                    n = ~~(e % 60);
                t < 10 && (t = "0" + t), n < 10 && (n = "0" + n), r.timeLeftToExpire = t + ":" + n
            }, 1e3)
        }
        angular.module("app").controller("hbSlideSessionCtrl", ["$rootScope", "$scope", "$interval", "hbSessionSliderSvc", e])
    }(),
    function () {
        "use strict";

        function e(e, t, n, i, o, r) {
            function a() {
                s()
            }

            function s() {
                u.windowHeight = window.innerHeight, u.windowWidth = window.innerWidth
            }

            function c() {
                t.defaults.headers.common.GBMDigitalIdentityUser && t.defaults.headers.common.GBMDigitalIdentityApp && t.defaults.headers.common.GBMDigitalIdentityHash && t.defaults.headers.common["X-Forwarded-For"] && i.getUserConfiguration().then(function (e) {
                    d = e
                })
            }

            function l(t) {
                t && "y" === t.bar && (e.pageYScrollPosition = t.top)
            }
            var u = this,
                d = {};
            u.title = "GBM Homebroker", u.theme = "dark", u.windowHeight = 0, u.windowWidth = 0, u.notifyPositionChanged = l, u.scrollSpeed = "firefox" === o() ? 20 : 1, u.height = n.innerHeight + "px", u.loggedIn = r.loggedIn(), u.enableYScroll = "scroll", e.pageYScrollPosition = 0, e.$watch(function () {
                return r.loggedIn()
            }, function (e) {
                u.enableYScroll = e ? "hidden" : "scroll", u.loggedIn = e
            }), window.onresize = function (t) {
                e.$apply(function () {
                    u.height = n.innerHeight + "px"
                })
            }, e.$watch(function () {
                return $("body").height()
            }, function (e) {
                e < n.innerHeight ? u.enableYScroll = "hidden" : u.enableYScroll = u.loggedIn ? "hidden" : "scroll"
            }), e.$watch(function () {
                return d
            }, function (e, t) {
                e && e.themeName && (u.theme = e.themeName.toLowerCase())
            }, !0), e.$watch(function () {
                return t.defaults.headers.common.GBMDigitalIdentityUser
            }, function (e, t) {
                c()
            }), e.$watch(function () {
                return t.defaults.headers.common.GBMDigitalIdentityApp
            }, function (e, t) {
                c()
            }), e.$watch(function () {
                return t.defaults.headers.common.GBMDigitalIdentityHash
            }, function (e, t) {
                c()
            }), e.$watch(function () {
                return t.defaults.headers.common["X-Forwarded-For"]
            }, function (e, t) {
                c()
            }), e.$watch(function () {
                return window.innerHeight
            }, function () {
                s()
            }), e.$watch(function () {
                return window.innerWidth
            }, function () {
                s()
            }), a()
        }
        angular.module("app").controller("hbPageCtrl", ["$scope", "$http", "$window", "hbUserAppConfigSvc", "hbBrowserSvc", "hbSecuritySvc", e])
    }(),
    function () {
        "use strict";

        function e(e, t, n, i, o, r, a) {
            function s() {}

            function c() {
                return o.logout().then(function () {
                    a.widgets.active.length = 0, mySlidebars.slidebars.close(), t.path("/login")
                })
            }

            function l() {
                u.isOpeningSettingsWindow = !0;
                var t = r.open({
                    scope: e,
                    templateUrl: "loadPartial/Dashboard/Settings",
                    controller: "hbSettingsCtrl as cfg"
                });
                t.opened.then(function () {
                    u.isOpeningSettingsWindow = !1
                })
            }
            var u = this;
            u.contracts = i.contracts, u.defaultContract = i.defaultContract, u.disconnectUser = c, u.showSettingsWindow = l, s()
        }
        angular.module("app").controller("hbRightNavCtrl", ["$scope", "$location", "$anchorScroll", "hbContractManagementSvc", "hbSecuritySvc", "$modal", "hbDashboardSvc", e])
    }(),
    function () {
        "use strict";

        function e(e, t, n, i, o, r, a, s) {
            function c(e, t) {
                var n = r.servicesUri + "api/appmanagement/getUserDashboards",
                    i = {
                        count: 0,
                        mustRetry: !0
                    };
                return a(n, "POST", {
                    width: e,
                    height: t
                }, i)
            }

            function l(e) {
                var t = r.servicesUri + "api/appmanagement/getUserDashboardWidgets/" + e,
                    n = {
                        count: 0,
                        mustRetry: !0
                    };
                return a(t, "get", null, n)
            }

            function u() {
                var e = r.servicesUri + "api/appmanagement/getUserWidgetTypes",
                    t = {
                        count: 0,
                        mustRetry: !0
                    };
                return a(e, "get", null, t)
            }

            function d(e) {
                var t = r.servicesUri + "api/appmanagement/getWidgetsInUserDashBoard/" + e,
                    n = {
                        count: 0,
                        mustRetry: !0
                    };
                return a(t, "get", null, n)
            }

            function g(e) {
                var t = r.servicesUri + "api/appmanagement/getWidgetConfiguration/" + e,
                    n = {
                        count: 0,
                        mustRetry: !0
                    };
                return a(t, "get", null, n)
            }

            function f(e) {
                var t = r.servicesUri + "api/appmanagement/deleteUserDashBoardWidget/" + e;
                return a(t, "get", null)
            }

            function p() {
                var e = r.servicesUri + "api/AppManagement/GetSolaceIndexesTopic",
                    t = {
                        count: 0,
                        mustRetry: !0
                    };
                return a(e, "post", null, t)
            }

            function h() {
                var e = r.servicesUri + "api/AppManagement/GetUserAppConfiguration",
                    t = {
                        count: 0,
                        mustRetry: !0
                    };
                return a(e, "get", null, t)
            }

            function m(e) {
                var t = {
                        isRealTime: !0,
                        issic: !0,
                        employeeId: s.getUser().user,
                        contract: e,
                        orderStatus: 0,
                        alert: 5,
                        newsCategory: 6,
                        newsSeverity: 7,
                        instruments: ["*"]
                    },
                    n = r.servicesUri + "api/AppManagement/GetSolaceOrderTopic",
                    i = {
                        count: 0,
                        mustRetry: !0
                    };
                return a(n, "post", t, i)
            }

            function v() {
                var e = r.servicesUri + "api/AppManagement/GetUserDefaultConfiguration",
                    t = {
                        count: 0,
                        mustRetry: !0
                    };
                return a(e, "get", null, t)
            }

            function b(e) {
                var t = r.servicesUri + "api/appmanagement/addUserDashboard/";
                return a(t, "post", e)
            }

            function S(e) {
                var t = r.servicesUri + "api/appmanagement/addUserDashBoardWidget/";
                return a(t, "post", e)
            }

            function y(e, t) {
                var n = r.servicesUri + "api/appmanagement/updateWidgetsInUserDashBoard/" + e;
                return a(n, "post", t)
            }

            function T(e, n) {
                function i() {
                    var e = (new Date).getTime();
                    return e - N < 3e3 ? void setTimeout(i, 4e3) : void a(r.servicesUri + "api/appmanagement/updateWidgetsConfiguration", "post", U).then(function (e) {
                        var t = R.updateWidgetConfiguration;
                        return R.updateWidgetConfiguration = null, t.resolve(), e
                    })
                }
                N = (new Date).getTime(), R.updateWidgetConfiguration || (U.length = 0);
                for (var o = !1, s = 0, c = U.length; s < c; s++) U[s].widgetId === e && (U[s].configuration = n, o = !0);
                if (!o) {
                    var l = {
                        widgetId: e,
                        configuration: n
                    };
                    U.push(l)
                }
                return R.updateWidgetConfiguration ? R.updateWidgetConfiguration.promise : (R.updateWidgetConfiguration = t.defer(), setTimeout(i, 4e3), R.updateWidgetConfiguration.promise)
            }

            function C(e) {
                var t = r.servicesUri + "api/appmanagement/deleteUserDashboard/" + e;
                return a(t, "get")
            }

            function w(e) {
                var t = r.servicesUri + "api/appmanagement/updateUserDashboard";
                return a(t, "post", e)
            }

            function I(e) {
                var t = {
                        isRealTime: !0,
                        issic: !!e,
                        instruments: ["*"]
                    },
                    n = r.servicesUri + "api/AppManagement/GetSolaceDataTopic";
                return a(n, "post", t)
            }

            function _(e) {
                var t = {
                        isRealTime: !0,
                        issic: !!e,
                        instruments: ["*"]
                    },
                    n = r.servicesUri + "api/AppManagement/GetSolaceLTopic/" + i.user.hasLevel2;
                return a(n, "post", t)
            }

            function P(e) {
                var t = r.servicesUri + "api/appmanagement/UpdateUserDefaultConfiguration";
                return a(t, "post", e)
            }

            function M() {
                if (B) return t.when(B);
                if (R.getCapitalMarketOperationTime) return R.getCapitalMarketOperationTime.promise;
                var e = R.getCapitalMarketOperationTime = t.defer();
                return a(r.servicesUri + "api/AppManagement/GetCapitalMarketOperationTime", "get", null).then(function (t) {
                    B = {
                        startTime: new Date(t.data.startTime),
                        endTime: new Date(t.data.endTime)
                    }, e.resolve(B)
                })["finally"](function () {
                    R.getCapitalMarketOperationTime = void 0
                }), e.promise
            }

            function O(e, t) {
                var n = r.servicesUri + "api/appmanagement/AddMarketChartConfiguration";
                return a(n, "post", {
                    description: e,
                    configuration: t
                })
            }

            function E() {
                var e = r.servicesUri + "api/appmanagement/GetMarketChartConfiguration";
                return a(e, "get")
            }

            function D(e) {
                var t = r.servicesUri + "api/appmanagement/UpdateMarketChartConfiguration";
                return a(t, "post", e)
            }

            function A(e) {
                var t = r.servicesUri + "api/appmanagement/DeleteMarketChartConfiguration";
                return a(t, "post", {
                    request: e
                }).then(function (t) {
                    return s.$emit("ChartConfigurationDeleted", e), t
                })
            }

            function k() {
                var e = r.servicesUri + "api/appmanagement/GetAgreementType";
                return a(e, "get")
            }

            function L(e) {
                var t = r.servicesUri + "api/appmanagement/GetAgreementLog";
                return a(t, "post", e)
            }

            function x(e) {
                var t = r.servicesUri + "api/appmanagement/AddApplicationAgreementLog";
                return a(t, "post", e)
            }

            function $(e) {
                var t = r.servicesUri + "api/appmanagement/GetCommisionsBadges";
                return a(t, "post", {
                    GlobalContract: e
                })
            }
            var B = null,
                R = {},
                N = 0,
                U = [];
            s.$watch(function () {
                return i.loggedIn()
            }, function (e, t) {
                t && !e && (R = {}, B = null)
            });
            var F = {
                getUserDashboards: c,
                getUserDashboardWidgets: l,
                getUserWidgetTypes: u,
                getWidgetsInUserDashBoard: d,
                getWidgetConfiguration: g,
                addUserDashboard: b,
                addUserDashBoardWidget: S,
                updateWidgetsInUserDashBoard: y,
                updateWidgetConfiguration: T,
                deleteUserDashboard: C,
                deleteUserDashBoardWidget: f,
                getSolaceDataTopic: I,
                getSolaceLTopic: _,
                getSolaceIndexesTopic: p,
                updateUserDashboard: w,
                getSolaceCapitalMarketOrderTopic: m,
                getUserDefaultConfiguration: v,
                updateUserDefaultConfiguration: P,
                getCapitalMarketOperationTime: M,
                getUserAppConfiguration: h,
                addMarketChartConfiguration: O,
                getMarketChartConfiguration: E,
                deleteMarketChartConfiguration: A,
                updateMarketChartConfiguration: D,
                getAgreementType: k,
                getAgreementLog: L,
                addApplicationAgreementLog: x,
                getCommisionsBadges: $
            };
            return F
        }
        var t = "hbAppManagementSvc";
        angular.module("app").factory(t, ["$http", "$q", "$sessionStorage", "hbSecuritySvc", "common", "urlServices", "serviceManager", "$rootScope", e])
    }(),
    function () {
        "use strict";

        function e(e, t, n, i, o, r) {
            function a() {
                var t = e.$q.defer();
                return l().then(function (e) {
                    angular.copy(e.data.filter(function (e) {
                        return e.isEnabled
                    }), v.contracts), v.contracts.length > 0 ? t.resolve(g) : t.reject("Error: No cuenta con un contrato activo")
                }, function (e) {
                    t.reject("Error" + e.message)
                }), t.promise
            }

            function s(t) {
                var i = n("filter")(g, {
                    contractId: t
                });
                return 0 === i.length ? angular.copy(g[0], f) : angular.copy(i[0], f), u(f.contractId).then(function (t) {
                    var n = !!t.data && !!t.data.clientType && t.clientType > 1;
                    angular.copy(t.data, p);
                    var i = e.$q.reject(!1),
                        a = e.$q.reject(!1);
                    return p && (i = o.getCommisionsBadges(n).then(function (e) {
                        return e.data && e.data.length > 0 && (p.commissions = e.data), e.data
                    }), a = r.getCapitalTransactionsAmountByRange(v.defaultContract.contractId, n).then(function (e) {
                        return p.capitalTransactions = e.data, e.data
                    })), e.$q.all([i, a])["finally"](function () {
                        p.updatedTimeStamp = Date.now()
                    })
                })
            }

            function c() {
                var t = e.$q.defer();
                if (m) t.resolve(h);
                else
                    for (var n = !1, i = v.contracts, o = i.length, r = 0, a = i.length; r < a; r++) u(i[r].contractId).then(function (e) {
                        n = null === e.data ? n : n || e.data.tradeSIC, o--, 0 === o && (h = n, m = !0, t.resolve(n))
                    }, function (e) {
                        t.reject(e)
                    });
                return t.promise
            }

            function l() {
                var e = {
                    count: 0,
                    mustRetry: !0
                };
                return i(t.servicesUri + "api/ContractManagement/GetContractsBP", "get", null, e)
            }

            function u(e) {
                var n = {
                    count: 0,
                    mustRetry: !0
                };
                return i(t.servicesUri + "api/ContractManagement/GetContract", "post", {
                    contractId: e
                }, n)
            }

            function d(e) {
                var n = {
                    count: 0,
                    mustRetry: !0
                };
                return i(t.servicesUri + "api/ContractManagement/GetContracts", "post", {
                    request: e
                }, n)
            }
            var g = (e.$q.defer(), []),
                f = {},
                p = {},
                h = !1,
                m = !1,
                v = {
                    loadData: a,
                    contracts: g,
                    defaultContract: f,
                    defaultContractDetail: p,
                    setDefaultContract: s,
                    isUserSicEnabled: c,
                    getContract: u,
                    getContracts: d
                };
            return v
        }
        var t = "hbContractManagementSvc";
        angular.module("app").factory(t, ["common", "urlServices", "$filter", "serviceManager", "hbAppManagementSvc", "hbPortfolioSvc", e])
    }(),
    function () {
        "use strict";

        function e(e, t, n, i) {
            function o() {
                var t = e.$q.defer();
                return s().then(function (e) {
                    angular.copy(e.data, u.cultures), t.resolve(c)
                }, function (e) {
                    t.reject("Error" + e.message)
                }), t.promise
            }

            function r(e) {
                var t = n("filter")(c, {
                    cultureId: e
                });
                0 === t.length ? angular.copy(c[0], l) : angular.copy(t[0], l)
            }

            function a(e) {
                var t = n("filter")(c, {
                    cultureId: e
                });
                return t
            }

            function s() {
                var e = {
                    count: 0,
                    mustRetry: !0
                };
                return i(t.servicesUri + "api/AppManagement/GetCultures", "get", null, e)
            }
            var c = (e.$q.defer(), []),
                l = {},
                u = {
                    loadData: o,
                    cultures: c,
                    defaultCulture: l,
                    setDefaultCulture: r,
                    findCulture: a
                };
            return u
        }
        var t = "hbCultureManagementSvc";
        angular.module("app").factory(t, ["common", "urlServices", "$filter", "serviceManager", e])
    }(),
    function () {
        "use strict";

        function e(e, t, n, i, o, r) {
            function a(e) {
                var t = {
                    isOnLine: !0,
                    instrumentType: 0
                };
                return c(t, e)
            }

            function s(e) {
                var t = {
                    isOnLine: !0,
                    instrumentType: 2
                };
                return c(t, e)
            }

            function c(e, t) {
                var n = {
                    count: 0,
                    mustRetry: !1,
                    isTimer: t
                };
                return o(i.servicesUri + "api/Market/GetMarketPriceMonitorDetail", "post", e, n)
            }

            function l() {
                var e = {
                    isOnLine: !0,
                    instrumentType: -1
                };
                return o(i.servicesUri + "api/Market/GetMarketPriceMonitorDetailOptimized", "post", e)
            }

            function u(e) {
                return E["getL2." + e] ? E["getL2." + e] : E["getL2." + e] = o(i.servicesUri + "api/Market/GetL2MarketData/" + e, "get", null).then(function (e) {
                    return t.user.hasLevel2 || (e.data = e.data.splice(0, 1)), e
                })["finally"](function () {
                    E["getL2." + e] = null
                })
            }

            function d(e, t) {
                return E["getParticipation." + e + "." + t] ? E["getParticipation." + e + "." + t] : E["getParticipation." + e + "." + t] = o(i.servicesUri + "api/Market/GetCompanySharePercentage/" + e, "post", {
                    IsOnLine: t
                })["finally"](function () {
                    E["getParticipation." + e + "." + t] = null
                })
            }

            function g(e) {
                return E["mdMarketData." + e] ? E["mdMarketData." + e] : E["mdMarketData." + e] = o(i.servicesUri + "api/Market/GetMDMarketData/" + e, "get", null)["finally"](function () {
                    E["mdMarketData." + e] = null
                })
            }

            function f(e, t, n) {
                if (E["getIssueIntraday." + e + "." + t]) return E["getIssueIntraday." + e + "." + t];
                var r = {
                    count: 0,
                    mustRetry: !1,
                    isTimer: n
                };
                return E["getIssueIntraday." + e + "." + t] = o(i.servicesUri + "api/Market/GetInstrumentPricesIntradayPPP/" + e, "post", {
                    IsOnLine: t
                }, r)["finally"](function () {
                    E["getIssueIntraday." + e + "." + t] = null
                })
            }

            function p(e, t, n, r, a) {
                var s = "getInstrumentPricesByRange." + e + "." + t + "." + n + "." + r;
                if (E[s]) return E[s];
                var c = {
                    count: 0,
                    mustRetry: !1,
                    isTimer: a
                };
                return E[s] = o(i.servicesUri + "api/Market/GetInstrumentPricesByRange/" + e, "post", {
                    IsOnLine: r,
                    startDate: t,
                    endDate: n
                }, c)["finally"](function () {
                    E[s] = null
                })
            }

            function h(e, t, n, r, a, s) {
                var c = "getCapitalMarketHistoricPrice." + e + "." + n + "." + r + "." + a;
                if (E[c]) return E[c];
                var l = {
                    count: 0,
                    mustRetry: !1,
                    isTimer: s
                };
                return E[c] = o(i.servicesUri + "api/Market/GetCapitalMarketHistoricPrice/", "post", {
                    issueId: e,
                    instrumentType: t,
                    IsOnLine: a,
                    startDate: n,
                    endDate: r
                }, l)["finally"](function () {
                    E[c] = null
                })
            }

            function m(e, t, n) {
                if (E["getInstrumentPricesIntradayComplete." + e + "." + t]) return E["getInstrumentPricesIntradayComplete." + e + "." + t];
                var r = {
                    count: 0,
                    mustRetry: !1,
                    isTimer: n
                };
                return E["getInstrumentPricesIntradayComplete." + e + "." + t] = o(i.servicesUri + "api/Market/GetInstrumentPricesIntradayComplete/" + e, "post", {
                    IsOnLine: !0,
                    request: t
                }, r)["finally"](function () {
                    E["getInstrumentPricesIntradayComplete." + e + "." + t] = null
                })
            }

            function v(e) {
                return o(i.servicesUri + "api/Market/GetCommoditiesByType/", "post", {
                    IsOnLine: e
                })
            }

            function b(e, t) {
                return o(i.servicesUri + "api/Market/GetIndexIntraday/" + e, "post", {
                    IsOnLine: t
                })
            }

            function S(e) {
                return o(i.servicesUri + "api/Market/SearchIssue/" + e, "get")
            }

            function y(e, t) {
                var n = {
                    count: 0,
                    mustRetry: !1,
                    isTimer: t
                };
                return o(i.servicesUri + "api/Market/GetCommoditiesByType/", "post", e, n)
            }

            function T() {
                return o(i.servicesUri + "api/Market/GetWatchList/", "GET")
            }

            function C(e) {
                return o(i.servicesUri + "api/Market/GetWatchListDetail/", "POST", e)
            }

            function w(e) {
                return o(i.servicesUri + "api/Market/UpdateUserWatchList/", "POST", e)
            }

            function I(e) {
                return o(i.servicesUri + "api/Market/AddWatchList/", "POST", e)
            }

            function _(e) {
                return o(i.servicesUri + "api/Market/DeleteWatchList/?watchlistid=" + e, "GET")
            }

            function P(e, t) {
                return o(i.servicesUri + "api/Market/AddIssueWatchList/" + e + "/" + t, "GET")
            }

            function M(e, t) {
                return o(i.servicesUri + "api/Market/DeleteIssueWatchList/" + e + "/" + t, "GET")
            }
            var O = "hbMarketSvc";
            r.init(O);
            var E = {};
            e.$watch(function () {
                return t.loggedIn()
            }, function (e, t) {
                (t && !e || !t && e) && (E = {})
            });
            var D = {
                getNationalMarketData: a,
                getSICMarketData: s,
                getL2: u,
                getParticipation: d,
                mdMarketData: g,
                getIssueIntraday: f,
                getInstrumentPricesByRange: p,
                getCommoditiesForInternet: v,
                getIndexIntraday: b,
                searchIssue: S,
                getCommoditiesByType: y,
                getMarketPriceMonitorDetailOptimize: l,
                getWatchList: T,
                getWatchListDetail: C,
                addWatchList: I,
                updateUserWatchList: w,
                deleteWatchList: _,
                addIssueWatchList: P,
                deleteIssueWatchList: M,
                getInstrumentPricesIntradayComplete: m,
                getCapitalMarketHistoricPrice: h
            };
            return D
        }
        var t = "hbMarketSvc";
        angular.module("app").factory(t, ["$rootScope", "hbSecuritySvc", "common", "urlServices", "serviceManager", "hbCacheSvc", e])
    }(),
    function () {
        "use strict";

        function e(e, t, n, i) {
            function o(e, n, o) {
                var r = {
                    count: 0,
                    mustRetry: !1,
                    isTimer: o
                };
                return i(t.servicesUri + "api/Operation/GetBlotterCapitalMarket/", "post", {
                    instrumentTypes: n,
                    ordersId: null,
                    processDate: (new Date).toISO8601String(),
                    accountId: e,
                    contractId: e
                }, r)
            }

            function r(e, n, o, r) {
                var a = {
                    count: 0,
                    mustRetry: !1,
                    isTimer: r
                };
                return i(t.servicesUri + "api/Operation/GetBlotterCapitalMarket/", "post", {
                    instrumentTypes: n,
                    ordersId: o,
                    processDate: (new Date).toISO8601String(),
                    accountId: e,
                    contractId: e
                }, a)
            }

            function a(e, n, o) {
                return i(t.servicesUri + "api/Operation/CancelOrder", "post", {
                    ElectronicOrderId: e,
                    IsPredispatchOrder: n,
                    vigencia: o
                })
            }

            function s(e) {
                return i(t.servicesUri + "api/Operation/CancelAllOrdersCapitalMarket/", "post", {
                    contractId: e
                })
            }

            function c(e) {
                return i(t.servicesUri + "api/Operation/RegisterCapitalOrder", "post", e)
            }

            function l() {
                return i(t.servicesUri + "api/Operation/GetIVA", "get", null)
            }

            function u() {
                var t = e.$q.defer();
                return l().then(function (e) {
                    y.IVA = parseFloat(e.data.response).toFixed(2), t.resolve(e.data)
                }, function (e) {
                    t.reject("Error" + e.message)
                }), t.promise
            }

            function d(e, n) {
                var o = {
                    count: 0,
                    mustRetry: !1,
                    isTimer: n
                };
                return i(t.servicesUri + "api/Operation/GetAvailableFundsForTrade/" + e, "get", null, o)
            }

            function g(e) {
                return i(t.servicesUri + "api/Operation/RegisterWithdrawal", "post", e)
            }

            function f(e, n) {
                return i(t.servicesUri + "api/Operation/GetSellingPower/", "post", {
                    contractId: e
                }, {
                    isTimer: n
                })
            }

            function p(e) {
                return i(t.servicesUri + "api/Operation/RegisterFundsOrder", "post", e)
            }

            function h(e, n) {
                return i(t.servicesUri + "api/Operation/GetMarginHB", "post", {
                    contractId: e
                }, {
                    isTimer: n
                })
            }

            function m(e, n) {
                return i(t.servicesUri + "api/Operation/GetCapitalMarketContractRisk", "post", {
                    contractId: e
                }, {
                    isTimer: n
                })
            }

            function v(e) {
                var o = n.defaultContract.contractId;
                return i(t.servicesUri + "api/Operation/GetContractProperties", "post", {
                    contractId: o
                }, {
                    isTimer: e
                })
            }
            var b = 0,
                S = {
                    Stock: [0, 2],
                    Funds: [27, 28],
                    Cash: [-1]
                },
                y = {
                    getCapitalMarketOrders: o,
                    getCapitalMarketOrder: r,
                    cancelCapitalMarketOrder: a,
                    registerCapitalMarketOrder: c,
                    loadIVA: u,
                    IVA: b,
                    cancelAllCapitalMarketOrders: s,
                    getAvailableFundsForTrade: d,
                    registerWithdrawal: g,
                    registerFundsOrder: p,
                    getMarginHB: h,
                    getCapitalMarketContractRisk: m,
                    getSellingPower: f,
                    InstrumentTypes: S,
                    getContractProperties: v
                };
            return y
        }
        var t = "hbOperationSvc";
        angular.module("app").factory(t, ["common", "urlServices", "hbContractManagementSvc", "serviceManager", e])
    }(),
    function () {
        "use strict";

        function e(e, t, n, i) {
            function o(e) {
                return i(n.servicesUri + "api/Portfolio/GetTransactions/", "post", e)
            }

            function r(e, t) {
                return i(n.servicesUri + "api/Portfolio/GetPosition/", "post", {
                    contractId: e
                }, {
                    isTimer: t
                })
            }

            function a(e, t) {
                var o = moment().startOf("month"),
                    r = moment();
                return i(n.servicesUri + "api/Portfolio/GetCapitalTransactionsAmountByRange/", "post", {
                    contractId: e,
                    startDate: o,
                    endDate: r,
                    globalContract: t
                })
            }
            var s = {
                getTransactions: o,
                getPosition: r,
                getCapitalTransactionsAmountByRange: a
            };
            return s
        }
        var t = "hbPortfolioSvc";
        angular.module("app").factory(t, ["hbSecuritySvc", "common", "urlServices", "serviceManager", e])
    }(),
    function () {
        "use strict";

        function e(e, t, n) {
            function i() {
                return n(t.servicesUri + "api/Research/GetInteractiveDataUser", "post", null)
            }
            var o = {
                getInteractiveDataUser: i
            };
            return o
        }
        var t = "hbResearchSvc";
        angular.module("app").factory(t, ["common", "urlServices", "serviceManager", e])
    }(),
    function () {
        "use strict";

        function e(e, t, n) {
            function i() {
                return n(t.servicesUri + "api/User/GetUser", "get", null)
            }
            var o = {
                getUser: i
            };
            return o
        }
        var t = "hbUserSvc";
        angular.module("app").factory(t, ["common", "urlServices", "serviceManager", e])
    }(),
    function () {
        "use strict";

        function e(e, t, n, i, o, r, a, s) {
            function c() {
                return M.user
            }

            function l() {
                var e = n.$q.defer();
                return _ ? (e.resolve(M.user), e.promise) : I.promise
            }

            function u(t) {
                return e.post(i.servicesUri + "api/Security/GetUserKey", {
                    user: t
                }).then(function (e) {
                    return r.logging("Got user key", r.loggingTypes.DEBUG), e.data
                })
            }

            function d(t, o, a) {
                var s = n.$q.defer(),
                    c = !!a;
                return u(t).then(function (t) {
                    e.post(i.servicesUri + "api/Security/SignIn/" + c, {
                        user: t.key,
                        password: o,
                        token: a,
                        deviceType: "1"
                    }).then(function (e) {
                        return r.logging("User authenticated", r.loggingTypes.DEBUG), S(e.data), v().then(function () {
                            s.resolve(e.data)
                        }), e
                    }, function (e) {
                        r.logging(e.data, r.loggingTypes.EXCEPTION), s.reject(e)
                    })
                }, function (e) {
                    r.logging(e.data, r.loggingTypes.EXCEPTION), s.reject(e)
                }), s.promise
            }

            function g(t) {
                var o = n.$q.defer();
                return e.post(i.servicesUri + "api/Security/SignInAuthToken", {
                    token: t,
                    deviceType: "1"
                }).then(function (e) {
                    return r.logging("Session updated.", r.loggingTypes.SUCCESS), S(e.data), v().then(function () {
                        o.resolve(e.data)
                    }), e
                }, function (e) {
                    r.logging(e.data, r.loggingTypes.EXCEPTION), o.reject(e)
                }), o.promise
            }

            function f() {
                return !!(M.user && M.user.hasOwnProperty("name") && e.defaults.headers.common.GBMDigitalIdentityApp && e.defaults.headers.common["X-Forwarded-For"])
            }

            function p() {
                if (!P && f()) {
                    P = !0;
                    var t = e.get(i.servicesUri + "api/Security/SignOut", {}).then(function (e) {
                            r.logging("signOut() completed...", r.loggingTypes.DEBUG)
                        }, function (e) {}),
                        o = e.post("loadPartial/Account/CloseSession", {}).then(function (e) {
                            r.logging("closeSession() completed...", r.loggingTypes.DEBUG)
                        }, function (e) {});
                    return n.$q.all([t, o]).then(function (e) {
                        return r.logging("signOut() && closeSession() loaded successfully...", r.loggingTypes.DEBUG), r.logging("User logout", r.loggingTypes.SUCCESS), e
                    })["finally"](function (t) {
                        P = !1, angular.copy({}, M.user), delete e.defaults.headers.common.GBMDigitalIdentityUser, delete e.defaults.headers.common.GBMDigitalIdentityHash, a.dismissAll("logout")
                    })
                }
            }

            function h(t, n, o) {
                return e.post(i.servicesUri + "api/Security/ReSyncTokenSignIn", {
                    usernameToken: t,
                    firstToken: n,
                    secondToken: o
                })
            }

            function m() {
                return e.post("loadPartial/Account/StartSession", {
                    name: M.user.name,
                    user: M.user.user,
                    sessionid: M.user.hash,
                    hasLevel2: M.user.hasLevel2,
                    isReadAndWrite: M.user.isReadAndWrite,
                    applicationid: e.defaults.headers.common.GBMDigitalIdentityApp,
                    ipaddress: e.defaults.headers.common["X-Forwarded-For"],
                    timeExpiresReadSession: M.user.timeExpiresReadSession,
                    timeExpiresOperationSession: M.user.timeExpiresOperationSession
                })["catch"](function (e) {
                    r.logging("Error creating user session on server", r.loggingTypes.EXCEPTION)
                })
            }

            function v() {
                return m().then(function (e) {
                    return s.slideSession(), e
                })
            }

            function b() {
                var e = n.$q.defer();
                if ("undefined" != typeof currentSession) {
                    if (w.toString().length > 0) {
                        var t = JSON.parse(currentSession),
                            i = {
                                user: t.User,
                                name: t.Name,
                                hash: t.SessionId,
                                hasLevel2: t.HasLevel2,
                                isReadAndWrite: t.IsReadAndWrite,
                                timeExpiresReadSession: t.TimeExpiresReadSession,
                                timeExpiresOperationSession: t.TimeExpiresOperationSession
                            };
                        S(i)
                    }
                } else e.reject("No session found"), y();
                return e.promise
            }

            function S(t) {
                angular.extend(M.user, t), e.defaults.headers.common.GBMDigitalIdentityUser = t.user, e.defaults.headers.common.GBMDigitalIdentityHash = t.hash, s.setSessionLength(t.timeExpiresReadSession, t.timeExpiresOperationSession)
            }

            function y() {
                var t = e.post("loadPartial/Account/CloseSession", {}).then(function (e) {
                    r.logging("closeSession() completed...", r.loggingTypes.DEBUG)
                }, function (e) {
                    r.logging("Error closing user session on server.", r.loggingTypes.EXCEPTION)
                });
                return n.$q.all([t]).then(function (t) {
                    return r.logging("closeSession() loaded successfully...", r.loggingTypes.DEBUG), angular.copy({}, M.user), delete e.defaults.headers.common.GBMDigitalIdentityUser, delete e.defaults.headers.common.GBMDigitalIdentityHash, a.dismissAll("logout"), o.path("/login"), t
                })
            }

            function T(t) {
                return e.post(i.servicesUri + "api/Security/ResetPassword", {
                    user: t
                })
            }

            function C(t, n) {
                return e.post(i.servicesUri + "api/Security/UpdatePassword", {
                    user: w.user,
                    password: t,
                    newPassword: n
                })
            }
            var w = {},
                I = n.$q.defer(),
                _ = !1,
                P = !1,
                M = {
                    user: w,
                    login: d,
                    logout: p,
                    loggedIn: f,
                    resetUser: y,
                    bootstrap: l,
                    updateSession: g,
                    reSyncToken: h,
                    serviceInitialized: I.promise,
                    recoverPassword: T,
                    updatePassword: C
                };
            t.getUser = c, t.$on("log-Out", function () {
                p()
            });
            var O = b().then(function (e) {
                return I.resolve(e), e
            }, function (e) {
                I.reject(e)
            });
            return O["finally"](function () {
                _ = !0
            }), t.$on("sessionSlider.sessionExpired", function () {
                y()
            }), t.$on("sessionSlider.writeSessionExpired", function () {
                w.isReadAndWrite = !1, g("")
            }), M
        }
        var t = "hbSecuritySvc";
        angular.module("app").factory(t, ["$http", "$rootScope", "common", "urlServices", "$location", "hbLoggingSvc", "$modalStack", "hbSessionSliderSvc", e])
    }(),
    function () {
        "use strict";

        function e(e, t, n, i, o, r, a, s, c, l, u) {
            function d() {
                var e = n.$q.defer();
                t.post("loadPartial/Account/GetApplicationData", {}).then(function (n) {
                    t.defaults.headers.common.GBMDigitalIdentityApp = JSON.parse(n.data), c.logging("getApplicationData() completed.", c.loggingTypes.DEBUG), t.get(i.servicesUri + "api/Utilities/GetPublicIP", {}).then(function (n) {
                        t.defaults.headers.common["X-Forwarded-For"] = n.data.response, c.logging("getPublicIP() completed.", c.loggingTypes.DEBUG), e.resolve(n.data.response)
                    }, function (e) {
                        c.logging("getPublicIP() exception contacting service.", c.loggingTypes.EXCEPTION)
                    })
                }, function (e) {
                    c.logging("getApplicationData() exception contacting service.", c.loggingTypes.EXCEPTION)
                });
                return n.$q.all([e.promise]).then(function (e) {
                    return c.logging("getApplicationData() && getPublicIP() loaded successfully.", c.loggingTypes.DEBUG),
                        e
                })
            }

            function g() {
                if (s.loggedIn()) {
                    var e = r.loadData().then(function (e) {
                            c.logging("getContracts() completed.", c.loggingTypes.DEBUG)
                        }, function (e) {
                            c.logging("getContracts() exception contacting service.", c.loggingTypes.EXCEPTION)
                        }),
                        t = l.loadData().then(function (e) {
                            c.logging("getCultures() completed.", c.loggingTypes.DEBUG)
                        }, function (e) {
                            c.logging("getCultures() exception contacting service.", c.loggingTypes.EXCEPTION)
                        });
                    return n.$q.all([e, t]).then(function (e) {
                        c.logging("getContracts() & getCultures() loaded successfully.", c.loggingTypes.DEBUG);
                        var t = a.initialize().then(function (e) {
                                c.logging("getUserAppConfiguration() completed.", c.loggingTypes.DEBUG)
                            }, function (e) {
                                c.logging("getUserAppConfiguration() exception contacting service.", c.loggingTypes.EXCEPTION)
                            }),
                            i = u.loadIVA().then(function () {
                                c.logging("loadIVA() completed.", c.loggingTypes.DEBUG)
                            }, function (e) {
                                c.logging("loadIVA() exception contacting service.", c.loggingTypes.EXCEPTION)
                            });
                        return n.$q.all([t, i]).then(function (e) {
                            c.logging("getUserAppConfiguration() && loadIVA() loaded successfully.", c.loggingTypes.DEBUG)
                        })
                    })
                }
            }
            n.$q.defer();
            e.appletsWorking = [];
            var f = {
                initialize: d,
                loadcontracts: g
            };
            return f
        }
        var t = "hbLocalDataSvc";
        angular.module("app").factory(t, ["$rootScope", "$http", "common", "urlServices", "$location", "hbContractManagementSvc", "hbUserAppConfigSvc", "hbSecuritySvc", "hbLoggingSvc", "hbCultureManagementSvc", "hbOperationSvc", e])
    }(),
    function () {
        "use strict";

        function e(e, t, n, i, o, r, a, s, c, l, u, d) {
            function g() {
                oe = [], X.length = 0, j.length = 0, Q.length = 0;
                for (var e in K) K[e] = null;
                for (var e in Z) Z[e] = null;
                for (var e in ee) ee[e] = null;
                var t = p(),
                    n = h();
                i.$q.all([t, n]).then(function (e) {
                    y().then(function (e) {
                        return Y = !0, J.resolve(!0), e
                    }, function (e) {
                        J.reject(e), console.error("Get Init Market Data", e), s.logging("Error retrieving initial market data snapshot", s.loggingTypes.EXCEPTION)
                    })
                })
            }

            function f() {
                return Y ? i.$q.when(!0) : J.promise
            }

            function p() {
                var e = r.getSolaceDataTopic(!1).then(function (e) {
                        var t = {
                            serviceToken: "token",
                            serviceTopic: e.data.dataServiceAgent,
                            subscriptionTopic: e.data.dataSubscription[0],
                            correlationKey: {
                                TP: this,
                                Symbol: "*"
                            }
                        };
                        oe.push(t);
                        var t = {
                            serviceToken: "token",
                            serviceTopic: e.data.aggServiceAgent,
                            subscriptionTopic: e.data.aggSubscription[0],
                            correlationKey: {
                                TP: this,
                                Symbol: "*"
                            }
                        };
                        return oe.push(t), e
                    }),
                    t = r.getSolaceDataTopic(!0).then(function (e) {
                        var t = {
                            serviceToken: "token",
                            serviceTopic: e.data.dataServiceAgent,
                            subscriptionTopic: e.data.dataSubscription[0],
                            correlationKey: {
                                TP: this,
                                Symbol: "*"
                            }
                        };
                        oe.push(t);
                        var t = {
                            serviceToken: "token",
                            serviceTopic: e.data.aggServiceAgent,
                            subscriptionTopic: e.data.aggSubscription[0],
                            correlationKey: {
                                TP: this,
                                Symbol: "*"
                            }
                        };
                        return oe.push(t), e
                    }),
                    n = r.getSolaceIndexesTopic().then(function (e) {
                        var t = {
                            serviceToken: "token",
                            serviceTopic: e.data.serviceAgent,
                            subscriptionTopic: e.data.suscription[0],
                            correlationKey: {
                                TP: this,
                                Symbol: "*"
                            }
                        };
                        return oe.push(t), e
                    });
                return i.$q.all([e, t, n])
            }

            function h() {
                var e = r.getSolaceLTopic(!1).then(function (e) {
                        var t = {
                            serviceToken: "token",
                            serviceTopic: e.data.dataServiceAgent,
                            subscriptionTopic: e.data.dataSubscription[0],
                            correlationKey: {
                                TP: this,
                                Symbol: "*"
                            }
                        };
                        return oe.push(t), e
                    }),
                    t = r.getSolaceLTopic(!0).then(function (e) {
                        var t = {
                            serviceToken: "token",
                            serviceTopic: e.data.dataServiceAgent,
                            subscriptionTopic: e.data.dataSubscription[0],
                            correlationKey: {
                                TP: this,
                                Symbol: "*"
                            }
                        };
                        return oe.push(t), e
                    });
                return i.$q.all([e, t])
            }

            function m() {
                var e = new solace.SessionProperties;
                e.url = a.url, e.password = a.password, e.vpnName = a.vpnName, e.userName = a.userName, e.transportProtocol = solace.TransportProtocol.WS_BINARY, V = new SolHB.ClientWrapper({
                    solaceSessionProperties: e,
                    eventCallback: P,
                    messageCallback: M,
                    connectRetryCount: a.connectRetryCount,
                    subscriptionTimeout: a.subscriptionTimeout,
                    subscriptionRetryCount: a.subscriptionRetryCount,
                    subscriptionRetryInterval: a.subscriptionRetryInterval
                })
            }

            function v() {
                V || m(), q || (V.connect(), angular.forEach(oe, function (e, t) {
                    V.subscribe(e)
                }), q = !0)
            }

            function b() {
                q && V && (angular.forEach(oe, function (e, t) {
                    V.unsubscribe(e)
                }), V.disconnect(), Y = !1, q = !1)
            }

            function S() {
                return q
            }

            function y(e) {
                G();
                var t = o.getNationalMarketData(e).then(function (e) {
                        return T(e.data, X, K), e
                    }),
                    n = o.getSICMarketData(e).then(function (e) {
                        return T(e.data, j, Z), e
                    });
                return R(e), i.$q.all([t, n])["finally"](function () {
                    F()
                })
            }

            function T(e, t, n) {
                var i = new Date,
                    o = i.getHours(),
                    r = i.getMinutes(),
                    a = i.getSeconds();
                o = o.toString().length < 2 ? "0" + o : o, r = r.toString().length < 2 ? "0" + r : r, a = a.toString().length < 2 ? "0" + a : a;
                var s = o + ":" + r + ":" + a + "." + i.getMilliseconds();
                for (var c in e) {
                    var l = e[c],
                        u = {
                            symbol: l.issueID,
                            body: {
                                StockSeries: l.issueID,
                                changeAvg: l.percentageChange || 0,
                                Last: (l.lastPrice > 0 ? l.lastPrice : l.closePrice) || 0,
                                aggVolume: l.aggregatedVolume || 0,
                                operationVolume: l.aggregatedVolume || 0,
                                maxPrice: l.maxPrice || 0,
                                minPrice: l.minPrice || 0,
                                ppp: l.ppp,
                                openPrice: l.openPrice || 0,
                                averageVolume6M: l.averageVolume6M,
                                lastWithOutLot: (l.lastPrice > 0 ? l.lastPrice : l.closePrice) || 0,
                                Time: s,
                                ipcParticipationRate: l.ipcParticipationRate || 0,
                                isMarketDataRefresh: !0
                            },
                            benchmarks: l.benchmarks,
                            closePrice: l.closePrice
                        },
                        d = {
                            body: [{
                                BuyPrice: l.bidPrice || 0,
                                BuyVolume: l.bidVolume || 0,
                                BuyOrdersNum: 0,
                                SellPrice: l.askPrice || 0,
                                SellVolume: l.askVolume || 0,
                                SellOrdersNum: 0
                            }]
                        };
                    if (n && n[l.issueID]) {
                        var g = t[n[l.issueID] - 1];
                        g.lastTick = s, g.hechos.closePrice = u.closePrice, angular.extend(g.hechos.body, u.body)
                    } else n[l.issueID] = t.push({
                        symbol: l.issueID,
                        issueName: l.issueName,
                        hechos: u,
                        posturas: d,
                        lastTick: s
                    })
                }
            }

            function C() {
                return X
            }

            function w() {
                return j
            }

            function I() {
                return te
            }

            function _(e) {
                var t;
                return e && e.symbol ? (K.hasOwnProperty(e.symbol.toUpperCase()) ? (t = X[K[e.symbol.toUpperCase()] - 1], t.instrumentType = 0) : Z.hasOwnProperty(e.symbol.toUpperCase()) && (t = j[Z[e.symbol.toUpperCase()] - 1], t.instrumentType = 2), t && ("posturas" === e.topic ? t = t.posturas : "hechos" === e.topic && (t = t.hechos)), t) : t
            }

            function P(e) {}

            function M(e) {
                var t = "AGG",
                    n = e.getBodyJson();
                switch (e.getTopic().indexOf("AGG") < 0 && (t = B(n)), t) {
                    case "P":
                        A(n, X, K);
                        break;
                    case "DP":
                        A(n, j, Z);
                        break;
                    case "O1":
                        k(e, n, X, K);
                        break;
                    case "D2":
                        k(e, n, j, Z);
                        break;
                    case "Indices2":
                        E(n, Q, ee);
                        break;
                    case "AGG":
                        x(e, n);
                        break;
                    case "ORD":
                        $(n);
                        break;
                    default:
                        s.logging("Unknown message type received from solace: " + t, s.loggingTypes.EXCEPTION)
                }
            }

            function O(e) {
                if (ee[e]) return Q[ee[e] - 1]
            }

            function E(e, t, n) {
                var i = angular.copy(e);
                D(i, t, n)
            }

            function D(e, t, n) {
                var i = e;
                if (void 0 !== i.GBL_INDEX) {
                    var o = {
                        index: i.GBL_INDEX,
                        body: {
                            date: i.Timestamp,
                            percentageChange: i.ChangePercent,
                            price: i.Value,
                            volume: i.Volume,
                            unitChange: i.ChangeUnit,
                            lastValue: i.Value,
                            type: i.Type
                        }
                    };
                    if (n[i.GBL_INDEX]) {
                        var i = t[n[i.GBL_INDEX] - 1].body;
                        i.date = o.body.date, i.percentageChange = o.body.percentageChange, i.price = o.body.price, i.volume = o.body.volume, i.unitChange = o.body.unitChange, i.lastValue = o.body.lastValue
                    } else n[i.GBL_INDEX] = t.push(o)
                }
            }

            function A(e, t, n) {
                U(e);
                var i = t[n[e.StockSeries] - 1];
                if (i) {
                    var o = angular.copy(e);
                    o.lastWithOutLot = parseFloat(o.Last), "P" !== e.Odd_lot ? o.Last = parseFloat(o.Last) : o.Last = i.hechos.body.Last, o.operationVolume = e.OperationVolume || 0, o.aggVolume = i.hechos.body.aggVolume || 0, o.isMarketDataRefresh = !1, angular.extend(i.hechos.body, o), angular.extend(i, {
                        lastTick: o.Time
                    }), ie.onNext(i.hechos.body)
                }
            }

            function k(e, t, n, i) {
                N(t);
                var o = t.StockSeries,
                    r = n[i[o] - 1];
                if (r) {
                    var a = L(t);
                    angular.extend(r.posturas, {
                        topic: e.getTopic(),
                        body: a,
                        lastTick: a[0].Time
                    }), angular.extend(r, {
                        lastTick: a[0].Time
                    })
                }
            }

            function L(e) {
                var t = [];
                for (var n in e) {
                    var i = e[n],
                        o = n.slice(-1),
                        r = n;
                    isNaN(o) ? o = 0 : (o -= 1, r = n.slice(0, n.length - 1)), t[o] || (t[o] = {});
                    var a = t[o];
                    a[r] = i
                }
                return t
            }

            function x(e, t) {
                var n = e.getTopic().indexOf("NAC") > 0 ? "nac" : "sic",
                    i = "nac" === n ? X : j,
                    o = "nac" === n ? K : Z,
                    r = i[o[t.StockSeries] - 1];
                r && angular.extend(r.hechos.body, {
                    aggVolume: t.AggregateVolume || 0,
                    changeAvg: t.PercentageChange || 0,
                    maxPrice: t.MaxPrice || 0,
                    minPrice: t.MinPrice || 0,
                    ppp: "undefined" == typeof t.BMVWeightedAvgPrice ? t.WeightedAvgPrice : 0 === t.BMVWeightedAvgPrice ? t.WeightedAvgPrice : t.BMVWeightedAvgPrice
                })
            }

            function $(e) {
                var t = e.preorderId || e.ElecId,
                    n = ne[t];
                if (n) {
                    var i = {},
                        o = !1;
                    e.CapitalTypeId && (i.capitalOrderTypeId = e.CapitalTypeId, o = !0), e.AssignQty && (i.assignedQuantity = e.AssignQty, o = !0), e.CancelQty && (i.cancelQuantity = e.CancelQty, o = !0), e.AvgPrc && (i.averagePrice = e.AvgPrc, o = !0), e.ProcessDate && (i.processDate = e.ProcessDate, o = !0), e.Status && (i.gbmIntProcessStatus = e.Status, o = !0), (o = !0) && (i.lastTick = (new Date).getTime(), angular.extend(n, i))
                } else {
                    n = {
                        assignedQuantity: e.AssignQty,
                        averagePrice: e.AvgPrc,
                        cancelQuantity: e.CancelQty,
                        commision: e.Commision,
                        issueId: e.IssueId,
                        processDate: e.ProcessDate,
                        originalQuantity: e.OrderQty,
                        gbmIntProcessStatus: e.Status,
                        lastTick: (new Date).getTime(),
                        price: e.Price,
                        capitalOrderTypeId: e.OrderTypeId,
                        sobId: e.ElecId,
                        accountId: e.ContractId,
                        iva: e.TransactionIVA,
                        algoTradingTypeId: e.AlgoTradingTypeId,
                        minQty: e.MinQty,
                        maxFloor: e.MaxFloor,
                        mainOrderAMId: e.OrderId,
                        triggerPrice: e.TriggerPrice,
                        pegOffsetValue: e.PegOffsetValue,
                        instrumentType: 0,
                        bitBuy: !0,
                        isCancelable: !0
                    };
                    var t = n.preorderId || n.sobId;
                    ne[t] = n, te.push(n)
                }
                u.setOrderTypeText(n), u.setDirectionText(n), u.setStatusText(n)
            }

            function B(e) {
                return e.ElecId ? "ORD" : e.RegType ? e.RegType.trim() : void 0
            }

            function R(e) {
                o.getCommoditiesByType({
                    commodityType: -3
                }, e).then(function (e) {
                    angular.forEach(e.data, function (e, t) {
                        var n = {
                            GBL_INDEX: e.name,
                            Timestamp: (new Date).toISOString().replace("T", " "),
                            ChangePercent: e.percentageChange,
                            Value: e.lastValue,
                            Volume: e.volume,
                            ChangeUnit: e.unitChange,
                            Type: e.commodityType
                        };
                        D(n, Q, ee)
                    })
                }, function (e) {
                    s.logging(e.data, s.loggingTypes.EXCEPTION)
                })
            }

            function N(e) {
                ae.TimePosturas = e.Time
            }

            function U(e) {
                ae.TimeHechos = e.Time
            }

            function F() {
                G(), H = setInterval(function () {
                    y(!0)
                }, re)
            }

            function G() {
                H && clearInterval(H)
            }
            var V, W, z, H, J = i.$q.defer(),
                q = !1,
                Y = !1,
                X = [],
                j = [],
                Q = [],
                K = {},
                Z = {},
                ee = {},
                te = [],
                ne = {},
                ie = new Rx.Subject,
                oe = [],
                re = d.min5,
                ae = {
                    getNac: C,
                    getSic: w,
                    getSymbol: _,
                    getSolaceIndex: O,
                    TimePosturas: W,
                    TimeHechos: z,
                    inited: Y,
                    isSolaceConnected: S,
                    serviceInitialized: f,
                    connectSolace: v,
                    disconnectSolace: b,
                    getOrders: I,
                    indicesCommodities: Q,
                    refresh: y,
                    hechosRxSubject: ie
                };
            return t.$watch(n.loggedIn, function (e, t) {
                e ? g() : (J = i.$q.defer(), G(), b())
            }), ae
        }
        var t = "hbSolaceSvc";
        angular.module("app").factory(t, ["$interval", "$rootScope", "hbSecuritySvc", "common", "hbMarketSvc", "hbAppManagementSvc", "solaceOptions", "hbLoggingSvc", "hbOperationSvc", "hbContractManagementSvc", "hbOrderGloblizationSvc", "timeoutConfig", e])
    }(),
    function () {
        "use strict";

        function e(e, i) {
            function o(e, t) {
                try {
                    switch (n && console.log("[" + (new Date).format("dd/mm/yyyy HH:MM:ss L tt") + "] - " + e), t) {
                        case d.SUCCESS:
                            notificationConfiguration.showSuccess && u(e, null, !0);
                            break;
                        case d.INFORMATION:
                            notificationConfiguration.showInformation && s(e);
                            break;
                        case d.WARNING:
                            notificationConfiguration.showWarning && l(e);
                            break;
                        case d.DEBUG:
                            notificationConfiguration.showDebug && s(e);
                            break;
                        case d.EXCEPTION:
                            if (notificationConfiguration.showException)
                                if (e.IsBussinessError) r(e.ErrorMessage);
                                else {
                                    var i = void 0 === e.EventId ? e : (e.EventId ? "<div>Event Id: <b>" + e.EventId + "</b></div>" : "") + "<div>" + (e.EventId ? "<i>" + e.ErrorMessage + "</i>" : e.ErrorMessage) + "</div>";
                                    c(i, null, !0), n && console.trace()
                                }
                    }
                } catch (o) {
                    console.log("there was an error logging data. " + o)
                }
            }

            function r(e) {
                i.open({
                    templateUrl: "loadPartial/Error/Index",
                    windowClass: "confirm-transaction",
                    controller: "hbErrorCtrl as err",
                    resolve: {
                        message: function () {
                            return e
                        }
                    }
                })
            }
            var a = e.logger.getLogFn,
                s = a(t),
                c = a(t, "Error"),
                l = a(t, "warning"),
                u = e.logger.getLogFn(t, "success"),
                d = {
                    INFORMATION: "INFORMATION",
                    WARNING: "WARNING",
                    EXCEPTION: "EXCEPTION",
                    SUCCESS: "SUCCESS",
                    DEBUG: "DEBUG"
                },
                g = {
                    loggingTypes: d,
                    logging: o
                };
            return g
        }
        var t = "hbLoggingSvc";
        angular.module("app").factory(t, ["common", "$modal", e]);
        var n = !1
    }(),
    function () {
        "use strict";

        function e(e, t, n, i, o) {
            function r(t) {
                var n = e.$q.defer();
                if (t)
                    if (s[t]) n.resolve(s[t]);
                    else {
                        if (c[t]) return c[t];
                        c[t] = n.promise, o("./loadPartial/Globalization?section=" + t, "get", null).then(function (e) {
                            return s[t] = e.data, c[t] = null, n.resolve(e.data), e
                        })
                    }
                else n.resolve();
                return n.promise
            }

            function a(t, n, o) {
                var a = "[no label]";
                if (0 !== t.indexOf("#")) {
                    if (n) {
                        var c = t.substring(0, t.indexOf("_"));
                        return s[c] && s[c][t] ? s[c][t] : o ? o : null
                    }
                    var l = e.$q.defer(),
                        c = t.substring(0, t.indexOf("_"));
                    return s[c] ? s[c][t] ? l.resolve(s[c][t]) : o ? l.resolve(o) : l.resolve(null) : r(c).then(function () {
                        s[c] && s[c][t] ? l.resolve(s[c][t]) : o ? l.resolve(o) : l.resolve(null)
                    }), l.promise
                }
                return "undefined" != typeof angular.element(document.querySelector(t))[0] ? a = angular.element(document.querySelector(t))[0].value : i.logging("no label found for: " + t, i.loggingTypes.EXCEPTION), a
            }
            var s = {},
                c = {};
            return {
                getResource: a,
                load: r
            }
        }
        var t = "hbGlobalizationSvc";
        angular.module("app").factory(t, ["common", "urlServices", "$filter", "hbLoggingSvc", "serviceManager", e])
    }(),
    function () {
        "use strict";

        function e(e, t, n, i, o, r, a, s, c, l, u, d, g, f) {
            function p(e) {
                for (var t = e + "=", n = document.cookie.split(";"), i = 0; i < n.length; i++) {
                    var o = n[i].trim();
                    if (0 == o.indexOf(t)) return o.substring(t.length, o.length)
                }
                return ""
            }

            function h(e) {
                if ("undefined" != typeof e) {
                    var t = p("bplang"),
                        n = new Date;
                    n.setTime(n.getTime() + 31556926e3);
                    var i = "; expires=" + n.toGMTString();
                    "undefined" == typeof t || "" === t ? document.cookie = "bplang=" + e + i : t !== e && (document.cookie = "bplang=" + e + i, c.location.reload())
                }
            }

            function m() {
                var n = d.getUserAppConfiguration().then(function (t) {
                    try {
                        w.enabledSolace = t.data.solaceNotifications, y = t.data;
                        var n = JSON.parse(y.uiConfiguration);
                        o.setDefaultContract(n.contractId), l.setDefaultCulture(y.cultureId), n.dashboardSorting ? w.dashboardSorting = n.dashboardSorting : w.dashboardSorting = [], e.defaults.headers.common["Accept-Language"] = y.cultureDescription, h(y.cultureDescription)
                    } catch (i) {
                        o.setDefaultContract(null), s.logging("there is no application configuration for the user. " + i, s.loggingTypes.EXCEPTION)
                    }
                });
                return t.$q.all([n]).then(function (e) {
                    return s.logging("getUserAppConfiguration() loaded successfully...", s.loggingTypes.DEBUG), e
                })
            }

            function v(e) {
                var i = !1;
                switch (e) {
                    case a.CONTRACT:
                        if ("undefined" != typeof o.defaultContract.contractId) try {
                            var r = JSON.parse(y.uiConfiguration);
                            r.contractId = o.defaultContract.contractId, y.uiConfiguration = JSON.stringify(r), i = !0
                        } catch (c) {
                            var r = {};
                            r.contractId = o.defaultContract.contractId, y.uiConfiguration = JSON.stringify(r), i = !0
                        }
                        break;
                    case a.CULTURE:
                        "undefined" != typeof l.defaultCulture.cultureId && (y.cultureId = l.defaultCulture.cultureId, i = !0);
                        break;
                    case a.DASHBOARD_SORTING:
                        try {
                            var r = JSON.parse(y.uiConfiguration);
                            r.dashboardSorting = w.dashboardSorting, y.uiConfiguration = JSON.stringify(r), i = !0
                        } catch (c) {}
                }
                if (i) {
                    var d = u(n.servicesUri + "api/AppManagement/UpdateUserAppConfiguration", "post", y).then(function (e) {
                        s.logging("saveConfigData() completed...", s.loggingTypes.DEBUG)
                    }, function (e) {
                        s.logging(e.data, s.loggingTypes.EXCEPTION)
                    });
                    return t.$q.all([d]).then(function (e) {
                        return s.logging("saveConfigData() loaded successfully...", s.loggingTypes.DEBUG), e
                    })
                }
            }

            function b(e) {
                return d.updateUserDefaultConfiguration(e).then(function (t) {
                    angular.extend(C, e), w.enabledSolace = e.solaceNotifications, s.logging(g.getResource("Dashboard_JS_MSG_SettingsSaved", !0), s.loggingTypes.SUCCESS), l.defaultCulture.cultureId = e.cultureId
                }, function (e) {
                    s.logging(e.data, s.loggingTypes.EXCEPTION)
                })
            }

            function S() {
                return d.getUserDefaultConfiguration().then(function (e) {
                    return angular.extend(C, e.data), C
                }, function (e) {
                    s.logging(e, s.loggingTypes.EXCEPTION)
                })
            }
            var y = (t.$q.defer(), {}),
                T = !0,
                C = {},
                w = {
                    initialize: m,
                    enabledSolace: T,
                    updateUserConfiguration: b,
                    getUserConfiguration: S,
                    dashboardSorting: []
                };
            return r.$watch(function () {
                return o.defaultContract.contractId
            }, function (e, t) {
                v(a.CONTRACT)
            }), r.$watchCollection(function () {
                return w.dashboardSorting
            }, function (e, t) {
                v(a.DASHBOARD_SORTING)
            }), r.$watch(function () {
                return l.defaultCulture.cultureId
            }, function (t, n) {
                if (t && n && t !== n) {
                    var i = l.findCulture(t);
                    v(a.CULTURE).then(function () {
                        "undefined" != typeof i[0] && (e.defaults.headers.common["Accept-Language"] = i[0].code, h(i[0].code))
                    })
                }
            }), w
        }
        var t = "hbUserAppConfigSvc";
        angular.module("app").factory(t, ["$http", "common", "urlServices", "$location", "hbContractManagementSvc", "$rootScope", "configurationTypes", "hbLoggingSvc", "$window", "hbCultureManagementSvc", "serviceManager", "hbAppManagementSvc", "hbGlobalizationSvc", "hbSolaceSvc", e])
    }(),
    function () {
        "use strict";

        function e(e) {
            function t(e, t, i) {
                return i = i || o, new n(e, t, i)
            }

            function n(e, t, n) {
                this.selectedBinding = i[0].name, this.subs = {}, this.subs[n] = e, this.notificationHandlers = {}, this.notificationHandlers[n] = t
            }
            var i = [{
                    name: "alpha",
                    color: "#95ea4f"
                }, {
                    name: "beta",
                    color: "#1d5945"
                }, {
                    name: "gamma",
                    color: "#63d1bd"
                }, {
                    name: "delta",
                    color: "#00a9ff"
                }, {
                    name: "epsilon",
                    color: "#ef1359"
                }, {
                    name: "zeta",
                    color: "#E0844C"
                }, {
                    name: "eta",
                    color: "#81526C"
                }, {
                    name: "theta",
                    color: "#DCD087"
                }, {
                    name: "iota",
                    color: "#8B8681"
                }, {
                    name: "kappa",
                    color: "#C2847D"
                }],
                o = "default",
                r = {},
                a = {},
                s = {
                    eventBindings: i,
                    buildInstance: t
                };
            return n.prototype.registerHandlers = function (e, t, n) {
                var i = this;
                e = e || o, n && (this.notificationHandlers[e] = n), t && (this.subs[e] = t), this.subs && this.subs[e] && angular.forEach(this.subs[e], function (t, n) {
                    if (!t.unsub) {
                        var n;
                        n = t.isGlobal ? t.sub : t.sub + "." + i.selectedBinding, r[n] || (r[n] = []), r[n].push(i.notificationHandlers[e]),
                            function (e, n) {
                                t.unsub = function () {
                                    var t = r[e].indexOf(n);
                                    r[e].splice(t, 1)
                                }
                            }(n, i.notificationHandlers[e])
                    }
                });
                var s = a[i.selectedBinding];
                if (s) {
                    var c = !1;
                    if (t)
                        for (var l = 0; l < t.length; l++) {
                            var u = t[l];
                            if (c = u.sub === s.type) break
                        }
                    c && setTimeout(function () {
                        i.notify(s.type, s.message)
                    }, 1)
                }
            }, n.prototype.unRegisterHandler = function (e) {
                var t = this;
                e = e || o, angular.forEach(t.subs[e], function (e, t) {
                    e && e.unsub && (e.unsub(), e.unsub = void 0)
                })
            }, n.prototype.notify = function (e, t, n) {
                var i;
                if (i = n ? e : e + "." + this.selectedBinding, r[i]) {
                    for (var o = 0, s = r[i].length; o < s; o++) r[i][o]({
                        name: i
                    }, t);
                    a[this.selectedBinding] = {
                        type: e,
                        message: t
                    }
                }
            }, s
        }
        var t = "hbEventNotificationSvc";
        angular.module("app").factory(t, ["common", e])
    }(),
    function () {
        "use strict";

        function e(e, t, n) {
            function i() {
                return n(t.servicesUri + "api/Utilities/GetTokenGraphics/", "get", null)
            }

            function o(e) {
                return n(t.servicesUri + "api/Utilities/getStock2Graphics/" + e, "get", null)
            }

            function r() {
                var e = {
                    count: 0,
                    mustRetry: !1,
                    isTimer: !0
                };
                return n(t.servicesUri + "api/Utilities/GetCentralHour", "get", null, e).then(function (e) {
                    return e && e.data && e.data.response && (a.centralHour = e.data.response), e
                })
            }
            var a = {
                getTokenGraphics: i,
                getStock2Graphics: o,
                getCentralHour: r,
                centralHour: void 0
            };
            return a
        }
        var t = "hbUtilitiesSvc";
        angular.module("app").factory(t, ["hbSecuritySvc", "urlServices", "serviceManager", e])
    }(),
    function () {
        "use strict";

        function e() {
            var e = this;
            this.ghostElement = null, this.message = null, this.clearMessage = function () {
                e.message = null
            }, this.setMessage = function (t, n) {
                e.message = {
                    source: t,
                    payload: n
                }
            }, this.getMessage = function () {
                return e.message
            }, this.out = function () {
                e.ghostElement && (e.ghostElement.removeClass("drop-not-accepted"), e.ghostElement.removeClass("drop-accepted"))
            }, this.accepts = function (t) {
                if (null !== e.ghostElement) {
                    var n;
                    n = t instanceof Array ? t : [t];
                    for (var i = 0 === n.length, o = 0, r = n.length; o < r; o++)
                        if (null !== e.message && n[o] === e.message.source) {
                            i = !0;
                            break
                        }
                    i ? (e.ghostElement.removeClass("drop-not-accepted"), e.ghostElement.addClass("drop-accepted")) : (e.ghostElement.removeClass("drop-accepted"), e.ghostElement.addClass("drop-not-accepted"))
                }
            }, this.dragTableRow = function (t) {
                var n = $('<div><table class="table table-striped table-hover table-condensed"></table></div>'),
                    i = $(t.target).closest("tr");
                return n.css("width", i.width()), n.css("height", i.height()), e.removeGhost(), e.ghostElement = n, n.find("table").append(i.clone()).end()
            }, this.removeGhost = function () {
                e.ghostElement && (e.ghostElement.remove(), e.ghostElement = null)
            }
        }
        angular.module("app").service("hbDragNDropHelperSvc", function () {
            return new e
        })
    }(),
    function (e) {
        "use strict";

        function t(e, t, n) {
            var i = {};
            return i
        }
        var n = "hbSocketSvc";
        e.factory(n, ["$http", "$rootScope", "hbSecuritySvc", t])
    }(angular.module("app")),
    function (e) {
        "use strict";

        function t(e, t, n, i, o, r) {
            function a() {
                return t.post("loadPartial/Chat/GetChannelsList", {}).then(function (e) {
                    O.channels.length = 0;
                    for (var t in e.data) {
                        var n = e.data[t];
                        O.channels.push({
                            name: n.name,
                            friendlyChannelName: n.friendlyChannelName,
                            isPrivate: n.isPrivate
                        })
                    }
                    for (var i in O.channels) {
                        var o = O.channels[i];
                        g(o, !1)
                    }
                    for (var i in O.myPrivateChannels) {
                        var o = O.myPrivateChannels[i];
                        g(o, !0)
                    }
                }, function (e) {
                    o.logging(e.data, o.loggingTypes.EXCEPTION)
                })
            }

            function s() {
                E.presencePusher || (E.presencePusher = new Pusher(n, {
                    authEndpoint: "loadPartial/Chat/AuthPresence"
                })), O.myPublicChannel = E.presencePusher.subscribe("presence-" + n), O.myPublicChannel.bind("pusher:subscription_succeeded", function () {
                    w(), O.myPublicChannel.bind(i.user.user + "-invitations", function (e) {
                        o.logging("Tienes una invitaciÃ³n de chat privado de " + e.from, o.loggingTypes.INFORMATION), O.myInvitations.push(e)
                    }), O.myPublicChannel.bind("channelUpdated", function (e) {
                        a()
                    }), O.myPublicChannel.bind("pusher:member_added", function (e) {
                        w()
                    }), O.myPublicChannel.bind("pusher:member_removed", function (e) {
                        w()
                    })
                }), O.myPublicChannel.bind("pusher:subscription_error", function (e) {
                    console.error(e)
                })
            }

            function c(e) {
                E.presencePusher || (E.presencePusher = new Pusher(n, {
                    authEndpoint: "loadPartial/Chat/AuthPresence"
                }));
                var t = "presence-P-" + n + "-" + e + "-" + i.user.user,
                    o = E.presencePusher.subscribe(t);
                O.myPrivateChannels.push({
                    name: t,
                    info: {
                        isSubscribed: !0
                    },
                    members: 1,
                    friendlyChannelName: e,
                    newMessages: 0,
                    messages: []
                }), u(o)
            }

            function l(e) {
                E.presencePusher || (E.presencePusher = new Pusher(n, {
                    authEndpoint: "loadPartial/Chat/AuthPresence"
                }));
                var t = "presence-" + e,
                    i = E.presencePusher.subscribe(t);
                O.myPrecenseChannels.push({
                    name: t,
                    newMessages: 0,
                    friendlyChannelName: e,
                    messages: []
                }), u(i)
            }

            function u(e) {
                e.bind("pusher:subscription_succeeded", function () {
                    b()
                }), e.bind("pusher:subscription_error", function (t) {
                    console.error("pusher:subscription_error", t, e)
                }), e.bind("pusher:member_added", function (e) {
                    d(e.info.channelName, e.info.isPrivate)
                }), e.bind("pusher:member_removed", function (e) {
                    d(e.info.channelName, e.info.isPrivate)
                }), e.bind("sendMessage", M)
            }

            function d(e, t) {
                var n = [];
                n = t ? O.myPrivateChannels.filter(function (t) {
                    return t.name === e
                }) : O.channels.filter(function (t) {
                    return t.name === e
                }), n.length > 0 && g(n[0], t)
            }

            function g(e, t) {
                if (e.info = p(e.name, t), t) e.members = E.presencePusher.channels.channels[e.name].members;
                else {
                    var n = O.myPrecenseChannels.filter(function (t) {
                        return t.name === e.name
                    });
                    n.length > 0 ? e.members = E.presencePusher.channels.channels[e.name].members.count : f(e)
                }
            }

            function f(e) {
                return t.post("loadPartial/Chat/GetChannelMembersId", {
                    channelName: e.name
                }).then(function (t) {
                    t.data && (e.members = t.data.members.users.length)
                }, function (e) {
                    o.logging(e.data, o.loggingTypes.EXCEPTION)
                })
            }

            function p(e, t) {
                var n = {
                        isSubscribed: !1
                    },
                    i = [];
                return i = t ? O.myPrivateChannels.filter(function (t) {
                    return t.name === e
                }) : O.myPrecenseChannels.filter(function (t) {
                    return t.name === e
                }), i.length > 0 && (n.isSubscribed = !0, n.newMessages = i[0].newMessages), n
            }

            function h(e) {
                var t = O.myPrecenseChannels.filter(function (t) {
                        return t.name === e
                    }),
                    n = O.channels.filter(function (t) {
                        return t.name === e
                    });
                if (n.length > 0 && (n[0].info.newMessages = 0), t.length > 0) {
                    t[0].newMessages = 0;
                    var i = t[0];
                    i.members = E.presencePusher.channels.channels[e].members, O.currentPresenceChannel = i
                }
            }

            function m(e) {
                var t = O.myPrivateChannels.filter(function (t) {
                    return t.name === e
                });
                if (t.length > 0) {
                    t[0].newMessages = 0;
                    var n = t[0];
                    n.members = E.presencePusher.channels.channels[e].members, O.currentPrivateChannel = n
                }
            }

            function v() {
                O.currentPresenceChannel = void 0, O.currentPrivateChannel = void 0
            }

            function b() {
                return t.post("loadPartial/Chat/ChannelUpdated", {})
            }

            function S(e, t, i) {
                E.presencePusher || (E.presencePusher = new Pusher(n, {
                    authEndpoint: "loadPartial/Chat/AuthPresence"
                })), i ? O.myPrivateChannels.push({
                    name: e,
                    friendlyChannelName: t,
                    newMessages: 0,
                    messages: [],
                    info: {
                        isSubscribed: !0,
                        newMessages: 0
                    }
                }) : O.myPrecenseChannels.push({
                    name: e,
                    friendlyChannelName: t,
                    newMessages: 0,
                    messages: []
                });
                var o = E.presencePusher.subscribe(e);
                u(o)
            }

            function y() {
                if (E.presencePusher) {
                    for (var e in O.myPrecenseChannels) {
                        var t = O.myPrecenseChannels[e];
                        E.presencePusher.unsubscribe(t.name)
                    }
                    O.myPrecenseChannels.length = 0, O.myPrivateChannels.length = 0, O.myInvitations.length = 0, O.currentPresenceChannel = void 0
                }
                return !0
            }

            function T(e) {
                var t = void 0;
                if (e) {
                    E.presencePusher.unsubscribe(O.currentPrivateChannel.name);
                    var n = void 0;
                    for (var i in O.myPrivateChannels) {
                        var o = O.myPrivateChannels[i];
                        if (o.name === O.currentPrivateChannel.name) {
                            n = i;
                            break
                        }
                    }
                    O.myPrivateChannels.splice(n, 1), t = angular.copy(O.currentPrivateChannel.name)
                } else {
                    E.presencePusher.unsubscribe(O.currentPresenceChannel.name);
                    var n = void 0;
                    for (var i in O.myPrecenseChannels) {
                        var o = O.myPrecenseChannels[i];
                        if (o.name === O.currentPresenceChannel.name) {
                            n = i;
                            break
                        }
                    }
                    O.myPrecenseChannels.splice(n, 1), t = angular.copy(O.currentPresenceChannel.name)
                }
                return r(function () {
                    d(t, e)
                }, 500), !0
            }

            function C() {
                E.presencePusher && (E.presencePusher.unsubscribe("presence-" + n), O.myPublicChannel = void 0, O.channels.length = 0);
                var e = y();
                e && E.presencePusher && (E.presencePusher.disconnect(), E.presencePusher = void 0)
            }

            function w() {
                O.connectedUsers.length = 0;
                var e = E.presencePusher.channels.channels["presence-" + n].members;
                for (var t in e.members) {
                    var i = e.members[t];
                    e.myID !== t && O.connectedUsers.push({
                        id: t,
                        name: i.name
                    })
                }
            }

            function I(e) {
                if (!e.chatAlreadyExists) {
                    var r = "presence-P-" + n + "-" + e.channelName + "-" + i.user.user;
                    e.channelName = r
                }
                return e.from = i.user.name, t.post("loadPartial/Chat/SendInvitation", e).then(function () {
                    o.logging("InvitaciÃ³n enviada con Ã©xito.", o.loggingTypes.SUCCESS)
                }, function (e) {
                    o.logging(e.data, o.loggingTypes.EXCEPTION)
                })
            }

            function _(e) {
                O.myInvitations.splice(e, 1)
            }

            function P(e) {
                return t.post("loadPartial/Chat/SendMessage", {
                    channelName: e.channelName,
                    user: i.user.user,
                    from: i.user.name,
                    message: e.message
                })
            }

            function M(e) {
                e.isMine = e.user == i.user.user;
                var t = [];
                if (e.isPrivate) t = O.myPrivateChannels.filter(function (t) {
                    return t.name === e.channelName
                }), O.currentPrivateChannel ? O.currentPrivateChannel.name !== t[0].name && (t[0].newMessages = t[0].newMessages + 1) : t[0].newMessages = t[0].newMessages + 1;
                else {
                    t = O.myPrecenseChannels.filter(function (t) {
                        return t.name === e.channelName
                    });
                    var n = O.channels.filter(function (t) {
                        return t.name === e.channelName
                    });
                    O.currentPresenceChannel ? O.currentPresenceChannel.name !== t[0].name && (t[0].newMessages = t[0].newMessages + 1) : t[0].newMessages = t[0].newMessages + 1, n.length > 0 && (n[0].info = p(e.channelName))
                }
                t[0].messages.push(e)
            }
            var O = {
                    myPublicChannel: void 0,
                    myPrivateChannels: [],
                    myPrecenseChannels: [],
                    myInvitations: [],
                    channels: [],
                    currentPresenceChannel: void 0,
                    currentPrivateChannel: void 0,
                    connectedUsers: []
                },
                E = {
                    presencePusher: void 0
                },
                D = {
                    pusherInfo: E,
                    channelsInfo: O,
                    closeAllPushers: C,
                    unsubscribePushers: y,
                    createPrivateChannel: c,
                    createPresenceChannel: l,
                    sendMessage: P,
                    subscribeChannel: S,
                    getChannelList: a,
                    setCurrentPresenceChannel: h,
                    setCurrentPrivateChannel: m,
                    resetCurrentChannels: v,
                    unsubscribeCurrentChannel: T,
                    sendInvitation: I,
                    rejectInvitation: _
                };
            return e.$watch(function (e) {
                return i.user
            }, function (e, t) {
                e ? (s(), a()) : C()
            }), D
        }
        var n = "hbChatsSvc";
        e.factory(n, ["$rootScope", "$http", "pusherAppKey", "hbSecuritySvc", "hbLoggingSvc", "$timeout", t])
    }(angular.module("app")),
    function () {
        "use strict";

        function e(e, t, n, i, o, r, a, s, c) {
            function l() {
                u(), $ = setInterval(function () {
                    d()
                }, z)
            }

            function u() {
                $ && clearInterval($)
            }

            function d() {
                h(void 0, !0).then(function () {
                    t.$emit(J, {
                        isTimer: !0
                    })
                })
            }

            function g() {
                return s.getCapitalMarketOperationTime().then(function (e) {
                    return F = e, e
                })
            }

            function f() {
                return U ? e.when(!0) : (p(), N.promise)
            }

            function p() {
                L = [{
                    valueTypeId: 0,
                    key: "Position_VT0",
                    label: ""
                }, {
                    valueTypeId: 1,
                    key: "Position_VT1",
                    label: ""
                }, {
                    valueTypeId: 2,
                    key: "Position_VT2",
                    label: ""
                }, {
                    valueTypeId: 4,
                    key: "Position_VT4",
                    label: ""
                }, {
                    valueTypeId: 5,
                    key: "Position_VT5",
                    label: ""
                }, {
                    valueTypeId: 6,
                    key: "Position_VT6",
                    label: ""
                }, {
                    valueTypeId: 8,
                    key: "Position_VT8",
                    label: ""
                }, {
                    valueTypeId: 9,
                    key: "Position_VT9",
                    label: ""
                }, {
                    valueTypeId: 26,
                    key: "Position_VT26",
                    label: ""
                }, {
                    valueTypeId: 27,
                    key: "Position_VT27",
                    label: ""
                }], i.load("Position").then(function (e) {
                    for (var t in L) {
                        var n = L[t];
                        e[n.key] && (n.label = e[n.key])
                    }
                    r.serviceInitialized().then(function () {
                        h()
                    })
                })
            }

            function h(e, t) {
                return u(), e = e || n.defaultContract.contractId, o.getPosition(e, t).then(function (t) {
                    R.lastTick = new Date;
                    var n = B[e];
                    U || (N.resolve(!0), U = !0), n || (n = {
                        contract: e,
                        positionDetail: []
                    }, B[e] = n), n.positionDetail = [], n.positionDetail.push.apply(n.positionDetail, t.data);
                    var i = I(1e3, e);
                    if (i && (x = i.marketValue), y(e), H.debt.length = 0, H.equity.length = 0, n && n.positionDetail)
                        for (var o = 0; o < n.positionDetail.length; o++) {
                            var r = n.positionDetail[o];
                            27 === r.instrument.instrumentType && H.debt.push(r.instrument.issueID), 28 === r.instrument.instrumentType && H.equity.push(r.instrument.issueID)
                        }
                    return n
                }, function (e) {
                    N.reject(e)
                })["finally"](function () {
                    l()
                })
            }

            function m(t) {
                var n = G[t],
                    i = e.defer();
                return n ? e.when(n) : (h(t).then(function () {
                    i.resolve(G[t])
                }, function (e) {
                    i.reject(e)
                }), i.promise)
            }

            function v(t, i, o) {
                i = i || n.defaultContract.contractId;
                var r, a = G[i],
                    s = e.defer();
                return a ? (r = _(t), e.when(r)) : (h(i, o).then(function () {
                    r = _(t), s.resolve(r)
                }, function (e) {
                    s.reject(e)
                }), s.promise)
            }

            function b(t, i, o, r) {
                i = i || n.defaultContract.contractId;
                var a, s = G[i],
                    c = e.defer();
                if (s) {
                    a = _(t);
                    var l = P(o, a);
                    return e.when(l)
                }
                return h(i, r).then(function () {
                    a = _(t);
                    var e = P(o, a);
                    c.resolve(e)
                }, function (e) {
                    c.reject(e)
                }), c.promise
            }

            function S(e) {
                e = e || n.defaultContract.contractId;
                var t = G[e],
                    i = B[e];
                if (t) {
                    for (var o = t.aggPositionDetail.length; o--;) {
                        var r = t.aggPositionDetail[o],
                            a = i.positionDetail.filter(function (e) {
                                return e.positionValueType === r.posValueType
                            });
                        0 === a.length && t.aggPositionDetail.splice(o, 1)
                    }
                    for (var s = 0, o = t.aggPositionDetail.length; s < o; s++) t.aggPositionDetail[s].posValueTypeDetail = []
                }
            }

            function y(e) {
                var t, n, i, o = B[e],
                    a = G[e];
                S(e), a || (a = {
                    contract: e,
                    aggPositionDetail: []
                }, G[e] = a);
                for (var s = 0, c = o.positionDetail.length; s < c; s++) {
                    var l = o.positionDetail[s];
                    if (t = _(l.positionValueType), t || (t = new D(l.positionValueType), a.aggPositionDetail.push(t)), 0 === l.instrument.instrumentType || 2 === l.instrument.instrumentType ? (n = r.getSymbol({
                            symbol: l.instrument.issueID,
                            topic: "hechos"
                        }), i = new k(l, n)) : i = new k(l), t.posValueTypeDetail.push(i), 27 === l.positionValueType || 150 === l.positionValueType) {
                        var u = a.aggPositionDetail.filter(function (e) {
                            return e.posValueType === V
                        });
                        0 === u.length ? (u = new D(V), a.aggPositionDetail.push(u)) : u = u[0];
                        var d = u.posValueTypeDetail.filter(function (e) {
                            return e.position.instrument.issueID === l.instrument.issueID
                        });
                        d && 0 !== d.length ? d[0].position = l : (i = new k(l), u.posValueTypeDetail.push(i))
                    }
                }
                a.aggPositionDetail.sort(function (e, t) {
                    return e.posValueType > t.posValueType
                });
                for (var g = 0, c = a.aggPositionDetail.length; g < c; g++) a.aggPositionDetail[g].processAggData()
            }

            function T(t, i) {
                var o, r = e.defer();
                i = i || n.defaultContract.contractId;
                var a = B[i];
                return a ? (o = w(t, i), o ? r.resolve(o) : r.reject("No position found for issue: " + t)) : h(i).then(function (e) {
                    o = w(t, i), o ? r.resolve(o) : r.reject("No position found for issue: " + t)
                }, function (e) {
                    r.reject(e)
                }), r.promise
            }

            function C(e, t) {
                var i, o = (t || n.defaultContract.contractId, B[t]);
                return o && (i = o.positionDetail.filter(function (t, n) {
                    return t.instrument.issueID == e
                }), i && i.length > 0 && (i = i[0])), i
            }

            function w(e, t) {
                var n, i = B[t];
                if (i) {
                    var o = C(e, t);
                    o && (n = new E(e, t))
                }
                return n
            }

            function I(e, t) {
                var i, o = (t || n.defaultContract.contractId, B[t]);
                return o && (i = o.positionDetail.filter(function (t, n) {
                    return t.positionValueType == e
                }), i && i.length > 0 && (i = i[0])), i
            }

            function _(e) {
                var t, i, o = n.defaultContract.contractId,
                    r = G[o].aggPositionDetail;
                return i = r.filter(function (t) {
                    return t.posValueType === e
                }), i && i.length > 0 && (t = i[0]), t
            }

            function P(e, t) {
                var n;
                if (t) {
                    var i = t.posValueTypeDetail.filter(function (t) {
                        return t.position.instrument.issueID === e
                    });
                    i && i.length > 0 && (n = i[0])
                }
                return n
            }

            function M(e) {
                var t, n = L.filter(function (t) {
                    return t.valueTypeId === e
                });
                return n && n.length > 0 && (t = n[0].label), t
            }

            function O(e) {
                return h(void 0, e)
            }

            function E(e, t) {
                function n() {
                    var t, n = 0,
                        i = 0,
                        o = 0,
                        r = B[this.contractId];
                    if (r && (t = r.positionDetail.filter(function (t) {
                            return t.instrument.issueID == e && (0 == t.positionValueType || 1 == t.positionValueType || 6 == t.positionValueType || 8 == t.positionValueType || 9 == t.positionValueType)
                        }), t && t.length > 0)) {
                        i = t.length;
                        for (var a = 0; a < i; a++) n += t[a].shares, o += t[a].averageCost * t[a].shares;
                        this._shares = n, this._averageCost = o / n
                    }
                    this._tick = R.lastTick
                }
                this.issueId = e, this.contractId = t, this._shares = 0, this._averageCost = 0, this._tick, Object.defineProperty(this, "shares", {
                    get: function () {
                        return this._tick !== R.lastTick && n.call(this), this._shares
                    }
                }), Object.defineProperty(this, "averageCost", {
                    get: function () {
                        return this._tick !== R.lastTick && n.call(this), this._averageCost
                    }
                })
            }

            function D(e) {
                this.posValueType = e, this.posValueTypeLabel = M(e), this.posValueTypeDetail = [], this.isOpen = [0, 1, 5].indexOf(e) >= 0, this.tick = 0, this.marketValueSubTot = 0,
                    this.plusMinusSubTot = 0, this.varSubTot = 0, this.portfolioSubTot = 0, this._sortingProp = "Position_Issue", this._reverse = !1
            }

            function A(e, t) {
                return t.split(".").reduce(function (e, t) {
                    if ("object" == typeof e && void 0 !== e[t]) return e[t]
                }, e)
            }

            function k(e, t) {
                this.position = e, this.solaceSymbol = t, this.costAmount = e.shares * e.averageCost, this.marketPrice = t ? t.body.Last : e.instrument.lastPrice, this._marketValue = e.marketValue, this.lastTime, this._plusMinus, this._var, this._portfolio, Object.defineProperty(this, "marketValue", {
                    get: function () {
                        return this._marketValue
                    }
                }), Object.defineProperty(this, "plusMinus", {
                    get: function () {
                        return this._plusMinus
                    }
                }), Object.defineProperty(this, "var", {
                    get: function () {
                        return this._var
                    }
                }), Object.defineProperty(this, "portfolio", {
                    get: function () {
                        return this._portfolio
                    }
                }), Object.defineProperty(this, "solaceTick", {
                    get: function () {
                        var e = "";
                        return this.solaceSymbol && (this.lastTime !== this.solaceSymbol.body.Time && (this.processAggValues(), this.lastTime = this.solaceSymbol.body.Time), e = this.solaceSymbol.body.Time), e
                    }
                })
            }
            var L, x, $, B = {},
                R = {
                    lastTick: "undefined"
                },
                N = e.defer(),
                U = !1,
                F = {},
                G = {},
                V = 999,
                W = {
                    DebtInvesmentSocieties: 5,
                    Cash: 27,
                    Total: 1e3
                },
                z = c.seg30,
                H = {
                    debt: [],
                    equity: []
                },
                J = "update_totals",
                q = {
                    getAggPositions: m,
                    getAggPositionByValueType: v,
                    getAggPositionRowByInstrument: b,
                    getPositionValue: T,
                    initialized: f,
                    virtualValueType: V,
                    ticker: R,
                    refreshPosition: O,
                    ValueTypes: W,
                    refresh: h,
                    updateTotalsEvent: J,
                    foundsToSell: H
                };
            return t.$watch(function () {
                return a.loggedIn()
            }, function (e, t) {
                e === !1 ? u() : g()
            }), D.prototype.setSorting = function (e, t) {
                var n = this;
                e && (n._sortingProp = e, n._reverse = t);
                var i = "",
                    o = !1;
                switch (n._sortingProp) {
                    case "Position_Issue":
                        i = "position.instrument.issueID", o = !0;
                        break;
                    case "Position_Shares":
                        i = "position.shares";
                        break;
                    case "Position_AvgPrice":
                        i = "position.averageCost";
                        break;
                    case "Position_MarketPrice":
                        i = "marketPrice";
                        break;
                    case "Position_CostAmount":
                        i = "costAmount";
                        break;
                    case "Position_MarketValue":
                        i = "position.marketValue";
                        break;
                    case "Position_PlusMinus":
                        i = "plusMinus";
                        break;
                    case "Position_Var":
                        i = "var";
                        break;
                    case "Position_Portfolio":
                        i = "portfolio";
                        break;
                    default:
                        i = "position.instrument.issueID"
                }
                i && n.posValueTypeDetail.sort(function () {
                    var e, t = A(arguments[1], i),
                        r = A(arguments[0], i);
                    return e = o ? n._reverse ? t > r ? 1 : t < r ? -1 : 0 : t < r ? 1 : t > r ? -1 : 0 : n._reverse ? t - r : r - t
                })
            }, D.prototype.processAggData = function () {
                var e = this;
                e.sharesSubTot = 0, e.marketValueSubTot = 0, e.averageCostSubTot = 0, e.costAmountSubTot = 0, e.plusMinusSubTot = 0, e.varSubTot = 0, e.portfolioSubTot = 0;
                for (var t in e.posValueTypeDetail) {
                    var n = e.posValueTypeDetail[t];
                    n.processAggValues(), e.sharesSubTot += n.shares, e.averageCostSubTot += n.averageCost, e.costAmountSubTot += n.costAmount, e.marketValueSubTot += n.marketValue, e.plusMinusSubTot += n.plusMinus, e.portfolioSubTot += n.portfolio
                }
                e.varSubTot = e.plusMinusSubTot / e.costAmountSubTot * 100, e.setSorting()
            }, k.prototype.processAggValues = function () {
                var e = this;
                27 === e.position.positionValueType || 150 === e.position.positionValueType || 1e3 === e.position.positionValueType ? e._marketValue = e.position.marketValue : e._marketValue = e.solaceSymbol ? e.solaceSymbol.body.Last * e.position.shares : e.position.instrument.lastPrice * e.position.shares, e._plusMinus = e._marketValue - e.costAmount, e._var = e._plusMinus / e.costAmount * 100, e.marketPrice = e.solaceSymbol ? e.solaceSymbol.body.Last : e.position.instrument.lastPrice, e._portfolio = e._marketValue / x * 100, F.endTime && F.endTime < Date.now() && e.solaceSymbol && e.solaceSymbol.body.ppp > 0 && (e.marketPrice = e.solaceSymbol.body.ppp)
            }, q
        }
        var t = "hbPositionSvc";
        angular.module("app").factory(t, ["$q", "$rootScope", "hbContractManagementSvc", "hbGlobalizationSvc", "hbPortfolioSvc", "hbSolaceSvc", "hbSecuritySvc", "hbAppManagementSvc", "timeoutConfig", e])
    }(),
    function () {
        "use strict";

        function e(e, t) {
            function n() {
                return t.getWatchList().then(function (e) {
                    if (e.data) {
                        var t = e.data.map(function (e) {
                            return {
                                id: e.watchListTypeId,
                                name: e.title,
                                configuration: e.configuration,
                                symbols: []
                            }
                        });
                        u.watchListArr.push.apply(u.watchListArr, t)
                    }
                    return e
                })
            }

            function i(n, i) {
                var o, r = l(n);
                return r && (o = !r.symbols || 0 === r.symbols.length || i ? d.then(function () {
                    return t.getWatchListDetail({
                        watchListType: n,
                        isOnLine: !0
                    }).then(function (e) {
                        if (e.data) {
                            r.symbols.length = 0;
                            var t = e.data.map(function (e) {
                                return e.issueID
                            });
                            r.symbols.push.apply(r.symbols, t)
                        }
                        return t
                    })
                }) : r.symbols), e.when(o)
            }

            function o(e, n) {
                return t.addWatchList({
                    title: e,
                    configuration: n
                }).then(function (t) {
                    return u.watchListArr.push({
                        id: t.data.response,
                        name: e,
                        configuration: n,
                        symbols: []
                    }), t
                })
            }

            function r(e) {
                return t.updateUserWatchList(e).then(function (t) {
                    var n = l(e.watchListTypeId);
                    return n && angular.extend(n, {
                        name: e.title,
                        configuration: e.configuration
                    }), n
                })
            }

            function a(e) {
                return t.deleteWatchList(e).then(function (t) {
                    for (var n = -1, i = 0; i < u.watchListArr.length; i++)
                        if (u.watchListArr[i].id === e) {
                            n = i;
                            break
                        }
                    n > -1 && u.watchListArr.splice(n, 1)
                })
            }

            function s(e, n) {
                return t.addIssueWatchList(e, n).then(function (e) {
                    return i(n, !0)
                })
            }

            function c(e, n) {
                return t.deleteIssueWatchList(e, n).then(function (e) {
                    return i(n, !0)
                })
            }

            function l(e) {
                var t;
                return t = u.watchListArr.filter(function (t) {
                    return t.id === e
                }), t && t.length > 0 && (t = t[0]), t
            }
            var u = {
                    watchListArr: [],
                    getWatchListDetail: i,
                    addWatchList: o,
                    updateWatchList: r,
                    deleteWatchList: a,
                    addIssueWatchList: s,
                    deleteIssueWatchList: c
                },
                d = n();
            return u
        }
        var t = "hbWatchListSvc";
        angular.module("app").factory(t, ["$q", "hbMarketSvc", e])
    }(),
    function () {
        "use strict";

        function e(e, t, n, i) {
            function o() {
                return i(t.servicesUri + "api/Cash/GetAllBankAccountInformation/", "post", {
                    accountId: n.defaultContract.contractId,
                    contractId: n.defaultContract.contractId
                })
            }

            function r(e) {
                return i(t.servicesUri + "api/Cash/getDepositsWithDrawals/" + e, "post", {
                    contractId: n.defaultContract.contractId
                })
            }

            function a(e) {
                return i(t.servicesUri + "api/Cash/getDepositAccountInformation/" + e, "post", {
                    contractId: n.defaultContract.contractId
                })
            }
            var s = {
                getAllBankAccountInformation: o,
                getDepositsWithDrawals: r,
                getDepositAccountInformation: a
            };
            return s
        }
        var t = "hbCashSvc";
        angular.module("app").factory(t, ["common", "urlServices", "hbContractManagementSvc", "serviceManager", e])
    }(),
    function () {
        "use strict";

        function e(e, t, n, i, o, r, a) {
            function s() {
                l();
                for (var e = [], n = 0, o = A.length; n < o; n++) N[n] > 0 && i.defaultContract.contractId && y(n, !0, !0);
                B.S && e.push(B.S), B.F && e.push(B.F), B.C && e.push(B.C), e.length > 0 ? t.$q.all(e)["finally"](function () {
                    c()
                }) : c()
            }

            function c() {
                l(), U = setInterval(function () {
                    s()
                }, E)
            }

            function l() {
                U && clearInterval(U)
            }

            function u(e) {
                N[e]++, y(e, !0)
            }

            function d(e) {
                --N[e] < 0 && (N[e] = 0)
            }

            function g(e, t) {
                return y(k, e, void 0, t)
            }

            function f(e, t) {
                return y(L, e, void 0, t)
            }

            function p(e, t) {
                return y(x, e, void 0, t)
            }

            function h(t, n, i) {
                return e.cancelCapitalMarketOrder(t, n, i).then(function (e) {
                    return y(k, !0), o.$broadcast(R, {
                        isTimer: !1
                    }), e
                })
            }

            function m(n) {
                var i = t.$q.defer();
                return n.contractId = M, e.registerCapitalMarketOrder(n).then(function (e) {
                    y(k, !0), o.$broadcast(R, {
                        isTimer: !1
                    }), i.resolve(e)
                }, function (e) {
                    e.data && 41 == e.data.ErrorCode && (y(k, !0), o.$broadcast(R, {
                        isTimer: !1
                    })), i.reject(e)
                }), i.promise
            }

            function v(n) {
                var i = t.$q.defer();
                return n.contractId = M, e.registerWithdrawal(n).then(function (e) {
                    y(x, !0), o.$broadcast(R, {
                        isTimer: !1
                    }), i.resolve(e)
                }, function (e) {
                    e.data && 41 == e.data.ErrorCode && (y(x, !0), o.$broadcast(R, {
                        isTimer: !1
                    })), i.reject(e)
                }), i.promise
            }

            function b(n) {
                var i = t.$q.defer();
                return n.accountId = M, e.registerFundsOrder(n).then(function (e) {
                    y(L, !0), o.$broadcast(R, {
                        isTimer: !1
                    }), i.resolve(e)
                }, function (e) {
                    e.data && 41 == e.data.ErrorCode && (y(L, !0), o.$broadcast(R, {
                        isTimer: !1
                    })), i.reject(e)
                }), i.promise
            }

            function S() {
                return e.cancelAllCapitalMarketOrders(M).then(function (e) {
                    return y(k, !0), o.$broadcast(R, {
                        isTimer: !1
                    }), e
                })
            }

            function y(t, n, i, r) {
                var a = A[t];
                return r && ($[a].length = 0, O[a] = {}), B[a] ? $[a] : $[a].length > 0 && !n ? $[a] : (B[a] = e.getCapitalMarketOrders(M, D[t], i).then(function (e) {
                    var t = e.data,
                        n = !1;
                    B[a] = null;
                    for (var r = 0, s = t.length; r < s; r++) {
                        var c = t[r];
                        T(c), C(c), w(c);
                        var l = c.preorderId || c.vigenciaId || c.sobId,
                            u = O[a][l];
                        u ? (c.lastTick = u.lastTick, u.hasOwnProperty("$$hashKey") && (c.$$hashKey = u.$$hashKey), _.isEqual(c, u) || (n = !0, c.lastTick = (new Date).getTime(), angular.extend(u, c))) : (n = !0, c.lastTick = (new Date).getTime(), O[a][l] = c, $[a].push(c))
                    }
                    return n && o.$broadcast(R, {
                        isTimer: i
                    }), $[a]
                })["catch"](function () {
                    B[a] = null
                }), $[a])
            }

            function T(e) {
                var t = "";
                if (e.algoTradingTypeId) switch (e.algoTradingTypeId) {
                    case 1:
                        t = "Blotter_JS_MSG_STATIC_ICEBERG";
                        break;
                    case 2:
                        t = "Blotter_JS_MSG_DYNAMIC_ICEBERG";
                        break;
                    case 3:
                        t = "Blotter_JS_MSG_TIMED_ICEBERG";
                        break;
                    case 4:
                        t = "Blotter_JS_MSG_BEST_EXECUTION_AT_SCALE_MARKET";
                        break;
                    case 5:
                        t = "Blotter_JS_MSG_BEST_EXECUTION_AT_STATIC_MARKET";
                        break;
                    case 6:
                        t = "Blotter_JS_MSG_STOP_MARKET";
                        break;
                    case 7:
                        t = "Blotter_JS_MSG_STOP_LIMIT";
                        break;
                    case 15:
                        t = "Blotter_JS_MSG_TRAILING_STOP";
                        break;
                    case 16:
                        t = "Blotter_JS_MSG_OCA";
                        break;
                    case 20:
                        t = "Blotter_JS_MSG_OTA"
                } else switch (e.capitalOrderTypeId) {
                    case 1:
                        t = "Blotter_JS_MSG_COMPRA_NORMAL";
                        break;
                    case 8:
                        t = "Blotter_JS_MSG_VENTA_NORMAL";
                        break;
                    case 13:
                        t = "Blotter_JS_MSG_VENTA_CORTO";
                        break;
                    case 16:
                        t = "Blotter_JS_MSG_COMPRA_GLOBAL";
                        break;
                    case 18:
                        t = "Blotter_JS_MSG_VENTA_GLOBAL";
                        break;
                    case 44:
                        t = "Blotter_JS_MSG_COMPRA_MPL_ACTIVA";
                        break;
                    case 45:
                        t = "Blotter_JS_MSG_VENTA_MPL_ACTIVA";
                        break;
                    case 46:
                        t = "Blotter_JS_MSG_COMPRA_MPL_PASIVA";
                        break;
                    case 47:
                        t = "Blotter_JS_MSG_VENTA_MPL_PASIVA";
                        break;
                    case 60:
                        t = "Blotter_JS_MSG_COMPRA_MPL_SENTIDO_OPUESTO";
                        break;
                    case 61:
                        t = "Blotter_JS_MSG_VENTA_MPL_SENTIDO_OPUESTO";
                        break;
                    case 62:
                        t = "Blotter_JS_MSG_COMPRA_MPL_VOLUMEN_OCULTO";
                        break;
                    case 63:
                        t = "Blotter_JS_MSG_VENTA_MPL_VOLUMEN_OCULTO"
                }
                P ? e.capitalOrderTypeIdText = P[t] : n.getResource(t).then(function (t) {
                    e.capitalOrderTypeIdText = t
                })
            }

            function C(e) {
                var t = "";
                t = e.bitBuy ? "Blotter_JS_MSG_bitBuyCOMPRA" : "Blotter_JS_MSG_bitBuyVENTA", P ? e.bitBuyText = P[t] : n.getResource(t).then(function (t) {
                    e.bitBuyText = t
                })
            }

            function w(e) {
                switch (e.gbmIntProcessStatus) {
                    case 1:
                        e.gbmIntProcessStatusText = "PENDING-NEW";
                        break;
                    case 2:
                        e.gbmIntProcessStatusText = "NEW";
                        break;
                    case 3:
                        e.gbmIntProcessStatusText = "CANCEL-REQ";
                        break;
                    case 4:
                        e.gbmIntProcessStatusText = "CANCEL-PENDING";
                        break;
                    case 5:
                        e.gbmIntProcessStatusText = "CANCELLED";
                        break;
                    case 6:
                        e.gbmIntProcessStatusText = "CANCEL-RJX";
                        break;
                    case 7:
                        e.gbmIntProcessStatusText = "FILLED";
                        break;
                    case 8:
                        e.gbmIntProcessStatusText = "PTLFIL";
                        break;
                    case 9:
                        e.gbmIntProcessStatusText = "REJECTED";
                        break;
                    case 10:
                        e.gbmIntProcessStatusText = "ACK-GBM";
                        break;
                    case 11:
                        e.gbmIntProcessStatusText = "REPLACE-PENDING";
                        break;
                    case 12:
                        e.gbmIntProcessStatusText = "REPLACED";
                        break;
                    case 13:
                        e.gbmIntProcessStatusText = "REPLACE-RJX";
                        break;
                    case 14:
                        e.gbmIntProcessStatusText = "DK-RECV";
                        break;
                    case 15:
                        e.gbmIntProcessStatusText = "TRADE-BUST";
                        break;
                    case 16:
                        e.gbmIntProcessStatusText = "CORRECTION";
                        break;
                    case 17:
                        e.gbmIntProcessStatusText = "RESTATED";
                        break;
                    case 20:
                        e.gbmIntProcessStatusText = "WORKING";
                        break;
                    case 21:
                        e.gbmIntProcessStatusText = "RECEIVED";
                        break;
                    case 22:
                        e.gbmIntProcessStatusText = "RJX-GBM";
                        break;
                    case 23:
                        e.gbmIntProcessStatusText = "NEW"
                }
            }

            function I(t) {
                if (t.sobId && O.S[t.sobId]) {
                    console.log(t);
                    var n = O.S[t.sobId];
                    angular.extend(n, t), t.gbmIntProcessStatus && (w(n), console.log("updated status " + n.gbmIntProcessStatusText)), T(n), n.lastTick = (new Date).getTime()
                } else {
                    var i = t.sobId;
                    e.getCapitalMarketOrder(M, e.InstrumentTypes.Stock, i).then(function (e) {
                        console.log(e.data)
                    })
                }
            }
            var P, M = i.defaultContract.contractId,
                O = {
                    S: {},
                    F: {},
                    C: {}
                },
                E = a.seg30,
                D = [e.InstrumentTypes.Stock, e.InstrumentTypes.Funds, e.InstrumentTypes.Cash],
                A = ["S", "F", "C"],
                k = 0,
                L = 1,
                x = 2,
                $ = {
                    S: [],
                    F: [],
                    C: []
                },
                B = {
                    S: null,
                    F: null,
                    C: null
                },
                R = "orders_changed",
                N = [0, 0, 0];
            n.load("Blotter").then(function (e) {
                P = e
            });
            var U;
            o.$watch(function () {
                return r.loggedIn()
            }, function (e, t) {
                e ? s() : (l(), $.S.length = 0, $.F.length = 0, $.C.length = 0, B = {
                    S: null,
                    F: null,
                    C: null
                })
            }), o.$watch(function () {
                return i.defaultContract.contractId
            }, function (e, t) {
                if (e) {
                    M = e, $.S.length = 0, $.F.length = 0, $.C.length = 0, O = {
                        S: {},
                        F: {},
                        C: {}
                    }, B = {
                        S: null,
                        F: null,
                        C: null
                    };
                    for (var n = 0, i = A.length; n < i; n++) {
                        A[n];
                        y(n)
                    }
                }
            });
            var F = {
                registerCapitalMarketOrder: m,
                registerWithdrawal: v,
                registerFundsOrder: b,
                cancelCapitalMarketOrder: h,
                cancelAllCapitalMarketOrders: S,
                getStockOrders: g,
                getFundsOrders: f,
                getCashOrders: p,
                OrdersChangedEvent: R,
                subscribeToOrders: u,
                unsubscribeFromOrders: d,
                StockOrders: k,
                CashOrders: x,
                FundOrders: L,
                updateCapitalMarketOrder: I
            };
            return F
        }
        var t = "hbOrderSvc";
        angular.module("app").factory(t, ["hbOperationSvc", "common", "hbGlobalizationSvc", "hbContractManagementSvc", "$rootScope", "hbSecuritySvc", "timeoutConfig", e])
    }(),
    function () {
        "use strict";

        function e(e) {
            function t(t) {
                var n = "";
                if (t.algoTradingTypeId) switch (t.algoTradingTypeId) {
                    case 1:
                        n = "Blotter_JS_MSG_STATIC_ICEBERG";
                        break;
                    case 2:
                        n = "Blotter_JS_MSG_DYNAMIC_ICEBERG";
                        break;
                    case 3:
                        n = "Blotter_JS_MSG_TIMED_ICEBERG";
                        break;
                    case 4:
                        n = "Blotter_JS_MSG_BEST_EXECUTION_AT_SCALE_MARKET";
                        break;
                    case 5:
                        n = "Blotter_JS_MSG_BEST_EXECUTION_AT_STATIC_MARKET";
                        break;
                    case 6:
                        n = "Blotter_JS_MSG_STOP_MARKET";
                        break;
                    case 7:
                        n = "Blotter_JS_MSG_STOP_LIMIT";
                        break;
                    case 15:
                        n = "Blotter_JS_MSG_TRAILING_STOP";
                        break;
                    case 16:
                        n = "Blotter_JS_MSG_OCA"
                } else switch (t.capitalOrderTypeId) {
                    case 1:
                        n = "Blotter_JS_MSG_COMPRA_NORMAL";
                        break;
                    case 8:
                        n = "Blotter_JS_MSG_VENTA_NORMAL";
                        break;
                    case 13:
                        n = "Blotter_JS_MSG_VENTA_CORTO";
                        break;
                    case 16:
                        n = "Blotter_JS_MSG_COMPRA_GLOBAL";
                        break;
                    case 18:
                        n = "Blotter_JS_MSG_VENTA_GLOBAL";
                        break;
                    case 44:
                        n = "Blotter_JS_MSG_COMPRA_MPL_ACTIVA";
                        break;
                    case 45:
                        n = "Blotter_JS_MSG_VENTA_MPL_ACTIVA";
                        break;
                    case 46:
                        n = "Blotter_JS_MSG_COMPRA_MPL_PASIVA";
                        break;
                    case 47:
                        n = "Blotter_JS_MSG_VENTA_MPL_PASIVA";
                        break;
                    case 60:
                        n = "Blotter_JS_MSG_COMPRA_MPL_SENTIDO_OPUESTO";
                        break;
                    case 61:
                        n = "Blotter_JS_MSG_VENTA_MPL_SENTIDO_OPUESTO";
                        break;
                    case 62:
                        n = "Blotter_JS_MSG_COMPRA_MPL_VOLUMEN_OCULTO";
                        break;
                    case 63:
                        n = "Blotter_JS_MSG_VENTA_MPL_VOLUMEN_OCULTO"
                }
                e.getResource(n).then(function (e) {
                    t.capitalOrderTypeIdText = e
                })
            }

            function n(t) {
                var n = "";
                n = t.bitBuy ? "Blotter_JS_MSG_bitBuyCOMPRA" : "Blotter_JS_MSG_bitBuyVENTA", e.getResource(n).then(function (e) {
                    t.bitBuyText = e
                })
            }

            function i(e) {
                switch (e.gbmIntProcessStatus) {
                    case 1:
                        e.gbmIntProcessStatusText = "PENDING-NEW";
                        break;
                    case 2:
                        e.gbmIntProcessStatusText = "NEW";
                        break;
                    case 3:
                        e.gbmIntProcessStatusText = "CANCEL-REQ";
                        break;
                    case 4:
                        e.gbmIntProcessStatusText = "CANCEL-PENDING";
                        break;
                    case 5:
                        e.gbmIntProcessStatusText = "CANCELLED";
                        break;
                    case 6:
                        e.gbmIntProcessStatusText = "CANCEL-RJX";
                        break;
                    case 7:
                        e.gbmIntProcessStatusText = "FILLED";
                        break;
                    case 8:
                        e.gbmIntProcessStatusText = "PTLFIL";
                        break;
                    case 9:
                        e.gbmIntProcessStatusText = "REJECTED";
                        break;
                    case 10:
                        e.gbmIntProcessStatusText = "ACK-GBM";
                        break;
                    case 11:
                        e.gbmIntProcessStatusText = "REPLACE-PENDING";
                        break;
                    case 12:
                        e.gbmIntProcessStatusText = "REPLACED";
                        break;
                    case 13:
                        e.gbmIntProcessStatusText = "REPLACE-RJX";
                        break;
                    case 14:
                        e.gbmIntProcessStatusText = "DK-RECV";
                        break;
                    case 15:
                        e.gbmIntProcessStatusText = "TRADE-BUST";
                        break;
                    case 16:
                        e.gbmIntProcessStatusText = "CORRECTION";
                        break;
                    case 17:
                        e.gbmIntProcessStatusText = "RESTATED";
                        break;
                    case 20:
                        e.gbmIntProcessStatusText = "WORKING";
                        break;
                    case 21:
                        e.gbmIntProcessStatusText = "RECEIVED";
                        break;
                    case 22:
                        e.gbmIntProcessStatusText = "RJX-GBM";
                        break;
                    case 23:
                        e.gbmIntProcessStatusText = "NEW"
                }
            }
            var o = {
                setOrderTypeText: t,
                setDirectionText: n,
                setStatusText: i
            };
            return o
        }
        var t = "hbOrderGloblizationSvc";
        angular.module("app").factory(t, ["hbGlobalizationSvc", e])
    }(),
    function () {
        "use strict";

        function e(e, t, n, i, o, r, a, s) {
            function c(e) {
                l(e).then(function () {
                    n.getContractProperties(e).then(function (t) {
                        d(t.data, e).then(function () {
                            u(t.data.contractRisk), g(t.data), f()
                        })
                    })
                })
            }

            function l(n) {
                var o, r, c, l = t.$q.defer();
                return a.initialized().then(function () {
                    o = a.getAggPositionByValueType(a.ValueTypes.Total, void 0, n).then(function (e) {
                        return T = e ? e : {
                            marketValueSubTot: 0
                        }, e
                    }), r = a.getAggPositionByValueType(a.ValueTypes.DebtInvesmentSocieties, void 0, n).then(function (e) {
                        v = 0;
                        var t;
                        switch (i.defaultContractDetail.legalPersonalityType) {
                            case 1:
                                t = "GBMF2 BF";
                                break;
                            case 2:
                                t = "GBMF2 BM";
                                break;
                            default:
                                throw "Legal Personality Type not valid."
                        }
                        if (e)
                            for (var n = e.posValueTypeDetail, o = 0, r = n.length; o < r; o++) 2 === i.defaultContractDetail.clientType ? n[o].position && n[o].position.instrument && ("GBMF2 BF" !== n[o].position.instrument.issueID && "GBMF2 BM" !== n[o].position.instrument.issueID || (v += n[o].position.instrument.lastPrice * n[o].position.shares)) : n[o].position && n[o].position.instrument && n[o].position.instrument.issueID === t && (v += n[o].position.instrument.lastPrice * n[o].position.shares);
                        return e
                    }), c = a.getAggPositionByValueType(a.ValueTypes.Cash, void 0, n).then(function (e) {
                        return m = e ? e.marketValueSubTot : 0, e
                    }), e.all([o, r, c]).then(function () {
                        l.resolve()
                    })
                }, function (e) {
                    s.logging(e.data, s.loggingTypes.EXCEPTION), l.reject("Error")
                }), l.promise
            }

            function u(e) {
                b.pendingOrdersRisk = e.pendingOrdersRisk, b.registeredOrdersValue = e.registeredOrdersValue, b.reportos = e.reportos, b.virtualSalesGBMF2 = e.virtualSalesGBMF2
            }

            function d(e, o) {
                var r = t.$q.defer();
                return i.defaultContractDetail.tradeMargin ? n.getCapitalMarketContractRisk(i.defaultContract.contractId, o).then(function (t) {
                    S = e.marginHB;
                    var n = t.data;
                    S -= n.registeredOrdersValue, S -= n.pendingOrdersRisk, S -= n.reportos, S -= n.virtualSalesGBMF2, S < 0 && (S = 0), r.resolve(S)
                }, function (e) {
                    void 0 !== e && s.logging(e.data, s.loggingTypes.EXCEPTION), r.reject("Error")
                }) : (S = e.marginHB, r.resolve(S)), r.promise
            }

            function g(e) {
                y = e.sellingPower
            }

            function f() {
                h.cash = m, h.gbmf2 = v, h.capitalMarketRisks.pendingOrdersRisk = b.pendingOrdersRisk, h.capitalMarketRisks.registeredOrdersValue = b.registeredOrdersValue, h.capitalMarketRisks.reportos = b.reportos, h.capitalMarketRisks.virtualSalesGBMF2 = b.virtualSalesGBMF2, h.margin = S, h.sellingPower = y, h.buyingPower = h.cash + h.gbmf2 - h.capitalMarketRisks.virtualSalesGBMF2 + h.capitalMarketRisks.reportos - h.capitalMarketRisks.pendingOrdersRisk, h.total = T
            }

            function p() {
                return h
            }
            var h = {
                    capitalMarketRisks: {
                        pendingOrdersRisk: 0,
                        registeredOrdersValue: 0,
                        reportos: 0,
                        virtualSalesGBMF2: 0
                    },
                    gbmf2: 0,
                    cash: 0,
                    margin: 0,
                    sellingPower: 0,
                    buyingPower: 0,
                    total: {},
                    lastTick: new Date
                },
                m = 0,
                v = 0,
                b = {},
                S = 0,
                y = 0,
                T = 0;
            return o.$watch(function () {
                return i.defaultContract.contractId
            }, function (e, t) {
                e && c()
            }), o.$on(r.OrdersChangedEvent, function (e, t) {
                c(t.isTimer)
            }), o.$on(a.updateTotalsEvent, function (e, t) {
                c(t.isTimer)
            }), {
                getTotals: p,
                updateTotals: c
            }
        }
        var t = "hbTotalsSvc";
        angular.module("app").factory(t, ["$q", "common", "hbOperationSvc", "hbContractManagementSvc", "$rootScope", "hbOrderSvc", "hbPositionSvc", "hbLoggingSvc", e])
    }(),
    function () {
        "use strict";

        function e(e, t, n, i) {
            function o() {
                return s
            }

            function r(e) {
                s = e
            }

            function a() {
                u.state.progress = 0, u.state.currentTask = i.getResource("Dashboard_LoadingConfiguration", !0), u.totalWidgetCount = 0, u.initializedWidgetCount = 0
            }
            var s = !1,
                c = 0,
                l = n.widgets,
                u = {
                    state: {
                        progress: 0,
                        currentTask: ""
                    },
                    progress: 0,
                    currentTask: "",
                    totalWidgetCount: 0,
                    initializedWidgetCount: 0,
                    reset: a,
                    setInitialLoading: r,
                    isInitialLoading: o
                };
            return e.$on("dashboard.retrieving_dashboards", function () {
                u.state.currentTask = i.getResource("Dashboard_RetrievingDashboards", !0)
            }), e.$on("dashboard.dashboards_retrieved", function (e, t) {
                c = t, u.state.currentTask = i.getResource("Dashboard_DashboardsRetrieved", !0), u.state.progress = parseInt(2 / 6 * 10)
            }), e.$on("dashboard.retrieving_widget_types", function () {
                u.state.currentTask = i.getResource("Dashboard_RetrievingWidgets", !0)
            }), e.$on("dashboard.widget_types_retrieved", function () {
                0 === c ? (u.state.progress = 100, t.$broadcast("loading.tasks_completed")) : (u.state.currentTask = i.getResource("Dashboard_WidgetsRetrieved", !0), u.state.progress = parseInt(4 / 6 * 10))
            }), e.$on("dashboard.retrieving_dashboard_widgets", function () {
                u.state.currentTask = i.getResource("Dashboard_RetrievingDashboardWidgets", !0)
            }), e.$on("dashboard.dashboard_widgets_retrieved", function (e, n) {
                u.state.currentTask = i.getResource("Dashboard_DashboardWidgetsRetrieved", !0), u.totalWidgetCount += n, u.state.progress = parseInt(10), 0 === u.totalWidgetCount && (u.state.progress = 100, t.$broadcast("loading.tasks_completed"))
            }), e.$on("dashboard.widget_initialized", function (e, o) {
                return u.state.currentTask = o + " " + i.getResource("Dashboard_WidgetInitialized", !0), u.initializedWidgetCount++, u.state.progress = parseInt(u.initializedWidgetCount / u.totalWidgetCount * 90 + 10), n.isMobile.value ? void setTimeout(function () {
                    u.state.progress = 100, t.$broadcast("loading.tasks_completed")
                }, 100) : void(l.active.length <= u.initializedWidgetCount && setTimeout(function () {
                    t.$broadcast("loading.tasks_completed")
                }, 100))
            }), u
        }
        var t = "hbLoadingSvc";
        angular.module("app").factory(t, ["$rootScope", "common", "hbDashboardSvc", "hbGlobalizationSvc", e])
    }(),
    function () {
        "use strict";

        function e(e, t, n, i) {
            function o() {
                if (void 0 !== e.getUser().user) {
                    if (p) return;
                    var n = new Date;
                    if ((n.getTime() - l.getTime()) / 1e3 < 60) return;
                    return p = !0, t({
                        method: "POST",
                        url: i.servicesUri + "api/Security/SlideSession",
                        data: {}
                    }).then(function () {
                        l = new Date, p = !1
                    })["catch"](function (e) {
                        p = !1
                    })
                }
            }

            function r() {
                var t = f.Normal,
                    n = a();
                return u === -1 && d === -1 ? t = f.Normal : 0 !== d && n >= d && e.getUser().isReadAndWrite ? e.$broadcast("sessionSlider.writeSessionExpired") : 0 !== u && n >= u ? (t = f.Expired, e.$broadcast("sessionSlider.sessionExpired")) : t = 0 !== d && n >= d - g && e.getUser().isReadAndWrite ? f.ExpiringWrite : 0 !== u && n >= u - g ? f.Expiring : f.Normal, t
            }

            function a() {
                var e = Math.abs(new Date - l);
                return e / 6e4
            }

            function s(e, t) {
                u = e - 1, d = t - 1
            }

            function c() {
                var t = Math.abs(new Date - l),
                    n = t / 1e3,
                    i = 0;
                return i = e.getUser().isReadAndWrite ? 60 * d - n : 60 * u - n
            }
            var l = new Date,
                u = 480,
                d = 180,
                g = 5,
                f = {
                    Normal: "Normal",
                    ExpiringWrite: "ExpiringWrite",
                    Expiring: "Expiring",
                    Expired: "Expired"
                },
                p = !1,
                h = {
                    slideSession: o,
                    getSessionStatus: r,
                    SessionStatus: f,
                    setSessionLength: s,
                    getSecondsToExpire: c
                };
            return h
        }
        angular.module("app").factory("hbSessionSliderSvc", ["$rootScope", "$http", "$interval", "urlServices", e])
    }(),
    function () {
        "use strict";

        function e(e) {
            function t(t) {
                r[t] = e(t)
            }

            function n(e, t) {
                t = t || "default";
                var n = r[t].get(o(e)),
                    i = (new Date).getTime();
                if (n.duration > i - n.lastUpdate) return n.value
            }

            function i(e, t, n, i) {
                var a = 0;
                i.hours && (a += 60 * i.hours * 60 * 1e3), i.minutes && (a += 60 * i.minutes * 1e3), i.seconds && (a += 1e3 * i.seconds), n = n || "default", r[n].put(o(e), {
                    value: t,
                    duration: a,
                    lastUpdate: (new Date).getTime()
                })
            }

            function o(e) {
                return "object" == typeof e ? JSON.stringify(e) : e
            }
            var r = {};
            return r["default"] = e("default"), {
                init: t,
                get: n,
                put: i
            }
        }
        angular.module("app").factory("hbCacheSvc", ["$cacheFactory", e])
    }(),
    function () {
        "use strict";
        angular.module("app").service("hbBrowserSvc", [function () {
            return function () {
                var e = window.navigator.userAgent,
                    t = {
                        chrome: /chrome/i,
                        safari: /safari/i,
                        firefox: /firefox/i,
                        ie: /internet explorer/i
                    };
                for (var n in t)
                    if (t[n].test(e)) return n;
                return "unknown"
            }
        }])
    }(),
    function () {
        "use strict";

        function e(e, t, n, i, o, r, a, s) {
            function c(e, o) {
                var s = n.$q.defer(),
                    c = t("filter")(m.active, {
                        widgetTypeId: o
                    }, !0);
                return p(c[0].widgetTypeId).then(function (t) {
                    if (t < c[0].maxInstances) {
                        var n = {
                            applicationId: "",
                            employeeId: "",
                            widgetId: "",
                            dashBoardId: v.id,
                            widgetTypeId: o,
                            title: e,
                            configuration: JSON.stringify({
                                widgetTypeId: o
                            })
                        };
                        i.addUserDashBoardWidget(n).then(function (t) {
                            var n = {
                                id: t.data.response,
                                size_y: c[0].minRow,
                                size_x: c[0].minCol,
                                min_sizey: c[0].minRow,
                                min_sizex: c[0].minCol,
                                max_sizey: c[0].maxRow,
                                max_sizex: c[0].maxCol,
                                name: e,
                                init: 1,
                                widgetTypeId: c[0].widgetTypeId
                            };
                            h.active.push(n), setTimeout(function () {
                                l(), y.value && g(n, function () {})
                            }, 2e3), s.resolve(t.data)
                        }, function (e) {
                            r.logging(e.data, r.loggingTypes.EXCEPTION)
                        })
                    } else r.logging(a.getResource("Dashboard_WidgetInstances", !0, ""), r.loggingTypes.WARNING)
                }), s.promise
            }

            function l() {
                v.id && i.updateWidgetsInUserDashBoard(v.id, h.active).then(function (e) {
                    return r.logging("User Dashboard updated successfully!!", r.loggingTypes.DEBUG), e
                }, function (e) {
                    r.logging(e.data, r.loggingTypes.EXCEPTION)
                })
            }

            function u() {
                return T = {
                    value: 0
                }, i.getWidgetsInUserDashBoard(v.id).then(function (e) {
                    return e
                }, function (e) {
                    r.logging(e.data, r.loggingTypes.EXCEPTION)
                })
            }

            function d(e) {
                for (var t = 0; t < h.active.length; t++) f(h.active[t].id);
                e(!0)
            }

            function g(t, n) {
                var i = t.id;
                d(function () {
                    T.value = i, $("#locator-" + i).height(S.value - 30 + "px"), $("#locator-" + i).css("margin", "10px"), $("#widget-title-" + i).height("36px"), $("#widget-tools-" + i).show(), $("#widget-header-" + i).height("50px"), $("#" + i).height("99%"), s(function () {
                        e.$emit("mobile-resize-" + i, {
                            viewHeight: S.value
                        })
                    }, 500), n(!0)
                })
            }

            function f(e) {
                $("#" + e).height(0), $("#locator-" + e).height(0), $("#widget-title-" + e).height(0), $("#widget-header-" + e).height(0), $("#widget-tools-" + e).hide(), $("#locator-" + e).css("margin", "0px")
            }

            function p(e) {
                var t = n.$q.defer(),
                    o = 0,
                    r = 0;
                return u().then(function (n) {
                    if (0 === n.data.length) t.resolve(o);
                    else
                        for (var a = 0; a < n.data.length; a++) i.getWidgetConfiguration(n.data[a].id).then(function (i) {
                            r++, i.data.widgetTypeId === e && o++, r === n.data.length && t.resolve(o)
                        })
                }), t.promise
            }
            var h = {
                    active: [],
                    mobileSelected: []
                },
                m = {
                    active: []
                },
                v = {
                    id: null
                },
                b = {
                    relocation: !1
                },
                S = {
                    value: 0
                },
                y = {
                    value: !1
                },
                T = {
                    value: 0
                },
                C = {
                    selectedDashboard: v,
                    widgets: h,
                    userWidgetsTypes: m,
                    gridsterContainer: b,
                    addUserDashBoardWidget: c,
                    updateWidgetsInUserDashboard: l,
                    getWidgetsInUserDashBoard: u,
                    showCurrentWidget: g,
                    hideAllWidgets: d,
                    viewHeight: S,
                    isMobile: y,
                    currentWidget: T
                };
            return e.$watch(function () {
                return T.value
            }, function (e, n) {
                if (e != n && y.value && T.value) {
                    var i = t("filter")(h.active, {
                        id: T.value
                    }, !0);
                    angular.copy(i, h.mobileSelected), s(function () {
                        g(h.mobileSelected[0], function () {})
                    }, 1e3)
                }
            }), e.$watch(function () {
                return h.active.length
            }, function (e, n) {
                var i = t("filter")(h.active, {
                    id: T.value
                }, !0);
                0 == i.length && h.mobileSelected.splice(0, 1)
            }), e.$watch(function () {
                return o.loggedIn()
            }, function (e, t) {
                e || (h.active.length = 0)
            }), C
        }
        var t = "hbDashboardSvc";
        angular.module("app").factory(t, ["$rootScope", "$filter", "common", "hbAppManagementSvc", "hbSecuritySvc", "hbLoggingSvc", "hbGlobalizationSvc", "$timeout", e])
    }(),
    function () {
        "use strict";

        function e(e) {
            function t() {
                n(), i = e.$watch(function () {
                    r.count += 1, r.vb && console.log("digest")
                }), o = setInterval(function () {
                    var e = new Date,
                        t = (e.getTime() - r.ticker.getTime()) / 1e3,
                        n = r.count / t,
                        i = e.getHours() + ":" + e.getMinutes() + ":" + e.getSeconds();
                    console.log("Avg digest per min " + i + " : " + n), r.ticker = e, r.count = 0
                }, 6e4)
            }

            function n() {
                i && i(), o && clearInterval(o)
            }
            var i, o, r = {
                    count: 0,
                    ticker: new Date,
                    vb: !1
                },
                a = {
                    start: t,
                    stop: n,
                    avg: r
                };
            return a
        }
        var t = "hbMonitoSvc";
        angular.module("app").factory(t, ["$rootScope", e])
    }(),
    function () {
        "use strict";

        function e(e, t) {
            function n(e) {
                for (var t = 0; t < e.length; t++) {
                    var n = e[t].string,
                        i = e[t].subString;
                    if (n.indexOf(e[t].subString) !== -1) {
                        var o = {
                            versionSearchString: i,
                            identity: e[t].identity
                        };
                        return o
                    }
                }
            }

            function i(e, t) {
                var n = e.indexOf(t.versionSearchString);
                if (n !== -1) {
                    var i = e.indexOf("rv:");
                    return "trident" === t.versionSearchString && i !== -1 ? parseFloat(e.substring(i + 3)) : parseFloat(e.substring(n + t.versionSearchString.length + 1))
                }
            }

            function o() {
                var e = n(r),
                    t = navigator.userAgent.toLowerCase();
                a = e.identity || "other", s = i(t, e) || i(navigator.appVersion, e) || "unknown", ("explorer" == a && s < 10 || "chrome" == a && s < 24 || "firefox" == a && s < 18 || "opera" == a) && (window.location.href = "LoadPartial/BrowserNotSuppported/Index"), t.indexOf("safari/") !== -1 && t.indexOf("windows") !== -1 && t.indexOf("chrom") === -1 && (window.location.href = "LoadPartial/BrowserNotSuppported/Index")
            }
            var r = [{
                    string: navigator.userAgent.toLowerCase(),
                    subString: "chrome",
                    identity: "chrome"
                }, {
                    string: navigator.userAgent.toLowerCase(),
                    subString: "msie",
                    identity: "explorer"
                }, {
                    string: navigator.userAgent.toLowerCase(),
                    subString: "trident",
                    identity: "explorer"
                }, {
                    string: navigator.userAgent.toLowerCase(),
                    subString: "firefox",
                    identity: "firefox"
                }, {
                    string: navigator.userAgent.toLowerCase(),
                    subString: "safari",
                    identity: "safari"
                }, {
                    string: navigator.userAgent.toLowerCase(),
                    subString: "opera",
                    identity: "opera"
                }],
                a = "",
                s = "",
                c = {
                    activate: o(),
                    browser: a,
                    version: s
                };
            return c
        }
        angular.module("app").factory("hbCheckBrowserSvc", ["$http", "$location", e])
    }();
