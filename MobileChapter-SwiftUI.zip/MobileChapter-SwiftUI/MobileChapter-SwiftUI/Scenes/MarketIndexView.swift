//
//  ContentView.swift
//  MobileChapter-SwiftUI
//
//  Created by Isaac Velazquez on 31/08/20.
//  Copyright © 2020 Grupo Bursátil Mexicano. All rights reserved.
//

import SwiftUI
import SwiftUICharts

struct MarketIndexView: View {
    @State var results = [MarketIndexModel]()
    @State var prices = [Double]()
    @State var showingAlert = false
    
    let timerTime: TimeInterval = 30
    var marketIndexUseCase: MarketIndexUseCase {
        let apiClient = ApiClientImplementation()
        let marketIndexApiGateway = MarketIndexApiGatewayImplementation(apiClient: apiClient)
        return MarketIndexUseCaseImplementation(marketIndexApiGateway: marketIndexApiGateway)
    }
    
    var body: some View {
        VStack {
            //Chart
            LineView(data: prices, title: "IPC")
            //List
            List(results, id: \.volume) { item in
                VStack(alignment: .leading) {
                    HStack {
                        Text("Price").bold()
                        Text(item.formatPrice)
                    }
                    .padding([.top, .bottom], 8)
                    
                    HStack {
                        Text("Volume").bold()
                        Text(String(item.volume))
                    }
                    .padding([.top, .bottom], 8)
                    
                    HStack {
                        Text("Hour").bold()
                        Text(item.formatDate)
                    }
                    .padding([.top, .bottom], 8)
                }
                .gesture(TapGesture()
                            .onEnded({ _ in
                                self.showingAlert.toggle()
                }))
                    .alert(isPresented: self.$showingAlert) {
                        Alert(title: Text("Detail"),
                              message: Text("Price" + item.formatPrice),
                              dismissButton: .default(Text("ok")))
                    }
            }
        }
        .padding()
        .onAppear(perform: self.scheduledTimer)
    }
    
    func scheduledTimer() {
        //First request
        fetchData()
        //Scheduled timer
        Timer.scheduledTimer(withTimeInterval: timerTime, repeats: true) { timer in
            self.fetchData()
        }
    }
    
    func fetchData() {
        marketIndexUseCase.fetchIpcPoints { (result) in
            switch result {
            case .success(let response):
                DispatchQueue.main.async {
                    self.prices = response.map { $0.price }
                    self.results = response
                }
            case .failure(let error):
                ApiLog.error("Error \(String(describing: error.message))")
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        MarketIndexView()
    }
}
