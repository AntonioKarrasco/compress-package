//
//  SignInView.swift
//  MobileChapter-SwiftUI
//
//  Created by Isaac Velazquez on 01/09/20.
//  Copyright © 2020 Grupo Bursátil Mexicano. All rights reserved.
//

import SwiftUI
import SwiftUICharts

struct SignInView: View {
    @State var isAuthenticated = false
    @State var imageNum = 2
    @State var imageName = "background1"
    @State private var fadeOut = false
    
    let timer = Timer.publish(every: 2,
                              on: .main,
                              in: .common).autoconnect()

    var body: some View {
        ZStack {
            Image(imageName)
            .resizable()
            .edgesIgnoringSafeArea(.all)
            .animation(.easeOut(duration: 0.25))
            .opacity(fadeOut ? 0.6 : 1)
            .onReceive(timer) { input in
                self.imageNum += 1
                if self.imageNum > 4 {
                    self.imageNum = 2
                }
                self.fadeOut.toggle()
                DispatchQueue.main.asyncAfter(deadline: .now()) {
                    withAnimation {
                        self.imageName = "background" + String(self.imageNum)
                        self.fadeOut.toggle()
                    }
                }
            }
            
            VStack {
                Spacer()
                
                Spacer()
                
                Image("gbm")
                
                Spacer()
               
                Button(action: {
                    //TODO
                }) {
                    Text("Abre tu cuenta")
                    .bold()
                    .frame(minWidth: 0,
                           maxWidth: .infinity)
                    .padding()
                    .background(Color.white)
                }
                .foregroundColor(.black)
                .cornerRadius(100)
                .frame(minWidth: 0, maxWidth: .infinity)
                .padding([.trailing, .leading], 48)
                .padding(.bottom, 40)
                
                Button(action: {
                    //Biometric Authentication
                    self.biometricAuthentication()
                }) {
                    HStack {
                        Text("¿Ya tienes una cuenta?")
                        Text("Inicia sesión")
                        .fontWeight(.bold)
                            .underline()
                    }
                    .foregroundColor(.white)
                }
                .frame(minWidth: 0,
                       maxWidth: .infinity)
                .padding(.bottom, 60)
                .sheet(isPresented: $isAuthenticated) {
                    MarketIndexView()
                }
            }
        }
    }
    
    func biometricAuthentication() {
        let authentication = BiometricAuthenticationManager()
        authentication.authenticationBiometrics { (result) in
            switch result {
            case let .success(response):
                self.isAuthenticated = response
            case let .failure(error):
                ApiLog.error(error.message ?? .empty)
                self.isAuthenticated = false
            }
        }
    }
}


struct SignInView_Previews: PreviewProvider {
    static var previews: some View {
        SignInView()
    }
}
