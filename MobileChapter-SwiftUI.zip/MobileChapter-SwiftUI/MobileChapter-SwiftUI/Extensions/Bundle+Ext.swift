//
//  Bundle+Ext.swift
//  MobileChapter-SwiftUI
//
//  Created by Isaac Velazquez on 31/08/20.
//  Copyright © 2020 Grupo Bursátil Mexicano. All rights reserved.
//

import Foundation

extension Bundle {
    var bundleName: String {
        let bundle = Bundle(for: ApiLog.self)
        return bundle.infoDictionary?["CFBundleName"] as? String ?? .empty
    }
}
