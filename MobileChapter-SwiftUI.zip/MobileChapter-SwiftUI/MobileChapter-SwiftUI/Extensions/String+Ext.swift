//
//  String+Ext.swift
//  MobileChapter-SwiftUI
//
//  Created by Isaac Velazquez on 31/08/20.
//  Copyright © 2020 Grupo Bursátil Mexicano. All rights reserved.
//

import Foundation

extension String {
    static let empty               = ""
    static let newLine             = "\n"
    static let usePasscode         = "Por favor utiliza tu contraseña"
    static let reasonAutentication = "Se requiere la autenticación para acceder a la aplicación"
}
