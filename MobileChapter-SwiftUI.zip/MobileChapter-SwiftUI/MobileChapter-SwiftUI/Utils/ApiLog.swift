//
//  APILog.swift
//  ApiGateway
//
//  Created by gbmlocaladmin on 06/03/18.
//  Copyright © 2018 GBM. All rights reserved.
//

import UIKit

enum LogType: String {
    case info
    case error 
}

class ApiLog {
    static func info(_ message: String) {
        log(message, logType: .info)
    }
    
    static func error(_ message: String) {
        log(message, logType: .error)
    }
    
    private static func log(_ message: String, logType: LogType) {
        let bundle = Bundle(for: ApiLog.self)
        var completeMessage = bundle.bundleName
        completeMessage += " "
        completeMessage += logType.rawValue
        completeMessage += " "
        completeMessage += message
        print(completeMessage)
    }
}
