//
//  BiometricManager.swift
//  MobileChapter-SwiftUI
//
//  Created by Isaac Velazquez on 02/09/20.
//  Copyright © 2020 Grupo Bursátil Mexicano. All rights reserved.
//

import LocalAuthentication

typealias BiometricAuthenticationManagerHandler = (_ authorized: ApiResult<Bool>) -> Void

class BiometricAuthenticationManager {
    func authenticationBiometrics(completionHandler: @escaping BiometricAuthenticationManagerHandler) {
        let localAuthenticationContext = LAContext()
        localAuthenticationContext.localizedFallbackTitle = .usePasscode
        var authorizationError: NSError?
        if localAuthenticationContext.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics,
                                                        error: &authorizationError) {
            
            localAuthenticationContext.evaluatePolicy(.deviceOwnerAuthenticationWithBiometrics,
                                                      localizedReason: .reasonAutentication) { success, evaluateError in
                
                if success {
                    DispatchQueue.main.async() {
                        completionHandler(.success(true))
                    }
                    
                } else {
                    guard let error = evaluateError else {
                        return
                    }
                    ApiLog.error(error.localizedDescription)
                    completionHandler(.success(false))
                }
            }
        } else {
            guard let error = authorizationError else {
                return
            }
            ApiLog.error(error.localizedDescription)
            completionHandler(.success(false))
        }
    }
}
