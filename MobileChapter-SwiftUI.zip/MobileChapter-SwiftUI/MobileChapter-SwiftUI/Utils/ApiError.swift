//
//  ApiError.swift
//  MobileChapter-SwiftUI
//
//  Created by Isaac Velazquez on 31/08/20.
//  Copyright © 2020 Grupo Bursátil Mexicano. All rights reserved.
//

import Foundation

struct ApiError: Error, Decodable {
    var code: String?
    var eventId: String?
    var message: String?
    
    init(data: Data?) {
        guard let data = data else { self = ApiError.unexpectedError ; return }
        do {
            self = try ApiError.decode(data: data)
        } catch let error {
            ApiLog.error(error.localizedDescription)
        }
    }
    
    init(code: String,
         eventId: String,
         message: String) {
        self.code = code
        self.eventId = eventId
        self.message = message
    }
    static var unexpectedError: ApiError {
        return ApiError(code: "0",
                        eventId: "0",
                        message: "¡Lo sentimos! Ocurrió un error en el sistema, por favor inténtalo de nuevo")
    }
    
    static var unauthorizedError: ApiError {
        return ApiError(code: "1",
                        eventId: "1",
                        message: "No autorizado")
        
    }
    
    static var networkRequestError: ApiError {
        return ApiError(code: "2",
                        eventId: "2",
                        message: "Network request error - no other information")
        
    }
    
    static var notFound: ApiError {
        return ApiError(code: "3",
                        eventId: "3",
                        message: "¡Lo sentimos! El recurso no existe")
    }
}
