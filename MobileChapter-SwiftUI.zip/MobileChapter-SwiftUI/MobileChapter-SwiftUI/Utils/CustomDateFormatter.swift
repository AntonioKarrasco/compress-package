//
//  CvDateFormatter.swift
//  GBMPlatform
//
//  Created by gbmlocaladmin on 05/12/17.
//  Copyright © 2017 GBM Mobile. All rights reserved.
//

import Foundation

class CustomDateFormatter {
    ///////////////////////////////////////
    // MARK: Constants
    ///////////////////////////////////////
    static let hourFormatter = "HH:mm:ss"
    
    static func hourDate(_ date: Date) -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = CustomDateFormatter.hourFormatter
        return dateFormatter.string(from: date)
    }
}
