//
//  PercentageFormatter.swift
//  Homebroker
//
//  Created by GBM Mobile on 9/13/18.
//  Copyright © 2018 GBM Grupo Bursatil Mexicano. All rights reserved.
//

import Foundation

class PercentageFormatter {    
    static func formatWithDecimals(value: Double,
                                   showPrefix: Bool = false) -> String {
        let percentFormatter = NumberFormatter()
        percentFormatter.numberStyle = .percent
        percentFormatter.maximumFractionDigits = 2
        percentFormatter.minimumFractionDigits = .zero
        if showPrefix && value != 0 {
            if value > 0 {
                percentFormatter.positivePrefix = percentFormatter.plusSign + percentFormatter.currencySymbol
            } else {
                percentFormatter.positivePrefix = percentFormatter.minusSign + percentFormatter.currencySymbol
            }
        }
        guard let percentString = percentFormatter.string(from: NSNumber(value: value)) else { return formatWithDecimals(value: 0) }
        return percentString.components(separatedBy: .whitespaces).joined()
    }
}
