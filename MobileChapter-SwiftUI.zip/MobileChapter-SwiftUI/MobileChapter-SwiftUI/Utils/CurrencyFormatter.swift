//
//  CurrencyFormatter.swift
//  Homebroker
//
//  Created by GBM Mobile on 9/5/18.
//  Copyright © 2018 GBM Grupo Bursatil Mexicano. All rights reserved.
//

import UIKit

struct CurrencyFormatterStyle {
    let spaceBetweenSymbols: CGFloat
    let scaleSymbols: CGFloat
    let spaceDefault: CGFloat
    let minFontSize: CGFloat
    let baseFont: UIFont
}

class CurrencyFormatter {
    static let defaultCurrencySymbol       = "$"
    static let digitsForAmountLessThanOne  = 3
    static let maximumFractionDigits       = 2
    
    static func format(amount: Double,
                       truncate: Bool = false,
                       symbol: String = defaultCurrencySymbol,
                       showPrefix: Bool = false,
                       maximumFractionDigits: Int = maximumFractionDigits) -> String {
        let formatter = NumberFormatter()
        formatter.numberStyle = .currency
        formatter.roundingMode = .down
        formatter.currencySymbol = symbol
        formatter.currencyCode = .empty
        formatter.maximumFractionDigits = maximumFractionDigits
        if amount < 1 {
            formatter.maximumFractionDigits = digitsForAmountLessThanOne
        }
        if truncate {
            let isInteger = amount.truncatingRemainder(dividingBy: 1) == 0
            formatter.maximumFractionDigits = isInteger ? 0 : 2
        }
        if showPrefix && amount > 0 {
            formatter.positivePrefix = amount > 0 ? formatter.plusSign + formatter.currencySymbol : formatter.minusSign + formatter.currencySymbol
        }
        return formatter.string(from: NSNumber(value: amount)) ?? format(amount: 0)
    }
}
