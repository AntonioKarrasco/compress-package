//
//  ContentView.swift
//  MobileChapter-SwiftUI
//
//  Created by Isaac Velazquez on 31/08/20.
//  Copyright © 2020 Grupo Bursátil Mexicano. All rights reserved.
//

import SwiftUI
import SwiftUICharts

struct MarketIndexView: View {
    @State var results = [MarketIndexModel]()
    @State var prices = [Double]()
    var marketIndexUseCase: MarketIndexUseCase {
        let apiClient = ApiClientImplementation()
        let marketIndexApiGateway = MarketIndexApiGatewayImplementation(apiClient: apiClient)
        return MarketIndexUseCaseImplementation(marketIndexApiGateway: marketIndexApiGateway)
    }
    
    var body: some View {
        VStack {
            MultiLineChartView(data: [(prices, GradientColors.green)], title: "IPC")
            List(results, id: \.volume) { item in
                VStack(alignment: .leading) {
                    Text("Price \(item.formatPrice)")
                }
            }
        }.onAppear(perform: loadData)
    }
    
    func loadData() {
        marketIndexUseCase.fetchIpcPoints { (result) in
            switch result {
            case .success(let response):
                DispatchQueue.main.async {
                    self.prices = response.map { $0.price }
                    self.results = response
                }
            case .failure(let error):
                ApiLog.error("Error \(String(describing: error.message))")
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        MarketIndexView()
    }
}
