//
//  MarketIndexUseCase.swift
//  MobileChapter-SwiftUI
//
//  Created by Isaac Velazquez on 01/09/20.
//  Copyright © 2020 Grupo Bursátil Mexicano. All rights reserved.
//

import Foundation

typealias GetMarketIndexModelCompletionHandler = (_ token: ApiResult<[MarketIndexModel]>) -> Void

protocol MarketIndexUseCase {
    func fetchIpcPoints(completionHandler: @escaping GetMarketIndexModelCompletionHandler)
}

class MarketIndexUseCaseImplementation: MarketIndexUseCase {
    let marketIndexApiGateway: MarketIndexApiGateway
    
    init(marketIndexApiGateway: MarketIndexApiGateway) {
        self.marketIndexApiGateway = marketIndexApiGateway
    }
    
    func fetchIpcPoints(completionHandler: @escaping GetMarketIndexModelCompletionHandler) {
        marketIndexApiGateway.fetchIpcPoints { (result) in
            switch result {
            case let .success(response):
                let models = response.items.map { MarketIndexModel(date: $0.date,
                                                                   price: $0.price,
                                                                   percentageChange: $0.percentageChange,
                                                                   volume: $0.volume,
                                                                   change: $0.change) }
                completionHandler(.success(models))
            case let .failure(error):
                completionHandler(.failure(error))
            }
        }
    }
}
