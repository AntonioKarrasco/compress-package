//
//  IPCApiRequst.swift
//  MobileChapter-SwiftUI
//
//  Created by Isaac Velazquez on 31/08/20.
//  Copyright © 2020 Grupo Bursátil Mexicano. All rights reserved.
//

import Foundation

struct IPCApiRequest: ApiRequest {
    let url = Host.gbm + "/v3/cc4c350b-1f11-42a0-a1aa-f8593eafeb1e"
    
    var urlRequest: URLRequest {
        var request = URLRequest(url: URL(string: url)!)
        request.httpMethod = HttpMethod.GET
        return request
    }
}
