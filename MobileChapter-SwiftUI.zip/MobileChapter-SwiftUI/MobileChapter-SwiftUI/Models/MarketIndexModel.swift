//
//  MarketIndexModel.swift
//  MobileChapter-SwiftUI
//
//  Created by Isaac Velazquez on 02/09/20.
//  Copyright © 2020 Grupo Bursátil Mexicano. All rights reserved.
//
import Foundation

struct MarketIndexModel {
    let date: Date
    let price: Double
    let percentageChange: Double
    let volume: Int
    let change: Double
    
    var formatDate: String {
        return CustomDateFormatter.hourDate(date)
    }
    var formatPrice: String {
        return CurrencyFormatter.format(amount: price)
    }
    var formatPercentage: String {
        return PercentageFormatter.formatWithDecimals(value: percentageChange)
    }
}
