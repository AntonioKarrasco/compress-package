//
//  MarketIndex.swift
//  MobileChapter-SwiftUI
//
//  Created by Isaac Velazquez on 01/09/20.
//  Copyright © 2020 Grupo Bursátil Mexicano. All rights reserved.
//

import Foundation

struct MarketIndex {
    struct Response: Decodable, InitializableWithData {
        let items: [Index]
        
        init(data: Data?) throws {
            guard let data = data else { throw NSError.createParseError() }
            self.items = try [Index].decode(data: data)
        }
    }
    
    struct Index: Decodable {
        let date: Date
        let price: Double
        let percentageChange: Double
        let volume: Int
        let change: Double
    }
}
