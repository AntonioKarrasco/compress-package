//
//  MarketIndexApiGateway.swift
//  MobileChapter-SwiftUI
//
//  Created by Isaac Velazquez on 31/08/20.
//  Copyright © 2020 Grupo Bursátil Mexicano. All rights reserved.
//

import Foundation

typealias GetMarketIndexApiGatewayCompletionHandler = (_ token: ApiResult<MarketIndex.Response>) -> Void

protocol MarketIndexApiGateway {
    func fetchIpcPoints(completionHandler: @escaping GetMarketIndexApiGatewayCompletionHandler)
}

class MarketIndexApiGatewayImplementation: MarketIndexApiGateway {
    let apiClient: ApiClient
    
    init(apiClient: ApiClient) {
        self.apiClient = apiClient
    }
    
    func fetchIpcPoints(completionHandler: @escaping GetMarketIndexApiGatewayCompletionHandler) {
        let request = IPCApiRequest()
        apiClient.execute(request: request) { (result: ApiResult<ApiResponse<MarketIndex.Response>>) in
            switch result {
            case .success(let response):
                let entity = response.entity
                completionHandler(.success(entity!))
            case .failure(let error):
                completionHandler(.failure(error))
            }
        }
    }
}
