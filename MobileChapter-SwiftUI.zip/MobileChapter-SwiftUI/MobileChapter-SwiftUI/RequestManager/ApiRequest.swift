//
//  ApiRequest.swift
//  ApiGateway
//
//  Created by gbmlocaladmin on 06/03/18.
//  Copyright © 2018 GBM. All rights reserved.
//

import Foundation

protocol ApiRequest {
    var urlRequest: URLRequest { get }
}

extension URLRequest {    
    struct Properties {
        let identifier: String
        let httpMethod: String
        let endPoint: String?
        
        init(identifier: String, httpMethod: String, endPoint: String? = nil) {
            self.identifier = identifier
            self.httpMethod = httpMethod
            self.endPoint = endPoint
        }
    }
}
