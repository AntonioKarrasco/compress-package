//
//  ApiClient.swift
//  MobileChapter-SwiftUI
//
//  Created by Isaac Velazquez on 31/08/20.
//  Copyright © 2020 Grupo Bursátil Mexicano. All rights reserved.
//

import Foundation

enum StatusCode: Int {
    case success             = 200
    case created             = 201
    case noContent           = 204
    case partialContent      = 206
    case badRequest          = 400
    case unauthorized        = 401
    case forbidden           = 403
    case notFound            = 404
    case internalServerError = 500
    case serviceUnavailable  = 503
}

struct Host {
    static let gbm = "https://run.mocky.io"
}

struct HttpMethod {
    static let GET    = "GET"
    static let POST   = "POST"
    static let PUT    = "PUT"
    static let DELETE = "DELETE"
}

protocol ApiClient {
    func execute<T>(request: ApiRequest, completion: @escaping (_ result: ApiResult<ApiResponse<T>>) -> Void)
}

protocol URLSessionProtocol {
    func dataTask(with request: URLRequest, completionHandler: @escaping (Data?, URLResponse?, Error?) -> Void) -> URLSessionDataTask
}
extension URLSession: URLSessionProtocol { }

class ApiClientImplementation: NSObject, ApiClient, URLSessionDelegate {
    static let timeOut = 240.0
    static let emptyExplicit = "\"\""
    
    var urlSession: URLSessionProtocol!
    
    override init() {
        super.init()
        urlSession = URLSession(configuration: configuration, delegate: self, delegateQueue: nil)
    }
    
    init(urlSession: URLSessionProtocol) {
        self.urlSession = urlSession
    }
    
    fileprivate func requestDataLog(requestLog: inout String, log: String) {
        requestLog = requestLog + String.newLine + log
    }
    
    func execute<T>(request: ApiRequest, completion: @escaping (ApiResult<ApiResponse<T>>) -> Void) {
        let urlRequest = request.urlRequest
        let absoluteString = urlRequest.url?.absoluteString ?? .empty
        var requestLog = String.empty
        requestDataLog(requestLog: &requestLog, log: "Request: \(absoluteString)")
        requestDataLog(requestLog: &requestLog, log: "Headers: \(urlRequest.allHTTPHeaderFields ?? [:])")
        requestDataLog(requestLog: &requestLog, log: "Method: \(urlRequest.httpMethod ?? .empty)")
        if let httpBody = urlRequest.httpBody {
            requestDataLog(requestLog: &requestLog, log: "HttpBody: \(String.init(data: httpBody, encoding: String.Encoding.utf8) ?? .empty)")
        }
        ApiLog.info(requestLog)
        let dataTask = urlSession.dataTask(with: request.urlRequest) { [weak self] (data, response, error) in
            var responseLog = String.empty
            guard let httpUrlResponse = response as? HTTPURLResponse else {
                DispatchQueue.main.async { completion(.failure(ApiError.networkRequestError)) }
                return
            }
            self?.requestDataLog(requestLog: &responseLog, log: "Response: \(absoluteString)")
            self?.requestDataLog(requestLog: &responseLog, log: "StatusCode: \(httpUrlResponse.statusCode)")
            if let response = data {
                let logString = String(data: response, encoding: .utf8) ?? .empty
                self?.requestDataLog(requestLog: &responseLog, log: "Data: \(logString)")
            } else {
                self?.requestDataLog(requestLog: &responseLog, log: "No data")
            }
            ApiLog.info(responseLog)
            if httpUrlResponse.statusCode == StatusCode.success.rawValue ||
                httpUrlResponse.statusCode == StatusCode.noContent.rawValue ||
                httpUrlResponse.statusCode == StatusCode.created.rawValue {
                do {
                    let response = data?.count == .zero ? try ApiResponse<T>() : try ApiResponse<T>(data: data, httpUrlResponse: httpUrlResponse)
                    DispatchQueue.main.async {
                        completion(.success(response))
                    }
                } catch {
                    if let response = try? ApiResponse<T>(),
                        let responseString = String(data: data ?? Data(), encoding: .utf8),
                        responseString == ApiClientImplementation.emptyExplicit {
                        DispatchQueue.main.async {
                            completion(.success(response))
                        }
                        return
                    }
                    DispatchQueue.main.async {
                        completion(.failure(ApiError.unexpectedError))
                    }
                }
            } else {
                DispatchQueue.main.async {
                    switch httpUrlResponse.statusCode {
                    case StatusCode.unauthorized.rawValue,
                         StatusCode.serviceUnavailable.rawValue:
                        completion(.failure(ApiError.unauthorizedError))
                    case StatusCode.notFound.rawValue:
                        completion(.failure(ApiError.notFound))
                    default:
                        let apiError = ApiError(data: data)
                        completion(.failure(apiError))
                    }
                }
            }
        }
        dataTask.resume()
    }
    
    var configuration: URLSessionConfiguration {
        let configuration = URLSessionConfiguration.default
        configuration.timeoutIntervalForRequest = ApiClientImplementation.timeOut
        configuration.timeoutIntervalForResource = ApiClientImplementation.timeOut
        return configuration
    }
}
