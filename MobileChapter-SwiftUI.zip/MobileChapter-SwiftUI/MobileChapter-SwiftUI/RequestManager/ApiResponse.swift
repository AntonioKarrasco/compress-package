//
//  APIResponse.swift
//  ApiGateway
//
//  Created by gbmlocaladmin on 06/03/18.
//  Copyright © 2018 GBM. All rights reserved.
//

import UIKit

protocol InitializableWithData {
    init(data: Data?) throws
}

protocol InitializableWithJson {
    init(json: [String: Any]) throws
}

struct ApiParseError: Error {
    static let code = 999
    let error: Error
    let httpUrlResponse: HTTPURLResponse
    let data: Data?
    
    var localizedDescription: String {
        return error.localizedDescription + " \(error)"
    }
}

struct ApiResponse<T: InitializableWithData> {
    let entity: T?
    let httpUrlResponse: HTTPURLResponse?
    let data: Data?
    
    init(data: Data?, httpUrlResponse: HTTPURLResponse) throws {
        do {
            self.entity = try T(data: data)
            self.httpUrlResponse = httpUrlResponse
            self.data = data
        } catch {
            throw ApiParseError(error: error, httpUrlResponse: httpUrlResponse, data: data)
        }
    }
 
    init() throws {
        let data = Data()
        self.entity = try? T(data: data)
        self.httpUrlResponse = nil
        self.data = data
    }
}

extension Array: InitializableWithData {
    init(data: Data?) throws {
        guard let data = data,
            let jsonObject = try? JSONSerialization.jsonObject(with: data),
            let jsonArray = jsonObject as? [[String: Any]] else {
                throw NSError.createParseError()
        }
        
        guard let element = Element.self as? InitializableWithJson.Type else {
            throw NSError.createParseError()
        }
        
        self = try jsonArray.map({
            return try element.init(json: $0) as! Element
        })
    }
}

extension NSError {
    static func createParseError() -> NSError {
        return NSError(domain: "Challenge",
                       code: ApiParseError.code,
                       userInfo: [NSLocalizedDescriptionKey: "A parsing error occured"])
    }
}
