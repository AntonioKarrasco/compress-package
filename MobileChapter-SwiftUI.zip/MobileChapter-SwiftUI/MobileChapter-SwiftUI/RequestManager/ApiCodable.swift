//
//  ApiCodable.swift
//  ApiGateway
//
//  Created by gbmlocaladmin on 07/03/18.
//  Copyright © 2018 GBM. All rights reserved.
//

import UIKit
import CoreData

extension Decodable {
    static func decode(data: Data) throws -> Self {
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .customDecodeDate
        do {
            return try decoder.decode(Self.self, from: data)
        } catch let error {
            ApiLog.error(error.localizedDescription)
        }
        return try decoder.decode(Self.self, from: data)
    }
}

extension Encodable {
    func encode() throws -> Data {
        let encoder = JSONEncoder()
        encoder.outputFormatting = .prettyPrinted
        encoder.dateEncodingStrategy = .customEncodeDate
        return try encoder.encode(self)
    }
}

extension JSONDecoder.DateDecodingStrategy {
    static let customDecodeDate = custom({ decoder -> Date in
        let container = try decoder.singleValueContainer()
        let string = try container.decode(String.self)
        if #available(iOS 10.0, *) {
            if let date = Formatter.baseFormatCodable.date(from: string) ?? ISO8601DateFormatter().date(from: string) {
                return date
            }
        } else {
            // Fallback on earlier versions
        }
        throw DecodingError.dataCorruptedError(in: container, debugDescription: "Invalid date: \(string)")
    })
}

extension JSONEncoder.DateEncodingStrategy {
    static let customEncodeDate = custom {
        var container = $1.singleValueContainer()
        try container.encode(Formatter.baseFormatCodable.string(from: $0))
    }
}

extension Formatter {
    static let baseFormatCodable: DateFormatter = {
        let formatter = DateFormatter()
        formatter.calendar = Calendar(identifier: .iso8601)
        formatter.locale = Locale(identifier: "MX")
        formatter.timeZone = TimeZone(secondsFromGMT: 0)
        formatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX"
        return formatter
    }()
}
